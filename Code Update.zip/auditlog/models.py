from django.db import models
from django.conf import settings
from django.utils import timezone


class AuditLog(models.Model):
    """
    Central audit log for all user activity in WSMS Cloud.
    Records every significant action by shop admins, staff, and customers.
    """

    # ── Actor ────────────────────────────────────────────────────────────────
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='audit_logs',
    )
    user_username = models.CharField(max_length=150, blank=True, default='')
    user_role = models.CharField(max_length=30, blank=True, default='')

    # Shop the action belongs to (null for super-admin actions)
    shop = models.ForeignKey(
        'accounts.Shop',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='audit_logs',
    )

    # ── Action classification ─────────────────────────────────────────────
    ACTION_CATEGORIES = [
        ('auth',        'Authentication'),
        ('delivery',    'Delivery'),
        ('invoice',     'Invoice'),
        ('payment',     'Payment'),
        ('customer',    'Customer'),
        ('staff',       'Staff / Employee'),
        ('can',         'Can / Stock'),
        ('expense',     'Expense'),
        ('inventory',   'Inventory'),
        ('assignment',  'Delivery Assignment'),
        ('profile',     'Profile / Settings'),
        ('report',      'Report / Export'),
        ('system',      'System'),
        ('other',       'Other'),
    ]

    SEVERITY_CHOICES = [
        ('info',    'Info'),
        ('success', 'Success'),
        ('warning', 'Warning'),
        ('danger',  'Danger / Critical'),
    ]

    category   = models.CharField(max_length=30, choices=ACTION_CATEGORIES, default='other', db_index=True)
    action     = models.CharField(max_length=120)          # e.g. "created", "deleted", "logged_in"
    severity   = models.CharField(max_length=10, choices=SEVERITY_CHOICES, default='info', db_index=True)

    # ── Target object (generic) ───────────────────────────────────────────
    object_type  = models.CharField(max_length=60, blank=True, default='')   # e.g. "Invoice"
    object_id    = models.CharField(max_length=40, blank=True, default='')   # pk of the affected object
    object_repr  = models.CharField(max_length=255, blank=True, default='')  # human label

    # ── Detail ────────────────────────────────────────────────────────────
    description  = models.TextField(blank=True, default='')
    # JSON-serialisable dict of before/after values or extra context
    extra        = models.JSONField(null=True, blank=True)

    # ── Request metadata ─────────────────────────────────────────────────
    ip_address   = models.GenericIPAddressField(null=True, blank=True)
    user_agent   = models.TextField(blank=True, default='')
    request_path = models.CharField(max_length=500, blank=True, default='')
    request_method = models.CharField(max_length=10, blank=True, default='')

    # ── Timestamp ─────────────────────────────────────────────────────────
    timestamp = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['shop', '-timestamp']),
            models.Index(fields=['user', '-timestamp']),
            models.Index(fields=['category', '-timestamp']),
            models.Index(fields=['severity', '-timestamp']),
            models.Index(fields=['object_type', 'object_id']),
        ]
        verbose_name = 'Audit Log'
        verbose_name_plural = 'Audit Logs'

    def __str__(self):
        return f"[{self.timestamp.strftime('%Y-%m-%d %H:%M')}] {self.user_username} — {self.category}/{self.action}"

    @classmethod
    def log(
        cls,
        *,
        user=None,
        shop=None,
        category='other',
        action,
        severity='info',
        object_type='',
        object_id='',
        object_repr='',
        description='',
        extra=None,
        request=None,
    ):
        """
        Convenience factory.  Call from views, signals, or model.save():

            AuditLog.log(
                user=request.user,
                shop=request.user.shop,
                category='invoice',
                action='created',
                severity='success',
                object_type='Invoice',
                object_id=str(invoice.pk),
                object_repr=invoice.invoice_number,
                description=f"Invoice {invoice.invoice_number} created for {invoice.customer}",
                request=request,
            )
        """
        ip = None
        ua = ''
        path = ''
        method = ''
        if request:
            forwarded = request.META.get('HTTP_X_FORWARDED_FOR', '')
            ip = forwarded.split(',')[0].strip() if forwarded else request.META.get('REMOTE_ADDR')
            ua = request.META.get('HTTP_USER_AGENT', '')[:500]
            path = request.path[:500]
            method = request.method

        username = ''
        role = ''
        if user and user.is_authenticated:
            username = user.username
            role = getattr(user, 'role', '') or ''

        try:
            cls.objects.create(
                user=user if (user and user.is_authenticated) else None,
                user_username=username,
                user_role=role,
                shop=shop,
                category=category,
                action=action,
                severity=severity,
                object_type=object_type,
                object_id=str(object_id),
                object_repr=object_repr,
                description=description,
                extra=extra,
                ip_address=ip,
                user_agent=ua,
                request_path=path,
                request_method=method,
            )
        except Exception:
            pass   # Never let audit logging crash the main appfrom django.db import models

# Create your models here.
