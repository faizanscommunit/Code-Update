from django.urls import path
from . import views

app_name = 'auditlog'

urlpatterns = [
    path('',          views.audit_log_list,        name='list'),
    path('export/',   views.audit_log_export_csv,  name='export_csv'),
    path('stats/',    views.audit_log_stats_json,  name='stats_json'),
]