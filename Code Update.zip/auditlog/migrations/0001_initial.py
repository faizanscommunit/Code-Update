from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('accounts', '0001_initial'),   # adjust to your actual last migration name
    ]

    operations = [
        migrations.CreateModel(
            name='AuditLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('user_username', models.CharField(blank=True, default='', max_length=150)),
                ('user_role', models.CharField(blank=True, default='', max_length=30)),
                ('category', models.CharField(
                    choices=[
                        ('auth', 'Authentication'), ('delivery', 'Delivery'),
                        ('invoice', 'Invoice'), ('payment', 'Payment'),
                        ('customer', 'Customer'), ('staff', 'Staff / Employee'),
                        ('can', 'Can / Stock'), ('expense', 'Expense'),
                        ('inventory', 'Inventory'), ('assignment', 'Delivery Assignment'),
                        ('profile', 'Profile / Settings'), ('report', 'Report / Export'),
                        ('system', 'System'), ('other', 'Other'),
                    ],
                    db_index=True, default='other', max_length=30
                )),
                ('action', models.CharField(max_length=120)),
                ('severity', models.CharField(
                    choices=[
                        ('info', 'Info'), ('success', 'Success'),
                        ('warning', 'Warning'), ('danger', 'Danger / Critical'),
                    ],
                    db_index=True, default='info', max_length=10
                )),
                ('object_type', models.CharField(blank=True, default='', max_length=60)),
                ('object_id', models.CharField(blank=True, default='', max_length=40)),
                ('object_repr', models.CharField(blank=True, default='', max_length=255)),
                ('description', models.TextField(blank=True, default='')),
                ('extra', models.JSONField(blank=True, null=True)),
                ('ip_address', models.GenericIPAddressField(blank=True, null=True)),
                ('user_agent', models.TextField(blank=True, default='')),
                ('request_path', models.CharField(blank=True, default='', max_length=500)),
                ('request_method', models.CharField(blank=True, default='', max_length=10)),
                ('timestamp', models.DateTimeField(db_index=True, default=django.utils.timezone.now)),
                ('user', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='audit_logs',
                    to='accounts.user',   # ← adjust to your AUTH_USER_MODEL app label
                )),
                ('shop', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='audit_logs',
                    to='accounts.shop',
                )),
            ],
            options={
                'verbose_name': 'Audit Log',
                'verbose_name_plural': 'Audit Logs',
                'ordering': ['-timestamp'],
            },
        ),
        migrations.AddIndex(
            model_name='auditlog',
            index=models.Index(fields=['shop', '-timestamp'], name='al_shop_ts_idx'),
        ),
        migrations.AddIndex(
            model_name='auditlog',
            index=models.Index(fields=['user', '-timestamp'], name='al_user_ts_idx'),
        ),
        migrations.AddIndex(
            model_name='auditlog',
            index=models.Index(fields=['category', '-timestamp'], name='al_cat_ts_idx'),
        ),
        migrations.AddIndex(
            model_name='auditlog',
            index=models.Index(fields=['severity', '-timestamp'], name='al_sev_ts_idx'),
        ),
        migrations.AddIndex(
            model_name='auditlog',
            index=models.Index(fields=['object_type', 'object_id'], name='al_obj_idx'),
        ),
    ]
