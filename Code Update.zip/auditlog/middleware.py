"""
auditlog/middleware.py

Automatically logs every authenticated POST/DELETE/PUT/PATCH request.
Also logs login and logout events via the request path heuristic.

For finer control, call AuditLog.log() directly from your views.
"""

import re
from django.utils import timezone

# Paths to skip (static files, AJAX polling, tracking pings, etc.)
SKIP_PATTERNS = [
    re.compile(r'^/static/'),
    re.compile(r'^/media/'),
    re.compile(r'^/favicon'),
    re.compile(r'^/tracking/api/location/'),   # high-frequency GPS pings
    re.compile(r'^/tracking/events/'),
    re.compile(r'^/accounts/recent-activities/'),
    re.compile(r'^/api/low-stock-count/'),
    re.compile(r'^/__debug__/'),
    re.compile(r'^/admin/jsi18n/'),
]

# Map URL fragments → (category, action, severity)
_PATH_RULES = [
    # Auth
    (re.compile(r'/login/$'),                          'auth',       'logged_in',          'info'),
    (re.compile(r'/logout/$'),                         'auth',       'logged_out',          'info'),
    # Deliveries
    (re.compile(r'/deliveries/create/'),               'delivery',   'created',             'success'),
    (re.compile(r'/deliveries/\d+/edit/'),             'delivery',   'edited',              'warning'),
    (re.compile(r'/deliveries/\d+/delete/'),           'delivery',   'deleted',             'danger'),
    (re.compile(r'/record-delivery/'),                 'delivery',   'staff_recorded',      'success'),
    # Invoices
    (re.compile(r'/invoices/auto-generate/'),          'invoice',    'auto_generated',      'success'),
    (re.compile(r'/invoices/delete-all/'),             'invoice',    'bulk_deleted',        'danger'),
    (re.compile(r'/invoice/\d+/delete/'),              'invoice',    'deleted',             'danger'),
    (re.compile(r'/invoice/\d+/send/'),                'invoice',    'sent',                'info'),
    (re.compile(r'/invoice/\d+/pay/'),                 'invoice',    'payment_recorded',    'success'),
    (re.compile(r'/invoice/\d+/mark-paid/'),           'invoice',    'marked_paid',         'success'),
    (re.compile(r'/generate_bill/'),                   'invoice',    'custom_generated',    'success'),
    # Payments
    (re.compile(r'/receive-payment/'),                 'payment',    'received',            'success'),
    (re.compile(r'/payment/\d+/delete/'),              'payment',    'deleted',             'danger'),
    (re.compile(r'/payments/delete-all/'),             'payment',    'bulk_deleted',        'danger'),
    (re.compile(r'/payment/\d+/edit/'),                'payment',    'edited',              'warning'),
    (re.compile(r'/payment/\d+/mark-received/'),       'payment',    'marked_completed',    'success'),
    # Customers
    (re.compile(r'/customer/create/'),                 'customer',   'created',             'success'),
    (re.compile(r'/customer/\d+/edit/'),               'customer',   'edited',              'warning'),
    (re.compile(r'/customer/\d+/delete/'),             'customer',   'hard_deleted',        'danger'),
    (re.compile(r'/customer/\d+/archive/'),            'customer',   'archived',            'warning'),
    # Can ledger
    (re.compile(r'/can-statement/.+/add-opening/'),    'can',        'opening_added',       'info'),
    (re.compile(r'/can-statement/.+/add-adjustment/'), 'can',        'adjustment_added',    'warning'),
    # Staff
    (re.compile(r'/staff/create/'),                    'staff',      'created',             'success'),
    (re.compile(r'/staff/\d+/edit/'),                  'staff',      'edited',              'warning'),
    (re.compile(r'/staff/\d+/delete/'),                'staff',      'deleted',             'danger'),
    # Assignments
    (re.compile(r'/assignments/create/'),              'assignment', 'created',             'success'),
    (re.compile(r'/assignments/\d+/delete/'),          'assignment', 'deleted',             'danger'),
    (re.compile(r'/rider/mark-done/'),                 'assignment', 'marked_done',         'success'),
    (re.compile(r'/rider/mark-failed/'),               'assignment', 'marked_failed',       'warning'),
    # Expenses
    (re.compile(r'/expenses/add/'),                    'expense',    'created',             'success'),
    (re.compile(r'/expenses/\d+/edit/'),               'expense',    'edited',              'warning'),
    (re.compile(r'/expenses/\d+/delete/'),             'expense',    'deleted',             'danger'),
    # Inventory
    (re.compile(r'/inventory/stock-in/'),              'inventory',  'stock_in',            'success'),
    (re.compile(r'/inventory/stock-out/'),             'inventory',  'stock_out',           'warning'),
    (re.compile(r'/inventory/adjustment/'),            'inventory',  'stock_adjusted',      'warning'),
    (re.compile(r'/inventory/items/create/'),          'inventory',  'item_created',        'success'),
    (re.compile(r'/inventory/items/\d+/delete/'),      'inventory',  'item_deleted',        'danger'),
    (re.compile(r'/inventory/po/\d+/receive/'),        'inventory',  'po_received',         'success'),
    # Can types
    (re.compile(r'/can-types/create/'),                'can',        'type_created',        'success'),
    (re.compile(r'/can-types/\d+/delete/'),            'can',        'type_deleted',        'danger'),
    # Profile
    (re.compile(r'/profile/$'),                        'profile',    'updated',             'info'),
    # Reports
    (re.compile(r'/profit-loss/'),                     'report',     'viewed_pnl',          'info'),
]


def _match_path(path):
    for pattern, category, action, severity in _PATH_RULES:
        if pattern.search(path):
            return category, action, severity
    return None, None, None


class AuditLogMiddleware:
    """
    Logs significant POST/DELETE/PUT/PATCH requests automatically.
    Add to MIDDLEWARE **after** AuthenticationMiddleware:

        MIDDLEWARE = [
            ...
            'django.contrib.auth.middleware.AuthenticationMiddleware',
            'auditlog.middleware.AuditLogMiddleware',
            ...
        ]
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        # Only log authenticated users and relevant methods
        if not getattr(request, 'user', None) or not request.user.is_authenticated:
            return response
        if request.method not in ('POST', 'PUT', 'PATCH', 'DELETE'):
            return response

        path = request.path
        for skip in SKIP_PATTERNS:
            if skip.match(path):
                return response

        category, action, severity = _match_path(path)
        if not category:
            return response   # unrecognised path — skip

        # Only log successful responses (2xx / 3xx)
        if response.status_code >= 400:
            return response

        try:
            from .models import AuditLog
            user = request.user
            shop = None
            try:
                if getattr(user, 'role', '') == 'staff':
                    from accounts.models import Staff
                    st = Staff.objects.filter(user=user).select_related('admin__shop_admin').first()
                    if st:
                        shop = getattr(st.admin, 'shop_admin', None)
                else:
                    shop = getattr(user, 'shop_admin', None)
            except Exception:
                pass

            AuditLog.log(
                user=user,
                shop=shop,
                category=category,
                action=action,
                severity=severity,
                description=f"{request.method} {path}",
                request=request,
            )
        except Exception:
            pass   # Never crash the app

        return response