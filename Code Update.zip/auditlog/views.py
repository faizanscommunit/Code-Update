"""
auditlog/views.py

Audit log dashboard — accessible by shop_admin only.
Shows paginated, filtered logs for their own shop.
"""
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.utils import timezone
from django.db.models import Q, Count
from django.core.paginator import Paginator
import csv
import datetime

from .models import AuditLog


def _require_shop_admin(view_fn):
    from functools import wraps
    @wraps(view_fn)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login')
        role = getattr(request.user, 'role', '')
        if role not in ('shop_admin', 'super_admin'):
            from django.http import HttpResponseForbidden
            return HttpResponseForbidden('Admin access required.')
        return view_fn(request, *args, **kwargs)
    return wrapper


def _get_shop(user):
    try:
        return getattr(user, 'shop_admin', None)
    except Exception:
        return None


@login_required
@_require_shop_admin
def audit_log_list(request):
    user = request.user
    shop = _get_shop(user)

    # Base queryset — super_admin sees everything, shop_admin sees own shop
    if getattr(user, 'role', '') == 'super_admin':
        qs = AuditLog.objects.all()
    else:
        qs = AuditLog.objects.filter(
            Q(shop=shop) | Q(user=user)
        )

    # ── Filters ──────────────────────────────────────────────────────────
    category  = request.GET.get('category', '').strip()
    severity  = request.GET.get('severity', '').strip()
    user_q    = request.GET.get('user', '').strip()
    search    = request.GET.get('search', '').strip()
    date_from = request.GET.get('date_from', '').strip()
    date_to   = request.GET.get('date_to', '').strip()
    obj_type  = request.GET.get('object_type', '').strip()

    if category:
        qs = qs.filter(category=category)
    if severity:
        qs = qs.filter(severity=severity)
    if user_q:
        qs = qs.filter(user_username__icontains=user_q)
    if search:
        qs = qs.filter(
            Q(description__icontains=search) |
            Q(action__icontains=search) |
            Q(object_repr__icontains=search) |
            Q(request_path__icontains=search) |
            Q(user_username__icontains=search)
        )
    if date_from:
        try:
            qs = qs.filter(timestamp__date__gte=datetime.date.fromisoformat(date_from))
        except ValueError:
            pass
    if date_to:
        try:
            qs = qs.filter(timestamp__date__lte=datetime.date.fromisoformat(date_to))
        except ValueError:
            pass
    if obj_type:
        qs = qs.filter(object_type__iexact=obj_type)

    # ── Stats for cards ───────────────────────────────────────────────────
    today = timezone.now().date()
    total_today  = qs.filter(timestamp__date=today).count()
    total_week   = qs.filter(timestamp__date__gte=today - datetime.timedelta(days=7)).count()
    total_danger = qs.filter(severity='danger').count()
    total_all    = qs.count()

    # Category breakdown for mini chart
    cat_counts = (
        qs.values('category')
        .annotate(n=Count('id'))
        .order_by('-n')[:8]
    )

    # Recent unique users
    recent_users = (
        qs.filter(timestamp__date__gte=today - datetime.timedelta(days=1))
        .values_list('user_username', flat=True)
        .distinct()[:20]
    )

    # ── Pagination ────────────────────────────────────────────────────────
    paginator = Paginator(qs.select_related('user', 'shop'), 50)
    page      = paginator.get_page(request.GET.get('page', 1))

    ctx = {
        'logs':          page,
        'total_today':   total_today,
        'total_week':    total_week,
        'total_danger':  total_danger,
        'total_all':     total_all,
        'cat_counts':    list(cat_counts),
        'recent_users':  list(recent_users),
        # Filter values for form re-population
        'f_category':  category,
        'f_severity':  severity,
        'f_user':      user_q,
        'f_search':    search,
        'f_date_from': date_from,
        'f_date_to':   date_to,
        'f_obj_type':  obj_type,
        # Choices for dropdowns
        'categories': AuditLog.ACTION_CATEGORIES,
        'severities': AuditLog.SEVERITY_CHOICES,
    }
    return render(request, 'auditlog/audit_log_list.html', ctx)


@login_required
@_require_shop_admin
def audit_log_export_csv(request):
    """Export filtered audit logs as CSV."""
    user = request.user
    shop = _get_shop(user)

    if getattr(user, 'role', '') == 'super_admin':
        qs = AuditLog.objects.all()
    else:
        qs = AuditLog.objects.filter(Q(shop=shop) | Q(user=user))

    # Apply same filters as list view
    for field, lookup in [
        ('category',      'category'),
        ('severity',      'severity'),
    ]:
        val = request.GET.get(field, '').strip()
        if val:
            qs = qs.filter(**{lookup: val})

    search = request.GET.get('search', '').strip()
    if search:
        qs = qs.filter(
            Q(description__icontains=search) |
            Q(action__icontains=search) |
            Q(object_repr__icontains=search) |
            Q(user_username__icontains=search)
        )

    response = HttpResponse(content_type='text/csv')
    filename = f"audit_log_{timezone.now().strftime('%Y%m%d_%H%M%S')}.csv"
    response['Content-Disposition'] = f'attachment; filename="{filename}"'

    writer = csv.writer(response)
    writer.writerow([
        'Timestamp', 'User', 'Role', 'Category', 'Action',
        'Severity', 'Object Type', 'Object ID', 'Object',
        'Description', 'IP Address', 'Path', 'Method'
    ])

    for log in qs.order_by('-timestamp')[:10000]:
        writer.writerow([
            log.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            log.user_username,
            log.user_role,
            log.category,
            log.action,
            log.severity,
            log.object_type,
            log.object_id,
            log.object_repr,
            log.description,
            log.ip_address or '',
            log.request_path,
            log.request_method,
        ])

    return response


@login_required
@_require_shop_admin
def audit_log_stats_json(request):
    """AJAX — returns category/severity breakdown for charts."""
    user = request.user
    shop = _get_shop(user)

    if getattr(user, 'role', '') == 'super_admin':
        qs = AuditLog.objects.all()
    else:
        qs = AuditLog.objects.filter(Q(shop=shop) | Q(user=user))

    today = timezone.now().date()
    days  = int(request.GET.get('days', 7))
    since = today - datetime.timedelta(days=days)
    qs    = qs.filter(timestamp__date__gte=since)

    by_category = list(
        qs.values('category').annotate(n=Count('id')).order_by('-n')
    )
    by_severity = list(
        qs.values('severity').annotate(n=Count('id')).order_by('-n')
    )
    # Activity per day (last N days)
    daily = []
    for i in range(days, -1, -1):
        d = today - datetime.timedelta(days=i)
        daily.append({
            'date':  d.isoformat(),
            'count': qs.filter(timestamp__date=d).count(),
        })

    return JsonResponse({
        'by_category': by_category,
        'by_severity': by_severity,
        'daily':       daily,
    })