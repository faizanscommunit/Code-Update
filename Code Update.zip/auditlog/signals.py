"""
auditlog/signals.py

Only auth signals here.
Model-level events (delivery, payment, invoice, customer) are captured
by AuditLogMiddleware via the request/response cycle to avoid duplicates.
"""
from django.contrib.auth.signals import user_logged_in, user_logged_out, user_login_failed
from django.dispatch import receiver


@receiver(user_logged_in)
def on_login(sender, request, user, **kwargs):
    try:
        from .models import AuditLog
        shop = None
        try:
            shop = getattr(user, 'shop_admin', None)
        except Exception:
            pass
        AuditLog.log(
            user=user, shop=shop,
            category='auth', action='logged_in', severity='success',
            description=f"User '{user.username}' logged in ({getattr(user, 'role', 'unknown')} role)",
            request=request,
        )
    except Exception:
        pass


@receiver(user_logged_out)
def on_logout(sender, request, user, **kwargs):
    try:
        from .models import AuditLog
        if not user:
            return
        shop = None
        try:
            shop = getattr(user, 'shop_admin', None)
        except Exception:
            pass
        AuditLog.log(
            user=user, shop=shop,
            category='auth', action='logged_out', severity='info',
            description=f"User '{user.username}' logged out",
            request=request,
        )
    except Exception:
        pass


@receiver(user_login_failed)
def on_login_failed(sender, credentials, request, **kwargs):
    try:
        from .models import AuditLog
        username = credentials.get('username', 'unknown') if credentials else 'unknown'
        AuditLog.log(
            user=None, shop=None,
            category='auth', action='login_failed', severity='danger',
            description=f"Failed login attempt for username: '{username}'",
            request=request,
        )
    except Exception:
        pass