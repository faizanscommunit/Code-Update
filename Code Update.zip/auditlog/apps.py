from django.apps import AppConfig


class AuditlogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'auditlog'
    verbose_name = 'Audit Log'

    def ready(self):
        # Import signals so they register on startup
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass