from django.contrib import admin
from django.contrib.sitemaps.views import sitemap
from django.urls import path, include, reverse
from django.conf.urls.i18n import i18n_patterns
from django.http import HttpResponse

handler404 = 'accounts.views.error_404'
handler500 = 'accounts.views.error_500'
handler400 = 'accounts.views.error_400'


def robots_txt(request):
    sitemap_url = request.build_absolute_uri(reverse('sitemap'))
    lines = [
        'User-agent: *',
        'Allow: /',
        f'Sitemap: {sitemap_url}',
    ]
    return HttpResponse('\n'.join(lines), content_type='text/plain')

# set admin site titles
admin.site.site_header = "WSMS Cloud"
admin.site.site_title = "WSMS Cloud"
admin.site.index_title = "WSMS Cloud"

from accounts.sitemaps import StaticViewSitemap

sitemaps = {
    'static': StaticViewSitemap(),
}

urlpatterns = [
    # Language switcher (must NOT be inside i18n_patterns)
    path('i18n/', include('django.conf.urls.i18n')),
    path('sitemap.xml', sitemap, {'sitemaps': sitemaps}, name='sitemap'),
    path('robots.txt', robots_txt, name='robots_txt'),
]

urlpatterns += i18n_patterns(
    path('administration-panel/', admin.site.urls, name='administration_panel'),
    path('', include('accounts.urls')),
    path('inventory/', include('inventory.urls')),
    path('tracking/', include('tracking.urls', namespace='tracking')),
    path('audit-log/', include('auditlog.urls', namespace='auditlog')),
    prefix_default_language=False,  # /en/ prefix hidden; Arabic gets /ar/
)
