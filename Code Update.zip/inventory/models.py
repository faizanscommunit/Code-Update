# ================================================================================
# inventory/models.py  — CORRECTED
#
# Key fixes applied:
#   1. Removed the first (dead) InventorySale class — only one definition remains.
#   2. Added `customer = ForeignKey(accounts.Customer)` back to InventorySale.
#   3. Fixed InventoryReceivable.save() — removed the ReceivableLedger creation
#      block that used self.admin.shop (which doesn't exist on User) and also
#      violated the ReceivableLedger unique_together constraint. The accounts-level
#      ReceivableLedger is now hit from InventorySale.save() instead, where the
#      customer's shop is available via customer.shop.
#   4. InventorySale.save() — always creates an InventoryInvoice on new completed
#      sales AND hits ReceivableLedger when there is an outstanding balance and a
#      linked accounts.Customer.
#   5. InventoryReceivable — added explicit `sale` OneToOne field (was only a
#      reverse-relation comment before, causing fragile hasattr() checks).
# ================================================================================

from django.db import models
from django.conf import settings
from django.db.models import Q, Sum
from django.utils import timezone
from django.core.exceptions import ValidationError
from decimal import Decimal
import uuid as _uuid_module


# ──────────────────────────────────────────────────────────────────────────────
# SUPPLIER
# ──────────────────────────────────────────────────────────────────────────────

class Supplier(models.Model):
    admin        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='suppliers')
    name         = models.CharField(max_length=200)
    contact_name = models.CharField(max_length=100, blank=True, default='')
    phone        = models.CharField(max_length=20, blank=True, default='')
    email        = models.EmailField(blank=True, default='')
    address      = models.TextField(blank=True, default='')
    notes        = models.TextField(blank=True, default='')
    is_active    = models.BooleanField(default=True)
    created_at   = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)

    class Meta:
        ordering        = ['name']
        unique_together = [('admin', 'name')]

    def __str__(self):
        return self.name

    @property
    def total_purchases(self):
        return self.purchase_orders.filter(status='received').aggregate(t=Sum('total_cost'))['t'] or Decimal('0.00')


# ──────────────────────────────────────────────────────────────────────────────
# INVENTORY CATEGORY
# ──────────────────────────────────────────────────────────────────────────────

class InventoryCategory(models.Model):
    admin       = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='inventory_categories')
    name        = models.CharField(max_length=100)
    description = models.TextField(blank=True, default='')
    icon        = models.CharField(max_length=50, blank=True, default='fas fa-box', help_text='FontAwesome class e.g. fas fa-tint')
    color       = models.CharField(max_length=20, blank=True, default='#4361ee', help_text='Hex colour for UI accent')

    class Meta:
        verbose_name_plural = 'Inventory Categories'
        unique_together     = [('admin', 'name')]
        ordering            = ['name']

    def __str__(self):
        return self.name


# ──────────────────────────────────────────────────────────────────────────────
# INVENTORY ITEM
# ──────────────────────────────────────────────────────────────────────────────

class InventoryItem(models.Model):
    UNIT_CHOICES = [
        ('pcs', 'Pieces'), ('ltr', 'Litres'), ('kg', 'Kilograms'), ('g', 'Grams'),
        ('m', 'Metres'), ('box', 'Box'), ('pair', 'Pair'), ('set', 'Set'),
        ('roll', 'Roll'), ('pack', 'Pack'),
    ]

    admin    = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='inventory_items')
    category = models.ForeignKey(InventoryCategory, on_delete=models.SET_NULL, null=True, blank=True, related_name='items')
    can_type = models.OneToOneField(
        'accounts.CanType', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='inventory_item',
        help_text='Link to a CanType to enable auto-deduction on deliveries'
    )

    name             = models.CharField(max_length=200)
    sku              = models.CharField(max_length=50, blank=True, default='', help_text='Stock Keeping Unit / barcode')
    description      = models.TextField(blank=True, default='')
    unit             = models.CharField(max_length=10, choices=UNIT_CHOICES, default='pcs')

    current_stock    = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    low_stock_alert  = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('10.00'))
    reorder_quantity = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('50.00'))

    avg_unit_cost    = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    cost_price       = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text='COGS per unit; used when recording inventory sales.'
    )

    is_active                = models.BooleanField(default=True)
    track_stock              = models.BooleanField(default=True)
    auto_deduct_on_delivery  = models.BooleanField(default=False, help_text='Auto-deduct 1 unit per can delivered (only when linked to CanType)')

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering        = ['name']
        unique_together = [('admin', 'name')]

    def __str__(self):
        return f"{self.name} ({self.current_stock} {self.unit})"

    @property
    def is_low_stock(self):
        return self.current_stock <= self.low_stock_alert

    @property
    def stock_value(self):
        return (self.current_stock * self.avg_unit_cost).quantize(Decimal('0.01'))

    def _recalc_avg_cost(self):
        movements  = self.movements.filter(movement_type='in').order_by('date', 'id')
        total_qty  = Decimal('0')
        total_cost = Decimal('0')
        for m in movements:
            total_qty  += m.quantity
            total_cost += m.quantity * (m.unit_cost or Decimal('0'))
        if total_qty > 0:
            self.avg_unit_cost = (total_cost / total_qty).quantize(Decimal('0.0001'))
        else:
            self.avg_unit_cost = Decimal('0.00')

    def recalculate_stock(self):
        agg = self.movements.aggregate(
            total_in  = Sum('quantity', filter=Q(movement_type='in')),
            total_out = Sum('quantity', filter=Q(movement_type='out')),
            total_adj = Sum('quantity', filter=Q(movement_type='adjustment')),
        )
        total_in  = agg['total_in']  or Decimal('0')
        total_out = agg['total_out'] or Decimal('0')
        total_adj = agg['total_adj'] or Decimal('0')
        self.current_stock = total_in - total_out + total_adj
        self._recalc_avg_cost()
        InventoryItem.objects.filter(pk=self.pk).update(
            current_stock=self.current_stock,
            avg_unit_cost=self.avg_unit_cost,
        )


# ──────────────────────────────────────────────────────────────────────────────
# STOCK MOVEMENT
# ──────────────────────────────────────────────────────────────────────────────

class StockMovement(models.Model):
    MOVEMENT_TYPES = [
        ('in', 'Stock In  (Purchase / Return)'),
        ('out', 'Stock Out (Delivery / Consumption)'),
        ('adjustment', 'Adjustment'),
        ('transfer', 'Internal Transfer'),
        ('opening', 'Opening Balance'),
    ]
    REASON_CHOICES = [
        ('purchase', 'Purchase from Supplier'),
        ('customer_return', 'Customer Return (empty can)'),
        ('production', 'Production / Refill'),
        ('opening_balance', 'Opening Balance'),
        ('delivery', 'Customer Delivery'),
        ('sale', 'Inventory Sale'),
        ('damaged', 'Damaged / Waste'),
        ('expired', 'Expired'),
        ('internal_use', 'Internal Use'),
        ('count_correction', 'Physical Count Correction'),
        ('other', 'Other'),
    ]

    admin          = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='stock_movements')
    item           = models.ForeignKey(InventoryItem, on_delete=models.CASCADE, related_name='movements')
    supplier       = models.ForeignKey(Supplier, on_delete=models.SET_NULL, null=True, blank=True, related_name='movements')
    delivery       = models.ForeignKey('accounts.DailyDelivery', on_delete=models.SET_NULL, null=True, blank=True, related_name='stock_movements')
    purchase_order = models.ForeignKey('PurchaseOrder', on_delete=models.SET_NULL, null=True, blank=True, related_name='movements')

    movement_type = models.CharField(max_length=20, choices=MOVEMENT_TYPES)
    reason        = models.CharField(max_length=30, choices=REASON_CHOICES, default='other')
    quantity      = models.DecimalField(max_digits=12, decimal_places=2)
    unit_cost     = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    balance_after = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))

    date      = models.DateField(default=timezone.now)
    notes     = models.TextField(blank=True, default='')
    reference = models.CharField(max_length=100, blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['date', 'id']
        indexes  = [
            models.Index(fields=['item', 'date']),
            models.Index(fields=['admin', 'date']),
        ]

    def __str__(self):
        direction = '+' if self.movement_type in ('in', 'opening') else ('±' if self.movement_type == 'adjustment' else '-')
        return f"{self.item.name} {direction}{self.quantity} [{self.get_movement_type_display()}] {self.date}"

    @property
    def signed_quantity(self):
        if self.movement_type in ('in', 'opening'):
            return self.quantity
        elif self.movement_type == 'out':
            return -self.quantity
        return self.quantity

    def save(self, *args, **kwargs):
        from django.db import transaction as db_transaction

        if not self.item_id:
            raise ValidationError('StockMovement must be linked to an InventoryItem.')

        with db_transaction.atomic():
            base_qs = StockMovement.objects.select_for_update().filter(item=self.item, admin=self.admin)

            if self.pk:
                prev = base_qs.exclude(pk=self.pk).filter(
                    Q(date__lt=self.date) | Q(date=self.date, id__lt=self.pk)
                ).order_by('-date', '-id').first()
            else:
                prev = base_qs.filter(date__lte=self.date).order_by('-date', '-id').first()

            prev_balance = prev.balance_after if prev else Decimal('0')

            if self.movement_type in ('in', 'opening'):
                new_balance = prev_balance + self.quantity
            elif self.movement_type == 'out':
                new_balance = prev_balance - self.quantity
            else:
                new_balance = prev_balance + self.quantity

            self.balance_after = new_balance
            super().save(*args, **kwargs)

            later = base_qs.exclude(pk=self.pk).filter(
                Q(date__gt=self.date) | Q(date=self.date, id__gt=self.pk)
            ).order_by('date', 'id')

            cur = new_balance
            for m in later:
                if m.movement_type in ('in', 'opening'):
                    cur = cur + m.quantity
                elif m.movement_type == 'out':
                    cur = cur - m.quantity
                else:
                    cur = cur + m.quantity
                if m.balance_after != cur:
                    StockMovement.objects.filter(pk=m.pk).update(balance_after=cur)

            final_balance = cur if later.exists() else new_balance
            InventoryItem.objects.filter(pk=self.item_id).update(current_stock=final_balance)

            if self.movement_type in ('in', 'opening', 'purchase'):
                self.item.refresh_from_db()
                self.item._recalc_avg_cost()
                InventoryItem.objects.filter(pk=self.item_id).update(avg_unit_cost=self.item.avg_unit_cost)


# ──────────────────────────────────────────────────────────────────────────────
# PURCHASE ORDER
# ──────────────────────────────────────────────────────────────────────────────

class PurchaseOrder(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'), ('ordered', 'Ordered'), ('received', 'Received'),
        ('partial', 'Partially Received'), ('cancelled', 'Cancelled'),
    ]

    admin         = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='purchase_orders')
    supplier      = models.ForeignKey(Supplier, on_delete=models.SET_NULL, null=True, blank=True, related_name='purchase_orders')
    po_number     = models.CharField(max_length=50, unique=True)
    status        = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    order_date    = models.DateField(default=timezone.now)
    expected_date = models.DateField(null=True, blank=True)
    received_date = models.DateField(null=True, blank=True)
    total_cost    = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))
    notes         = models.TextField(blank=True, default='')
    created_at    = models.DateTimeField(auto_now_add=True)
    updated_at    = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-order_date', '-id']

    def __str__(self):
        return f"PO-{self.po_number} ({self.get_status_display()})"

    def _recalc_total(self):
        total = self.lines.aggregate(
            t=Sum(models.ExpressionWrapper(
                models.F('quantity') * models.F('unit_cost'),
                output_field=models.DecimalField()
            ))
        )['t'] or Decimal('0.00')
        self.total_cost = total
        PurchaseOrder.objects.filter(pk=self.pk).update(total_cost=total)

    def receive(self, received_date=None):
        from django.utils import timezone as tz
        self.received_date = received_date or tz.now().date()
        self.status = 'received'
        self.save()
        for line in self.lines.all():
            StockMovement.objects.create(
                admin=self.admin, item=line.item, supplier=self.supplier,
                purchase_order=self, movement_type='in', reason='purchase',
                quantity=line.quantity, unit_cost=line.unit_cost,
                date=self.received_date, notes=f"PO #{self.po_number} received",
                reference=self.po_number,
            )


class PurchaseOrderLine(models.Model):
    purchase_order = models.ForeignKey(PurchaseOrder, on_delete=models.CASCADE, related_name='lines')
    item           = models.ForeignKey(InventoryItem, on_delete=models.CASCADE, related_name='po_lines')
    quantity       = models.DecimalField(max_digits=10, decimal_places=2)
    unit_cost      = models.DecimalField(max_digits=10, decimal_places=2)
    received_qty   = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))

    class Meta:
        unique_together = [('purchase_order', 'item')]

    @property
    def line_total(self):
        return (self.quantity * self.unit_cost).quantize(Decimal('0.01'))

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self.purchase_order._recalc_total()

    def __str__(self):
        return f"{self.item.name} × {self.quantity}"


# ──────────────────────────────────────────────────────────────────────────────
# STOCK ALERT
# ──────────────────────────────────────────────────────────────────────────────

class StockAlert(models.Model):
    admin          = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='stock_alerts')
    item           = models.ForeignKey(InventoryItem, on_delete=models.CASCADE, related_name='alerts')
    stock_at_alert = models.DecimalField(max_digits=12, decimal_places=2)
    acknowledged   = models.BooleanField(default=False)
    created_at     = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Alert: {self.item.name} @ {self.stock_at_alert} ({self.created_at.date()})"


# ──────────────────────────────────────────────────────────────────────────────
# INVENTORY RECEIVABLE
# Must be defined BEFORE InventorySale because InventorySale has a FK to it.
# ──────────────────────────────────────────────────────────────────────────────

class InventoryReceivable(models.Model):
    """
    Tracks the outstanding balance for a credit / partial inventory sale.

    FIX: The original code tried to create an accounts.ReceivableLedger entry
    inside InventoryReceivable.save(), but:
      - self.admin.shop raises AttributeError  (User has shop_admin OneToOne, not .shop)
      - It violated ReceivableLedger unique_together on (delivery=None, transaction_type)
      - The shop can reliably be obtained only when a Customer is linked

    The ReceivableLedger hit is now handled in InventorySale.save() where we
    have a confirmed customer with a shop. InventoryReceivable.save() only
    manages its own status transitions.
    """
    STATUS_CHOICES = [
        ('open', 'Open'), ('partial', 'Partially Paid'),
        ('settled', 'Settled'), ('written_off', 'Written Off'),
    ]

    admin          = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='inventory_receivables')
    customer       = models.ForeignKey(
        'accounts.Customer', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='inventory_receivables'
    )
    # NOTE: 'sale' reverse-relation is defined via InventorySale.receivable_entry OneToOne below.
    customer_name  = models.CharField(max_length=200, blank=True, default='')
    customer_phone = models.CharField(max_length=30, blank=True, default='')
    total_amount   = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))
    amount_paid    = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))
    due_date       = models.DateField(null=True, blank=True)
    status         = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    notes          = models.TextField(blank=True, default='')
    created_at     = models.DateTimeField(auto_now_add=True)
    updated_at     = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        indexes  = [models.Index(fields=['admin', 'status'])]

    @property
    def balance_due(self):
        return max(self.total_amount - self.amount_paid, Decimal('0'))

    @property
    def is_overdue(self):
        return bool(self.due_date and timezone.now().date() > self.due_date and self.balance_due > 0)

    def save(self, *args, **kwargs):
        # Auto-update status only — ReceivableLedger is handled by InventorySale.save()
        if self.balance_due <= 0:
            self.status = 'settled'
        elif self.amount_paid > 0:
            self.status = 'partial'
        else:
            self.status = 'open'
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Receivable #{self.id} — {self.customer_name or (self.customer.display_name if self.customer else 'Unknown')} — Due: {self.balance_due}"


# ──────────────────────────────────────────────────────────────────────────────
# INVENTORY SALE  (single authoritative definition)
#
# FIX SUMMARY vs the original file:
#   - Removed duplicate first InventorySale class entirely.
#   - Added `customer = ForeignKey(accounts.Customer)` — was missing in the
#     second (active) definition, causing crashes in sale_create view.
#   - Removed `customer_name` / `customer_phone` free-text fields — customer
#     is now mandatory (FK), not optional walk-in text.
#   - save() now:
#       a) Always creates an InventoryInvoice for every completed sale.
#       b) Hits accounts.ReceivableLedger when customer is set and balance > 0.
#       c) Hits InventoryReceivable for the inventory-side tracking.
# ──────────────────────────────────────────────────────────────────────────────

class InventorySale(models.Model):
    PAYMENT_METHOD_CHOICES = [
        ('cash', 'Cash'), ('bank', 'Bank Transfer'),
        ('cheque', 'Cheque'), ('credit', 'Credit (Receivable)'), ('other', 'Other'),
    ]
    STATUS_CHOICES = [
        ('pending', 'Pending / Unpaid'), ('completed', 'Completed'),
        ('cancelled', 'Cancelled'), ('returned', 'Returned'),
    ]

    admin    = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='inventory_sales')
    item     = models.ForeignKey(InventoryItem, on_delete=models.PROTECT, related_name='sales')

    # Customer is MANDATORY — no walk-in free-text fields.
    customer = models.ForeignKey(
        'accounts.Customer', on_delete=models.PROTECT,
        related_name='inventory_sales',
        help_text='Customer must be selected from the accounts customer list.'
    )

    quantity        = models.DecimalField(max_digits=12, decimal_places=2)
    unit_price      = models.DecimalField(max_digits=10, decimal_places=2)
    cost_price      = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'),
                                          help_text='Avg cost at time of sale — populated automatically')

    total_amount    = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))
    total_cost      = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))
    gross_profit    = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))

    payment_method  = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, default='cash')
    payment_status  = models.CharField(
        max_length=20,
        choices=[('paid', 'Paid'), ('unpaid', 'Unpaid'), ('partial', 'Partial')],
        default='paid'
    )
    amount_received = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))

    status     = models.CharField(max_length=20, choices=STATUS_CHOICES, default='completed')
    sale_date  = models.DateField(default=timezone.now)
    notes      = models.TextField(blank=True, default='')
    reference  = models.CharField(max_length=100, blank=True, default='')

    stock_movement   = models.OneToOneField(
        StockMovement, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sale'
    )
    receivable_entry = models.OneToOneField(
        InventoryReceivable, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sale'
    )
    # Invoice created for every completed sale
    invoice = models.OneToOneField(
        'InventoryInvoice', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='sale'
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-sale_date', '-id']
        indexes  = [
            models.Index(fields=['admin', 'sale_date']),
            models.Index(fields=['item', 'sale_date']),
            models.Index(fields=['admin', 'status']),
        ]

    def __str__(self):
        return f"Sale #{self.id} — {self.item.name} ×{self.quantity} @ {self.unit_price} [{self.sale_date}]"

    @property
    def profit_margin_pct(self):
        if self.total_amount and self.total_amount > 0:
            return round(float(self.gross_profit) / float(self.total_amount) * 100, 1)
        return 0.0

    @property
    def balance_due(self):
        return max(self.total_amount - self.amount_received, Decimal('0'))

    def save(self, *args, **kwargs):
        from django.db import transaction as db_tx

        if not self.customer_id:
            raise ValidationError('InventorySale requires a customer.')

        # Snapshot cost on creation
        if not self.pk:
            self.cost_price = (
                self.item.cost_price
                if getattr(self.item, 'cost_price', None) is not None
                else self.item.avg_unit_cost or Decimal('0')
            )

        self.total_amount = (self.quantity * self.unit_price).quantize(Decimal('0.01'))
        self.total_cost   = (self.quantity * self.cost_price).quantize(Decimal('0.01'))
        self.gross_profit = (self.total_amount - self.total_cost).quantize(Decimal('0.01'))

        with db_tx.atomic():
            is_new = not self.pk
            super().save(*args, **kwargs)

            # ── 1. Stock movement ─────────────────────────────────────────
            if self.status == 'completed':
                if is_new:
                    mv = StockMovement.objects.create(
                        admin=self.admin, item=self.item,
                        movement_type='out', reason='sale',
                        quantity=self.quantity, date=self.sale_date,
                        notes=f"Sale #{self.id} — {self.customer.display_name}",
                        reference=self.reference or str(self.id),
                    )
                    InventorySale.objects.filter(pk=self.pk).update(stock_movement=mv)
                    self.stock_movement = mv
                elif self.stock_movement:
                    mv = self.stock_movement
                    if mv.quantity != self.quantity or mv.date != self.sale_date:
                        mv.quantity = self.quantity
                        mv.date     = self.sale_date
                        mv.save()

            elif self.status in ('cancelled', 'returned') and self.stock_movement:
                mv = self.stock_movement
                InventorySale.objects.filter(pk=self.pk).update(stock_movement=None)
                self.stock_movement = None
                mv.delete()

            # ── 2. Always create an InventoryInvoice for new completed sales ──
            if is_new and self.status == 'completed':
                inv_num = f"INV-{timezone.now().strftime('%Y%m')}-{str(_uuid_module.uuid4())[:6].upper()}"
                inv_status = 'paid' if self.balance_due <= 0 else ('partial' if self.amount_received > 0 else 'unpaid')
                inv = InventoryInvoice.objects.create(
                    admin=self.admin,
                    invoice_number=inv_num,
                    customer=self.customer,
                    customer_name=self.customer.display_name,
                    customer_phone=self.customer.phone_number or '',
                    customer_email=self.customer.email or '',
                    customer_address=self.customer.full_address or '',
                    issue_date=self.sale_date,
                    due_date=self.sale_date if self.balance_due <= 0 else (
                        self.sale_date.replace(day=1) if False else
                        _add_days(self.sale_date, 30)
                    ),
                    subtotal=self.total_amount,
                    total_amount=self.total_amount,
                    amount_paid=self.amount_received,
                    status=inv_status,
                    notes=self.notes,
                    reference=self.reference,
                )
                InventoryInvoiceLine.objects.create(
                    invoice=inv, sale=self, item=self.item,
                    description=f"{self.item.name} ({self.item.unit})",
                    quantity=self.quantity, unit_price=self.unit_price,
                )
                InventorySale.objects.filter(pk=self.pk).update(invoice=inv)
                self.invoice = inv

            # ── 3. InventoryReceivable for outstanding balance ─────────────
            balance_due = self.total_amount - self.amount_received
            if self.status == 'completed' and balance_due > 0:
                if is_new:
                    rec = InventoryReceivable.objects.create(
                        admin=self.admin,
                        customer=self.customer,
                        customer_name=self.customer.display_name,
                        customer_phone=self.customer.phone_number or '',
                        total_amount=self.total_amount,
                        amount_paid=self.amount_received,
                        due_date=_add_days(self.sale_date, 30),
                        notes=f"Inventory Sale #{self.id}",
                    )
                    InventorySale.objects.filter(pk=self.pk).update(receivable_entry=rec)
                    self.receivable_entry = rec
                elif self.receivable_entry:
                    rec = self.receivable_entry
                    rec.total_amount = self.total_amount
                    rec.amount_paid  = self.amount_received
                    rec.save()
            elif self.status in ('cancelled', 'returned') and self.receivable_entry:
                self.receivable_entry.delete()
                InventorySale.objects.filter(pk=self.pk).update(receivable_entry=None)
                self.receivable_entry = None

            # ── 4. Hit accounts.ReceivableLedger when balance > 0 ────────
            #
            # Only on new completed sales with an outstanding balance.
            # We use transaction_type='delivery' (debit entry) so the customer's
            # running balance increases — matching how DailyDelivery entries work.
            #
            # IMPORTANT: ReceivableLedger has unique_together on
            #   (delivery, transaction_type) and (payment, transaction_type).
            # We leave both delivery and payment NULL here, which means we CANNOT
            # use get_or_create safely when both are NULL (DB nulls aren't equal).
            # We therefore use a notes-based guard to avoid duplicates.
            if is_new and self.status == 'completed' and balance_due > 0:
                try:
                    from accounts.models import ReceivableLedger
                    shop = self.customer.shop
                    desc = f"Inventory Sale #{self.id} — {self.item.name} ×{self.quantity}"
                    # Prevent duplicate entries if save() is somehow called twice
                    already_exists = ReceivableLedger.objects.filter(
                        customer=self.customer,
                        admin=self.admin,
                        description=desc,
                    ).exists()
                    if not already_exists:
                        ReceivableLedger.objects.create(
                            admin=self.admin,
                            shop=shop,
                            customer=self.customer,
                            date=self.sale_date,
                            transaction_type='delivery',  # debit = customer owes us
                            debit=balance_due,
                            credit=Decimal('0.00'),
                            description=desc,
                            notes=f"Auto-created from InventorySale #{self.id}",
                        )
                except Exception as e:
                    import logging
                    logging.getLogger(__name__).warning(f"[InventorySale] ReceivableLedger entry failed: {e}")


def _add_days(d, n):
    """Helper to add n days to a date — avoids importing timedelta everywhere."""
    from datetime import timedelta
    return d + timedelta(days=n)


# ──────────────────────────────────────────────────────────────────────────────
# INVENTORY INVOICE
# ──────────────────────────────────────────────────────────────────────────────

class InventoryInvoice(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'), ('sent', 'Sent'), ('unpaid', 'Unpaid'),
        ('partial', 'Partially Paid'), ('paid', 'Paid'),
        ('overdue', 'Overdue'), ('cancelled', 'Cancelled'),
    ]

    admin          = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='inventory_invoices')
    invoice_number = models.CharField(max_length=60, unique=True, blank=True)

    # Customer is mandatory — no walk-in free-text (except for display caching)
    customer = models.ForeignKey(
        'accounts.Customer', on_delete=models.PROTECT,
        related_name='inventory_invoices',
        help_text='Must be a registered customer.'
    )
    # Cached display fields (populated from customer on save)
    customer_name    = models.CharField(max_length=200, blank=True, default='')
    customer_phone   = models.CharField(max_length=30, blank=True, default='')
    customer_email   = models.EmailField(blank=True, default='')
    customer_address = models.TextField(blank=True, default='')

    issue_date      = models.DateField(default=timezone.now)
    due_date        = models.DateField(null=True, blank=True)
    status          = models.CharField(max_length=20, choices=STATUS_CHOICES, default='unpaid')

    subtotal        = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))
    discount_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))
    tax_amount      = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))
    total_amount    = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))
    amount_paid     = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))

    notes     = models.TextField(blank=True, default='')
    terms     = models.TextField(blank=True, default='')
    reference = models.CharField(max_length=100, blank=True, default='')

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-issue_date', '-id']
        indexes  = [
            models.Index(fields=['admin', 'status']),
            models.Index(fields=['admin', 'issue_date']),
            models.Index(fields=['customer', 'issue_date']),
        ]

    def __str__(self):
        return f"INV-{self.invoice_number} ({self.get_status_display()})"

    @property
    def balance_due(self):
        return max(self.total_amount - self.amount_paid, Decimal('0'))

    @property
    def is_overdue(self):
        if self.due_date and self.balance_due > 0:
            return timezone.now().date() > self.due_date
        return False

    def recalculate_totals(self):
        lines     = self.lines.all()
        sub       = sum(ln.line_total for ln in lines)
        self.subtotal     = sub
        self.total_amount = max(sub - self.discount_amount + self.tax_amount, Decimal('0'))
        InventoryInvoice.objects.filter(pk=self.pk).update(
            subtotal=self.subtotal, total_amount=self.total_amount,
        )

    def update_status(self):
        if self.status == 'cancelled':
            return
        paid  = self.amount_paid
        total = self.total_amount
        if paid >= total and total > 0:
            self.status = 'paid'
        elif paid > 0:
            self.status = 'partial'
        elif self.due_date and timezone.now().date() > self.due_date:
            self.status = 'overdue'
        else:
            self.status = 'unpaid'
        InventoryInvoice.objects.filter(pk=self.pk).update(status=self.status)

    def record_payment(self, amount, method='cash', notes='', payment_date=None):
        from django.db import transaction as db_tx
        with db_tx.atomic():
            pay = InventoryInvoicePayment.objects.create(
                invoice=self, admin=self.admin, amount=amount,
                method=method, notes=notes,
                payment_date=payment_date or timezone.now().date(),
            )
            new_paid = self.amount_paid + amount
            InventoryInvoice.objects.filter(pk=self.pk).update(amount_paid=new_paid)
            self.amount_paid = new_paid
            self.update_status()
            # Sync linked sale's receivable
            try:
                sale = self.sale  # reverse OneToOne from InventorySale.invoice
                if sale and sale.receivable_entry:
                    rec = sale.receivable_entry
                    rec.amount_paid = min(rec.total_amount, rec.amount_paid + amount)
                    rec.save()
            except Exception:
                pass
            return pay

    def save(self, *args, **kwargs):
        # Sync customer display fields from the FK
        if self.customer_id:
            try:
                c = self.customer
                self.customer_name    = c.display_name
                self.customer_phone   = c.phone_number or ''
                self.customer_email   = c.email or ''
                self.customer_address = c.full_address or ''
            except Exception:
                pass
        if not self.invoice_number:
            self.invoice_number = f"{timezone.now().strftime('%Y%m')}-{str(_uuid_module.uuid4())[:6].upper()}"
        super().save(*args, **kwargs)


class InventoryInvoiceLine(models.Model):
    invoice     = models.ForeignKey(InventoryInvoice, on_delete=models.CASCADE, related_name='lines')
    sale        = models.ForeignKey(InventorySale, on_delete=models.SET_NULL, null=True, blank=True, related_name='invoice_lines')
    item        = models.ForeignKey(InventoryItem, on_delete=models.PROTECT, null=True, blank=True, related_name='invoice_lines')
    description = models.CharField(max_length=300)
    quantity    = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('1'))
    unit_price  = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0'))
    line_total  = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))

    class Meta:
        ordering = ['id']

    def save(self, *args, **kwargs):
        self.line_total = (self.quantity * self.unit_price).quantize(Decimal('0.01'))
        super().save(*args, **kwargs)
        self.invoice.recalculate_totals()

    def __str__(self):
        return f"{self.description} × {self.quantity} @ {self.unit_price}"


class InventoryInvoicePayment(models.Model):
    METHODS = [
        ('cash', 'Cash'), ('bank', 'Bank Transfer'),
        ('cheque', 'Cheque'), ('other', 'Other'),
    ]
    invoice      = models.ForeignKey(InventoryInvoice, on_delete=models.CASCADE, related_name='payments')
    admin        = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    amount       = models.DecimalField(max_digits=14, decimal_places=2)
    method       = models.CharField(max_length=20, choices=METHODS, default='cash')
    notes        = models.TextField(blank=True, default='')
    payment_date = models.DateField(default=timezone.now)
    created_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-payment_date', '-id']

    def __str__(self):
        return f"Payment {self.amount} on {self.payment_date} for {self.invoice}"