# ================================================================================
# inventory/views.py  — CORRECTED
#
# Key fixes vs the original:
#   1. Removed duplicate sale_create — only one definition with correct logic.
#   2. Customer is MANDATORY everywhere — no walk-in free-text fallback.
#   3. sale_create always creates an InventoryInvoice (via InventorySale.save()).
#   4. invoice_create records an InventorySale for every line item with an item FK.
#   5. customer.full_address used instead of the broken customer.address shim.
#   6. All customer dropdowns use live-search via customer_search AJAX endpoint.
#   7. invoice_create / invoice_edit enforce customer FK (no anonymous invoices).
# ================================================================================

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse
from django.utils.translation import gettext as _
from django.db.models import Sum, Q, F, ExpressionWrapper, DecimalField, Count
from django.utils import timezone
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.db import transaction
from django.core.paginator import Paginator
from decimal import Decimal, InvalidOperation
import datetime

from accounts.models import Customer
from .models import (
    Supplier, InventoryCategory, InventoryItem,
    StockMovement, PurchaseOrder, PurchaseOrderLine, StockAlert,
    InventorySale, InventoryInvoice, InventoryInvoiceLine,
    InventoryInvoicePayment, InventoryReceivable,
)


# ──────────────────────────────────────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────────────────────────────────────

def _get_admin(request):
    user = request.user
    if getattr(user, 'role', None) == 'staff':
        try:
            from accounts.models import Staff
            return Staff.objects.get(user=user).admin
        except Exception:
            pass
    return user


def _shop_admin_required(view_fn):
    from functools import wraps
    @wraps(view_fn)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login')
        role = getattr(request.user, 'role', '')
        if role not in ('shop_admin', 'super_admin'):
            messages.error(request, _('Access denied.'))
            return redirect('admin_dashboard')
        return view_fn(request, *args, **kwargs)
    return wrapper


def _get_customers_qs(admin):
    """Shared helper — all active customers for this admin's shop."""
    return (
        Customer.objects
        .filter(shop__admin=admin, is_deleted=False, is_active=True)
        .order_by('company_name', 'first_name', 'last_name')
    )


# ══════════════════════════════════════════════════════════════════════════════
# CUSTOMER LIVE-SEARCH  (AJAX — used by every dropdown in this module)
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def customer_search(request):
    """
    GET ?q=<query>&limit=<int>
    Returns JSON list of matching customers for the live-search widget.
    Walk-in / anonymous customers are NOT returned — registered only.
    """
    admin = _get_admin(request)
    q     = request.GET.get('q', '').strip()
    limit = min(int(request.GET.get('limit', 12)), 30)

    if len(q) < 2:
        return JsonResponse({'customers': []})

    qs = (
        _get_customers_qs(admin)
        .filter(
            Q(first_name__icontains=q)   |
            Q(last_name__icontains=q)    |
            Q(company_name__icontains=q) |
            Q(phone_number__icontains=q) |
            Q(customer_code__icontains=q)|
            Q(area__icontains=q)
        )[:limit]
    )

    return JsonResponse({'customers': [
        {
            'id':      c.id,
            'name':    c.display_name,
            'phone':   c.phone_number or '',
            'area':    c.area or '',
            'city':    c.city or '',
            'type':    c.get_customer_type_display() if hasattr(c, 'get_customer_type_display') else '',
            'balance': str(c.outstanding_balance or '0.00'),
            'code':    c.customer_code or '',
        }
        for c in qs
    ]})


# ══════════════════════════════════════════════════════════════════════════════
# DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def inventory_dashboard(request):
    admin = _get_admin(request)
    items = InventoryItem.objects.filter(admin=admin, is_active=True)

    total_items     = items.count()
    low_stock_items = items.filter(current_stock__lte=F('low_stock_alert'))
    out_of_stock    = items.filter(current_stock__lte=0)

    total_value = items.annotate(
        val=ExpressionWrapper(F('current_stock') * F('avg_unit_cost'), output_field=DecimalField())
    ).aggregate(total=Sum('val'))['total'] or Decimal('0.00')

    recent_movements = StockMovement.objects.filter(admin=admin).order_by('-date', '-id')[:10]
    open_pos         = PurchaseOrder.objects.filter(admin=admin, status__in=['draft', 'ordered', 'partial'])
    alerts           = StockAlert.objects.filter(admin=admin, acknowledged=False)

    categories = InventoryCategory.objects.filter(admin=admin)
    cat_data = []
    for cat in categories:
        cat_items = items.filter(category=cat)
        cat_value = cat_items.annotate(
            val=ExpressionWrapper(F('current_stock') * F('avg_unit_cost'), output_field=DecimalField())
        ).aggregate(t=Sum('val'))['t'] or 0
        cat_data.append({'name': cat.name, 'value': float(cat_value), 'color': cat.color})

    thirty_days_ago = timezone.now().date() - datetime.timedelta(days=30)
    total_in_30  = StockMovement.objects.filter(admin=admin, movement_type='in',  date__gte=thirty_days_ago).aggregate(t=Sum('quantity'))['t'] or 0
    total_out_30 = StockMovement.objects.filter(admin=admin, movement_type='out', date__gte=thirty_days_ago).aggregate(t=Sum('quantity'))['t'] or 0

    import json
    ctx = {
        'total_items': total_items, 'low_stock_items': low_stock_items,
        'out_of_stock': out_of_stock, 'total_value': total_value,
        'recent_movements': recent_movements, 'open_pos': open_pos,
        'alerts': alerts, 'cat_data_json': json.dumps(cat_data),
        'total_in_30': total_in_30, 'total_out_30': total_out_30,
    }
    return render(request, 'inventory/dashboard.html', ctx)


# ══════════════════════════════════════════════════════════════════════════════
# INVENTORY ITEMS
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def item_list(request):
    admin = _get_admin(request)
    qs    = InventoryItem.objects.filter(admin=admin).select_related('category').order_by('name')

    search = request.GET.get('search', '').strip()
    cat_id = request.GET.get('category', '')
    status = request.GET.get('status', '')

    if search:
        qs = qs.filter(Q(name__icontains=search) | Q(sku__icontains=search))
    if cat_id:
        qs = qs.filter(category_id=cat_id)
    if status == 'low':
        qs = qs.filter(current_stock__lte=F('low_stock_alert'), current_stock__gt=0)
    elif status == 'out':
        qs = qs.filter(current_stock__lte=0)
    elif status == 'ok':
        qs = qs.filter(current_stock__gt=F('low_stock_alert'))
    elif status == 'inactive':
        qs = qs.filter(is_active=False)

    paginator = Paginator(qs, 25)
    page      = paginator.get_page(request.GET.get('page', 1))
    categories = InventoryCategory.objects.filter(admin=admin)
    ctx = {'items': page, 'categories': categories, 'search': search, 'cat_id': cat_id, 'status': status}
    return render(request, 'inventory/item_list.html', ctx)


@_shop_admin_required
def item_create(request):
    admin      = _get_admin(request)
    categories = InventoryCategory.objects.filter(admin=admin)

    if request.method == 'POST':
        name        = request.POST.get('name', '').strip()
        sku         = request.POST.get('sku', '').strip()
        cat_id      = request.POST.get('category', '')
        unit        = request.POST.get('unit', 'pcs')
        desc        = request.POST.get('description', '').strip()
        low_alert   = request.POST.get('low_stock_alert', '10')
        reorder_q   = request.POST.get('reorder_quantity', '50')
        cost_p      = request.POST.get('cost_price', '').strip()
        track_stock = request.POST.get('track_stock') == 'on'
        opening_qty  = request.POST.get('opening_qty', '0').strip()
        opening_cost = request.POST.get('opening_cost', '0').strip()

        if not name:
            messages.error(request, 'Item name is required.')
            return redirect('inventory_item_create')
        if InventoryItem.objects.filter(admin=admin, name__iexact=name).exists():
            messages.error(request, f'An item named "{name}" already exists.')
            return redirect('inventory_item_create')

        try:
            item = InventoryItem.objects.create(
                admin=admin, name=name, sku=sku,
                category_id=int(cat_id) if cat_id else None,
                unit=unit, description=desc,
                low_stock_alert=Decimal(low_alert or '10'),
                reorder_quantity=Decimal(reorder_q or '50'),
                cost_price=Decimal(cost_p) if cost_p else None,
                track_stock=track_stock,
            )
            opening_qty_d = Decimal(opening_qty or '0')
            if opening_qty_d > 0:
                StockMovement.objects.create(
                    admin=admin, item=item, movement_type='opening',
                    reason='opening_balance', quantity=opening_qty_d,
                    unit_cost=Decimal(opening_cost or '0'),
                    date=timezone.now().date(), notes='Opening stock balance',
                )
            messages.success(request, f'Item "{name}" created successfully.')
            return redirect('inventory_item_list')
        except Exception as e:
            messages.error(request, f'Error creating item: {e}')
            return redirect('inventory_item_create')

    ctx = {'categories': categories, 'unit_choices': InventoryItem.UNIT_CHOICES}
    return render(request, 'inventory/item_form.html', ctx)


@_shop_admin_required
def item_edit(request, pk):
    admin = _get_admin(request)
    item  = get_object_or_404(InventoryItem, pk=pk, admin=admin)
    categories = InventoryCategory.objects.filter(admin=admin)
    from accounts.models import CanType
    can_types = CanType.objects.filter(admin=admin, enabled=True).filter(
        Q(inventory_item__isnull=True) | Q(inventory_item=item)
    )

    if request.method == 'POST':
        item.name        = request.POST.get('name', item.name).strip()
        item.sku         = request.POST.get('sku', '').strip()
        item.unit        = request.POST.get('unit', item.unit)
        item.description = request.POST.get('description', '').strip()
        cat_id           = request.POST.get('category', '')
        item.category_id = int(cat_id) if cat_id else None
        try:
            item.low_stock_alert  = Decimal(request.POST.get('low_stock_alert') or '10')
            item.reorder_quantity = Decimal(request.POST.get('reorder_quantity') or '50')
        except InvalidOperation:
            messages.error(request, 'Invalid numeric value.')
            return redirect('inventory_item_edit', pk=pk)
        cp = request.POST.get('cost_price', '').strip()
        item.cost_price = Decimal(cp) if cp else None
        ct_id = request.POST.get('can_type', '')
        item.can_type_id = int(ct_id) if ct_id else None
        item.auto_deduct_on_delivery = bool(request.POST.get('auto_deduct_on_delivery'))
        item.track_stock = bool(request.POST.get('track_stock'))
        item.is_active   = bool(request.POST.get('is_active'))
        item.save()
        messages.success(request, f'Item "{item.name}" updated.')
        return redirect('inventory_item_list')

    ctx = {'item': item, 'categories': categories, 'can_types': can_types,
           'unit_choices': InventoryItem.UNIT_CHOICES}
    return render(request, 'inventory/item_form.html', ctx)


@_shop_admin_required
@require_POST
def item_delete(request, pk):
    admin = _get_admin(request)
    item  = get_object_or_404(InventoryItem, pk=pk, admin=admin)
    if item.movements.exists():
        item.is_active = False
        item.save(update_fields=['is_active'])
        messages.warning(request, f'"{item.name}" has movement history — deactivated instead of deleted.')
    else:
        name = item.name
        item.delete()
        messages.success(request, f'Item "{name}" deleted.')
    return redirect('inventory_item_list')


# ══════════════════════════════════════════════════════════════════════════════
# STOCK MOVEMENTS
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def movement_list(request):
    admin = _get_admin(request)
    qs = StockMovement.objects.filter(admin=admin).select_related('item', 'supplier').order_by('-date', '-id')

    item_id   = request.GET.get('item', '')
    move_type = request.GET.get('type', '')
    from_date = request.GET.get('from_date', '')
    to_date   = request.GET.get('to_date', '')
    search    = request.GET.get('search', '').strip()

    if item_id:   qs = qs.filter(item_id=item_id)
    if move_type: qs = qs.filter(movement_type=move_type)
    if from_date:
        try: qs = qs.filter(date__gte=datetime.date.fromisoformat(from_date))
        except ValueError: pass
    if to_date:
        try: qs = qs.filter(date__lte=datetime.date.fromisoformat(to_date))
        except ValueError: pass
    if search:
        qs = qs.filter(Q(item__name__icontains=search) | Q(notes__icontains=search) | Q(reference__icontains=search))

    total_in  = qs.filter(movement_type='in').aggregate(t=Sum('quantity'))['t']  or 0
    total_out = qs.filter(movement_type='out').aggregate(t=Sum('quantity'))['t'] or 0

    paginator = Paginator(qs, 30)
    page      = paginator.get_page(request.GET.get('page', 1))
    items     = InventoryItem.objects.filter(admin=admin, is_active=True)
    ctx = {
        'movements': page, 'items': items,
        'total_in': total_in, 'total_out': total_out,
        'item_id': item_id, 'move_type': move_type,
        'from_date': from_date, 'to_date': to_date, 'search': search,
        'MOVEMENT_TYPES': StockMovement.MOVEMENT_TYPES,
    }
    return render(request, 'inventory/movement_list.html', ctx)


@_shop_admin_required
def stock_in(request):
    admin     = _get_admin(request)
    items     = InventoryItem.objects.filter(admin=admin, is_active=True)
    suppliers = Supplier.objects.filter(admin=admin, is_active=True)

    if request.method == 'POST':
        item_id     = request.POST.get('item_id')
        qty_raw     = request.POST.get('quantity', '0')
        cost_raw    = request.POST.get('unit_cost', '0')
        date_raw    = request.POST.get('date') or str(timezone.now().date())
        reason      = request.POST.get('reason', 'purchase')
        supplier_id = request.POST.get('supplier_id', '')
        notes       = request.POST.get('notes', '').strip()
        reference   = request.POST.get('reference', '').strip()
        is_ajax     = request.headers.get('x-requested-with') == 'XMLHttpRequest'

        try:
            item = InventoryItem.objects.get(pk=item_id, admin=admin)
            qty  = Decimal(qty_raw)
            cost = Decimal(cost_raw)
            if qty <= 0: raise ValueError('qty must be positive')
        except Exception as e:
            msg = f'Invalid input: {e}'
            if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg); return redirect('inventory_stock_in')

        try:
            mv = StockMovement.objects.create(
                admin=admin, item=item,
                supplier_id=int(supplier_id) if supplier_id else None,
                movement_type='in', reason=reason, quantity=qty, unit_cost=cost,
                date=datetime.date.fromisoformat(date_raw), notes=notes, reference=reference,
            )
            StockAlert.objects.filter(admin=admin, item=item, acknowledged=False).update(acknowledged=True)
            msg = f'Stock in: +{qty} {item.unit} of {item.name}. New balance: {mv.balance_after}'
            if is_ajax: return JsonResponse({'ok': True, 'message': msg, 'new_stock': float(mv.balance_after)})
            messages.success(request, msg); return redirect('inventory_movement_list')
        except Exception as e:
            msg = f'Error recording stock in: {e}'
            if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=500)
            messages.error(request, msg); return redirect('inventory_stock_in')

    ctx = {'items': items, 'suppliers': suppliers,
           'REASON_CHOICES': StockMovement.REASON_CHOICES, 'today': timezone.now().date()}
    return render(request, 'inventory/stock_in.html', ctx)


@_shop_admin_required
def stock_out(request):
    admin = _get_admin(request)
    items = InventoryItem.objects.filter(admin=admin, is_active=True)

    if request.method == 'POST':
        item_id   = request.POST.get('item_id')
        qty_raw   = request.POST.get('quantity', '0')
        date_raw  = request.POST.get('date') or str(timezone.now().date())
        reason    = request.POST.get('reason', 'internal_use')
        notes     = request.POST.get('notes', '').strip()
        reference = request.POST.get('reference', '').strip()
        is_ajax   = request.headers.get('x-requested-with') == 'XMLHttpRequest'

        try:
            item = InventoryItem.objects.get(pk=item_id, admin=admin)
            qty  = Decimal(qty_raw)
            if qty <= 0: raise ValueError('qty must be positive')
        except Exception as e:
            msg = f'Invalid input: {e}'
            if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg); return redirect('inventory_stock_out')

        if item.current_stock < qty:
            msg = f'Insufficient stock. Available: {item.current_stock} {item.unit}'
            if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg); return redirect('inventory_stock_out')

        try:
            mv = StockMovement.objects.create(
                admin=admin, item=item, movement_type='out', reason=reason,
                quantity=qty, date=datetime.date.fromisoformat(date_raw), notes=notes, reference=reference,
            )
            item.refresh_from_db()
            if item.is_low_stock:
                StockAlert.objects.get_or_create(
                    admin=admin, item=item, acknowledged=False,
                    defaults={'stock_at_alert': item.current_stock}
                )
            msg = f'Stock out: -{qty} {item.unit} of {item.name}. Remaining: {mv.balance_after}'
            if is_ajax: return JsonResponse({'ok': True, 'message': msg, 'new_stock': float(mv.balance_after)})
            messages.success(request, msg); return redirect('inventory_movement_list')
        except Exception as e:
            msg = f'Error recording stock out: {e}'
            if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=500)
            messages.error(request, msg); return redirect('inventory_stock_out')

    ctx = {'items': items,
           'REASON_CHOICES': [r for r in StockMovement.REASON_CHOICES if r[0] in
                              ('delivery', 'damaged', 'expired', 'internal_use', 'other')],
           'today': timezone.now().date()}
    return render(request, 'inventory/stock_out.html', ctx)


@_shop_admin_required
def stock_adjustment(request):
    admin = _get_admin(request)
    items = InventoryItem.objects.filter(admin=admin, is_active=True)

    if request.method == 'POST':
        item_id      = request.POST.get('item_id')
        new_qty_raw  = request.POST.get('new_quantity', '')
        delta_raw    = request.POST.get('delta_quantity', '')
        date_raw     = request.POST.get('date') or str(timezone.now().date())
        notes        = request.POST.get('notes', '').strip()
        is_ajax      = request.headers.get('x-requested-with') == 'XMLHttpRequest'

        try:
            item = InventoryItem.objects.get(pk=item_id, admin=admin)
        except InventoryItem.DoesNotExist:
            msg = 'Invalid item selected.'
            if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg); return redirect('inventory_stock_adjustment')

        try:
            if new_qty_raw.strip():
                delta = Decimal(new_qty_raw) - item.current_stock
            elif delta_raw.strip():
                delta = Decimal(delta_raw)
            else:
                raise ValueError('Provide either new quantity or delta.')
        except Exception as e:
            msg = f'Invalid quantity: {e}'
            if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg); return redirect('inventory_stock_adjustment')

        try:
            mv = StockMovement.objects.create(
                admin=admin, item=item, movement_type='adjustment',
                reason='count_correction', quantity=delta,
                date=datetime.date.fromisoformat(date_raw),
                notes=notes or 'Manual stock adjustment',
            )
            msg = f'Adjustment recorded. {item.name} stock set to {mv.balance_after} {item.unit}.'
            if is_ajax: return JsonResponse({'ok': True, 'message': msg, 'new_stock': float(mv.balance_after)})
            messages.success(request, msg); return redirect('inventory_movement_list')
        except Exception as e:
            msg = f'Adjustment failed: {e}'
            if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=500)
            messages.error(request, msg); return redirect('inventory_stock_adjustment')

    ctx = {'items': items, 'today': timezone.now().date()}
    return render(request, 'inventory/stock_adjustment.html', ctx)


# ══════════════════════════════════════════════════════════════════════════════
# SUPPLIERS
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def supplier_list(request):
    admin     = _get_admin(request)
    suppliers = Supplier.objects.filter(admin=admin).order_by('name')
    return render(request, 'inventory/supplier_list.html', {'suppliers': suppliers})


@_shop_admin_required
def supplier_create(request):
    admin = _get_admin(request)
    if request.method == 'POST':
        name    = request.POST.get('name', '').strip()
        contact = request.POST.get('contact_name', '').strip()
        phone   = request.POST.get('phone', '').strip()
        email   = request.POST.get('email', '').strip()
        address = request.POST.get('address', '').strip()
        notes   = request.POST.get('notes', '').strip()
        if not name:
            messages.error(request, 'Supplier name is required.')
            return redirect('inventory_supplier_create')
        if Supplier.objects.filter(admin=admin, name__iexact=name).exists():
            messages.error(request, f'Supplier "{name}" already exists.')
            return redirect('inventory_supplier_create')
        Supplier.objects.create(admin=admin, name=name, contact_name=contact,
                                phone=phone, email=email, address=address, notes=notes)
        messages.success(request, f'Supplier "{name}" added.')
        return redirect('inventory_supplier_list')
    return render(request, 'inventory/supplier_form.html', {})


@_shop_admin_required
def supplier_edit(request, pk):
    admin    = _get_admin(request)
    supplier = get_object_or_404(Supplier, pk=pk, admin=admin)
    if request.method == 'POST':
        supplier.name         = request.POST.get('name', supplier.name).strip()
        supplier.contact_name = request.POST.get('contact_name', '').strip()
        supplier.phone        = request.POST.get('phone', '').strip()
        supplier.email        = request.POST.get('email', '').strip()
        supplier.address      = request.POST.get('address', '').strip()
        supplier.notes        = request.POST.get('notes', '').strip()
        supplier.is_active    = bool(request.POST.get('is_active'))
        supplier.save()
        messages.success(request, f'Supplier "{supplier.name}" updated.')
        return redirect('inventory_supplier_list')
    return render(request, 'inventory/supplier_form.html', {'supplier': supplier})


@_shop_admin_required
@require_POST
def supplier_delete(request, pk):
    admin    = _get_admin(request)
    supplier = get_object_or_404(Supplier, pk=pk, admin=admin)
    if supplier.movements.exists() or supplier.purchase_orders.exists():
        supplier.is_active = False
        supplier.save(update_fields=['is_active'])
        messages.warning(request, f'"{supplier.name}" has history — deactivated instead of deleted.')
    else:
        name = supplier.name; supplier.delete()
        messages.success(request, f'Supplier "{name}" deleted.')
    return redirect('inventory_supplier_list')


# ══════════════════════════════════════════════════════════════════════════════
# PURCHASE ORDERS
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def po_list(request):
    admin         = _get_admin(request)
    pos           = PurchaseOrder.objects.filter(admin=admin).select_related('supplier')
    status_filter = request.GET.get('status', '')
    if status_filter: pos = pos.filter(status=status_filter)
    ctx = {'pos': pos, 'status_filter': status_filter, 'STATUS_CHOICES': PurchaseOrder.STATUS_CHOICES}
    return render(request, 'inventory/po_list.html', ctx)


@_shop_admin_required
def po_create(request):
    admin     = _get_admin(request)
    suppliers = Supplier.objects.filter(admin=admin, is_active=True)
    items     = InventoryItem.objects.filter(admin=admin, is_active=True)

    if request.method == 'POST':
        supplier_id   = request.POST.get('supplier_id', '')
        order_date    = request.POST.get('order_date') or str(timezone.now().date())
        expected_date = request.POST.get('expected_date', '') or None
        notes         = request.POST.get('notes', '').strip()
        import uuid as _uuid
        po_number = f"PO-{timezone.now().strftime('%Y%m%d')}-{str(_uuid.uuid4())[:6].upper()}"

        try:
            with transaction.atomic():
                po = PurchaseOrder.objects.create(
                    admin=admin,
                    supplier_id=int(supplier_id) if supplier_id else None,
                    po_number=po_number, status='draft',
                    order_date=datetime.date.fromisoformat(order_date),
                    expected_date=datetime.date.fromisoformat(expected_date) if expected_date else None,
                    notes=notes,
                )
                item_ids   = request.POST.getlist('item_ids[]')
                quantities = request.POST.getlist('quantities[]')
                unit_costs = request.POST.getlist('unit_costs[]')
                for i, iid in enumerate(item_ids):
                    if not iid: continue
                    qty  = Decimal(quantities[i] or '0')
                    cost = Decimal(unit_costs[i] or '0')
                    if qty <= 0: continue
                    PurchaseOrderLine.objects.create(
                        purchase_order=po, item_id=int(iid), quantity=qty, unit_cost=cost,
                    )
            messages.success(request, f'Purchase Order {po.po_number} created.')
            return redirect('inventory_po_detail', pk=po.pk)
        except Exception as e:
            messages.error(request, f'Error creating PO: {e}')
            return redirect('inventory_po_create')

    ctx = {'suppliers': suppliers, 'items': items, 'today': timezone.now().date()}
    return render(request, 'inventory/po_form.html', ctx)


@login_required
def po_detail(request, pk):
    admin = _get_admin(request)
    po    = get_object_or_404(PurchaseOrder, pk=pk, admin=admin)
    lines = po.lines.select_related('item')
    return render(request, 'inventory/po_detail.html', {'po': po, 'lines': lines})


@_shop_admin_required
@require_POST
def po_receive(request, pk):
    admin = _get_admin(request)
    po    = get_object_or_404(PurchaseOrder, pk=pk, admin=admin)
    if po.status in ('received', 'cancelled'):
        messages.error(request, f'PO is already {po.get_status_display()}.')
        return redirect('inventory_po_detail', pk=pk)
    received_date_raw = request.POST.get('received_date') or str(timezone.now().date())
    try:
        received_date = datetime.date.fromisoformat(received_date_raw)
    except ValueError:
        received_date = timezone.now().date()
    try:
        po.receive(received_date=received_date)
        messages.success(request, f'PO {po.po_number} marked as received. Stock updated.')
    except Exception as e:
        messages.error(request, f'Error receiving PO: {e}')
    return redirect('inventory_po_detail', pk=pk)


@_shop_admin_required
@require_POST
def po_cancel(request, pk):
    admin = _get_admin(request)
    po    = get_object_or_404(PurchaseOrder, pk=pk, admin=admin)
    if po.status == 'received':
        messages.error(request, 'Cannot cancel a received PO.')
        return redirect('inventory_po_detail', pk=pk)
    po.status = 'cancelled'
    po.save(update_fields=['status'])
    messages.success(request, f'PO {po.po_number} cancelled.')
    return redirect('inventory_po_list')


# ══════════════════════════════════════════════════════════════════════════════
# CATEGORIES
# ══════════════════════════════════════════════════════════════════════════════

@_shop_admin_required
def category_list(request):
    admin = _get_admin(request)
    cats  = InventoryCategory.objects.filter(admin=admin).annotate(item_count=Count('items'))
    if request.method == 'POST':
        name  = request.POST.get('name', '').strip()
        desc  = request.POST.get('description', '').strip()
        icon  = request.POST.get('icon', 'fas fa-box').strip()
        color = request.POST.get('color', '#4361ee').strip()
        if not name:
            messages.error(request, 'Category name is required.')
        elif InventoryCategory.objects.filter(admin=admin, name__iexact=name).exists():
            messages.error(request, f'Category "{name}" already exists.')
        else:
            InventoryCategory.objects.create(admin=admin, name=name, description=desc, icon=icon, color=color)
            messages.success(request, f'Category "{name}" created.')
        return redirect('inventory_category_list')
    return render(request, 'inventory/category_list.html', {'cats': cats})


@_shop_admin_required
@require_POST
def category_delete(request, pk):
    admin = _get_admin(request)
    cat   = get_object_or_404(InventoryCategory, pk=pk, admin=admin)
    if cat.items.exists():
        messages.error(request, f'Cannot delete "{cat.name}" — it has items assigned.')
    else:
        cat.delete()
        messages.success(request, f'Category "{cat.name}" deleted.')
    return redirect('inventory_category_list')


# ══════════════════════════════════════════════════════════════════════════════
# ALERTS
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def alert_list(request):
    admin  = _get_admin(request)
    alerts = StockAlert.objects.filter(admin=admin).select_related('item').order_by('-created_at')
    return render(request, 'inventory/alert_list.html', {'alerts': alerts})


@_shop_admin_required
@require_POST
def alert_acknowledge(request, pk):
    admin = _get_admin(request)
    alert = get_object_or_404(StockAlert, pk=pk, admin=admin)
    alert.acknowledged = True
    alert.save(update_fields=['acknowledged'])
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'ok': True})
    messages.success(request, 'Alert acknowledged.')
    return redirect('inventory_alert_list')


# ══════════════════════════════════════════════════════════════════════════════
# API / AJAX helpers
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def api_item_stock(request, pk):
    admin = _get_admin(request)
    item  = get_object_or_404(InventoryItem, pk=pk, admin=admin)
    return JsonResponse({
        'id': item.id, 'name': item.name,
        'current_stock': float(item.current_stock), 'unit': item.unit,
        'is_low_stock': item.is_low_stock, 'low_alert': float(item.low_stock_alert),
        'avg_cost': float(item.avg_unit_cost),
    })


@login_required
def api_item_sale_price(request, pk):
    admin = _get_admin(request)
    item  = get_object_or_404(InventoryItem, pk=pk, admin=admin)
    return JsonResponse({
        'id': item.id, 'name': item.name, 'unit': item.unit,
        'current_stock': float(item.current_stock),
        'cost_price': float(item.cost_price) if item.cost_price else None,
        'avg_cost': float(item.avg_unit_cost),
    })


@login_required
def api_low_stock_count(request):
    admin = _get_admin(request)
    count = InventoryItem.objects.filter(
        admin=admin, is_active=True, current_stock__lte=F('low_stock_alert')
    ).count()
    return JsonResponse({'count': count})


# ══════════════════════════════════════════════════════════════════════════════
# VALUATION REPORT
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def valuation_report(request):
    admin = _get_admin(request)
    items = InventoryItem.objects.filter(admin=admin, is_active=True).annotate(
        val=ExpressionWrapper(F('current_stock') * F('avg_unit_cost'), output_field=DecimalField())
    ).order_by('-val')
    total_value = items.aggregate(t=Sum('val'))['t'] or Decimal('0.00')
    return render(request, 'inventory/valuation_report.html', {'items': items, 'total_value': total_value})


# ══════════════════════════════════════════════════════════════════════════════
# SALES
# ══════════════════════════════════════════════════════════════════════════════

@_shop_admin_required
def sale_list(request):
    admin = _get_admin(request)
    qs = InventorySale.objects.filter(admin=admin).select_related('item', 'customer').order_by('-sale_date', '-id')

    search    = request.GET.get('search', '').strip()
    item_id   = request.GET.get('item', '')
    status    = request.GET.get('status', '')
    from_date = request.GET.get('from_date', '')
    to_date   = request.GET.get('to_date', '')

    if search:
        qs = qs.filter(
            Q(customer__first_name__icontains=search) |
            Q(customer__last_name__icontains=search)  |
            Q(customer__company_name__icontains=search)|
            Q(item__name__icontains=search)            |
            Q(reference__icontains=search)
        )
    if item_id:   qs = qs.filter(item_id=item_id)
    if status:    qs = qs.filter(status=status)
    if from_date:
        try: qs = qs.filter(sale_date__gte=datetime.date.fromisoformat(from_date))
        except ValueError: pass
    if to_date:
        try: qs = qs.filter(sale_date__lte=datetime.date.fromisoformat(to_date))
        except ValueError: pass

    totals = qs.filter(status='completed').aggregate(
        total_revenue=Sum('total_amount'), total_cogs=Sum('total_cost'),
        total_profit=Sum('gross_profit'),  total_qty=Sum('quantity'),
    )

    paginator = Paginator(qs, 30)
    page      = paginator.get_page(request.GET.get('page', 1))
    items     = InventoryItem.objects.filter(admin=admin, is_active=True)
    ctx = {
        'sales': page, 'items': items,
        'search': search, 'item_id': item_id, 'status': status,
        'from_date': from_date, 'to_date': to_date, 'totals': totals,
        'STATUS_CHOICES': InventorySale.STATUS_CHOICES,
    }
    return render(request, 'inventory/sale_list.html', ctx)


@_shop_admin_required
def sale_create(request):
    """
    Record a new inventory sale.
    - Customer is MANDATORY (FK to accounts.Customer) — no walk-in option.
    - Stock is deducted immediately.
    - An InventoryInvoice is ALWAYS created (handled by InventorySale.save()).
    - accounts.ReceivableLedger is hit when balance > 0 (handled by InventorySale.save()).
    """
    admin = _get_admin(request)
    
    # Check if any customers exist
    customers_exist = Customer.objects.filter(shop__admin=admin, is_deleted=False, is_active=True).exists()
    
    if not customers_exist:
        # No customers exist - show disabled form with message
        ctx = {
            'customers_exist': False,
            'no_customers_message': 'No customers found. Please create a customer first before recording sales.',
        }
        return render(request, 'inventory/sale_form.html', ctx)
    
    items = InventoryItem.objects.filter(admin=admin, is_active=True, track_stock=True)

    if request.method == 'POST':
        item_id        = request.POST.get('item_id')
        qty_raw        = request.POST.get('quantity', '1')
        price_raw      = request.POST.get('unit_price', '0')
        date_raw       = request.POST.get('sale_date') or str(timezone.now().date())
        payment_method = request.POST.get('payment_method', 'cash')
        payment_status = request.POST.get('payment_status', 'paid')
        amount_recv    = request.POST.get('amount_received', '').strip()
        customer_id    = request.POST.get('customer_id', '').strip()
        notes          = request.POST.get('notes', '').strip()
        reference      = request.POST.get('reference', '').strip()
        is_ajax        = request.headers.get('x-requested-with') == 'XMLHttpRequest'

        def err(msg, code=400):
            if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=code)
            messages.error(request, msg)
            return redirect('inventory_sale_create')

        # Customer is mandatory
        if not customer_id:
            return err('Please select a customer.')
        try:
            customer_obj = Customer.objects.get(pk=int(customer_id), shop__admin=admin, is_deleted=False)
        except (Customer.DoesNotExist, ValueError):
            return err('Invalid customer selected.')

        try:
            item  = InventoryItem.objects.get(pk=item_id, admin=admin)
            qty   = Decimal(qty_raw)
            price = Decimal(price_raw)
            if qty <= 0:   raise ValueError('Quantity must be positive')
            if price < 0:  raise ValueError('Price cannot be negative')
        except InventoryItem.DoesNotExist:
            return err('Invalid item selected.')
        except Exception as e:
            return err(f'Invalid input: {e}')

        if item.current_stock < qty:
            return err(f'Insufficient stock. Available: {item.current_stock} {item.unit}')

        total = qty * price
        try:
            amt_recv = Decimal(amount_recv) if amount_recv else (total if payment_status == 'paid' else Decimal('0'))
        except Exception:
            amt_recv = Decimal('0')

        try:
            sale = InventorySale.objects.create(
                admin=admin, item=item, customer=customer_obj,
                quantity=qty, unit_price=price,
                sale_date=datetime.date.fromisoformat(date_raw),
                payment_method=payment_method,
                payment_status=payment_status,
                amount_received=amt_recv,
                notes=notes, reference=reference,
                status='completed',
            )
            msg = (
                f'Sale recorded: {qty} × {item.name} @ {price}. '
                f'Total: {sale.total_amount}. '
                + (f'Balance due: {sale.balance_due}.' if sale.balance_due > 0 else 'Paid in full.')
            )
            if is_ajax:
                return JsonResponse({
                    'ok': True, 'message': msg,
                    'sale_id': sale.id,
                    'invoice_id': sale.invoice_id,
                    'new_stock': float(item.current_stock),
                })
            messages.success(request, msg)
            # Redirect to the auto-created invoice
            if sale.invoice_id:
                return redirect('inventory_invoice_detail', pk=sale.invoice_id)
            return redirect('inventory_sale_list')
        except Exception as e:
            return err(f'Error recording sale: {e}', 500)

    ctx = {
        'items': items,
        'today': timezone.now().date(),
        'PAYMENT_METHOD_CHOICES': InventorySale.PAYMENT_METHOD_CHOICES,
        'customer_search_url': '/inventory/api/customer-search/',
        'customers_exist': True,
    }
    return render(request, 'inventory/sale_form.html', ctx)


@_shop_admin_required
def sale_detail(request, pk):
    admin = _get_admin(request)
    sale  = get_object_or_404(InventorySale, pk=pk, admin=admin)
    return render(request, 'inventory/sale_detail.html', {'sale': sale})


@_shop_admin_required
@require_POST
def sale_cancel(request, pk):
    admin = _get_admin(request)
    sale  = get_object_or_404(InventorySale, pk=pk, admin=admin)
    if sale.status == 'cancelled':
        messages.warning(request, 'Sale is already cancelled.')
        return redirect('inventory_sale_detail', pk=pk)
    sale.status = 'cancelled'
    sale.save()
    messages.success(request, f'Sale #{sale.id} cancelled. Stock restored.')
    return redirect('inventory_sale_list')


# ══════════════════════════════════════════════════════════════════════════════
# INVOICES
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def invoice_list(request):
    admin = _get_admin(request)
    qs    = InventoryInvoice.objects.filter(admin=admin).select_related('customer').order_by('-issue_date', '-id')

    status_filter = request.GET.get('status', '')
    search        = request.GET.get('search', '').strip()
    from_date     = request.GET.get('from_date', '')
    to_date       = request.GET.get('to_date', '')

    if status_filter: qs = qs.filter(status=status_filter)
    if search:
        qs = qs.filter(
            Q(invoice_number__icontains=search)          |
            Q(customer__first_name__icontains=search)    |
            Q(customer__last_name__icontains=search)     |
            Q(customer__company_name__icontains=search)  |
            Q(customer__phone_number__icontains=search)
        )
    if from_date:
        try: qs = qs.filter(issue_date__gte=datetime.date.fromisoformat(from_date))
        except ValueError: pass
    if to_date:
        try: qs = qs.filter(issue_date__lte=datetime.date.fromisoformat(to_date))
        except ValueError: pass

    today = timezone.now().date()
    qs.filter(status__in=['unpaid', 'partial'], due_date__lt=today).update(status='overdue')

    totals = qs.aggregate(total_invoiced=Sum('total_amount'), total_paid=Sum('amount_paid'))
    total_outstanding = (totals['total_invoiced'] or 0) - (totals['total_paid'] or 0)

    paginator = Paginator(qs, 25)
    page      = paginator.get_page(request.GET.get('page', 1))
    ctx = {
        'invoices': page, 'status_filter': status_filter,
        'search': search, 'from_date': from_date, 'to_date': to_date,
        'totals': totals, 'total_outstanding': total_outstanding,
        'STATUS_CHOICES': InventoryInvoice.STATUS_CHOICES, 'today': today,
    }
    return render(request, 'inventory/invoice_list.html', ctx)


@_shop_admin_required
def invoice_create(request):
    """
    Manually create an invoice.
    Customer is MANDATORY. For each line with an item FK, an InventorySale
    is automatically recorded (which also deducts stock).
    """
    admin = _get_admin(request)
    
    # Check if any customers exist
    customers_exist = Customer.objects.filter(shop__admin=admin, is_deleted=False, is_active=True).exists()
    
    if not customers_exist:
        # No customers exist - show disabled form with message
        ctx = {
            'customers_exist': False,
            'no_customers_message': 'No customers found. Please create a customer first before creating invoices.',
            'customer_create_url': '/accounts/customer/create/',  # Adjust URL as needed
            'items': [],
            'customers': [],
            'today': timezone.now().date(),
            'due_default': (timezone.now().date() + datetime.timedelta(days=30)).isoformat(),
        }
        return render(request, 'inventory/invoice_form.html', ctx)
    
    items = InventoryItem.objects.filter(admin=admin, is_active=True)
    today = timezone.now().date()

    if request.method == 'POST':
        customer_id = request.POST.get('customer_id', '').strip()
        if not customer_id:
            messages.error(request, 'Please select a customer.')
            return redirect('inventory_invoice_create')
        try:
            customer_obj = Customer.objects.get(pk=int(customer_id), shop__admin=admin, is_deleted=False)
        except (Customer.DoesNotExist, ValueError):
            messages.error(request, 'Invalid customer selected.')
            return redirect('inventory_invoice_create')

        issue_date_raw  = request.POST.get('issue_date') or str(today)
        due_date_raw    = request.POST.get('due_date', '').strip()
        discount_raw    = request.POST.get('discount_amount', '0').strip()
        tax_raw         = request.POST.get('tax_amount', '0').strip()
        notes           = request.POST.get('notes', '').strip()
        terms           = request.POST.get('terms', '').strip()
        reference       = request.POST.get('reference', '').strip()
        amount_paid_raw = request.POST.get('amount_paid', '0').strip()

        try:
            issue_date   = datetime.date.fromisoformat(issue_date_raw)
            due_date     = datetime.date.fromisoformat(due_date_raw) if due_date_raw else None
            discount_amt = Decimal(discount_raw or '0')
            tax_amt      = Decimal(tax_raw or '0')
            amount_paid  = Decimal(amount_paid_raw or '0')
        except Exception as e:
            messages.error(request, f'Invalid date or amount: {e}')
            return redirect('inventory_invoice_create')

        descriptions = request.POST.getlist('descriptions[]')
        item_ids     = request.POST.getlist('line_item_ids[]')
        quantities   = request.POST.getlist('line_quantities[]')
        unit_prices  = request.POST.getlist('line_unit_prices[]')

        if not any(d.strip() for d in descriptions):
            messages.error(request, 'Add at least one line item.')
            return redirect('inventory_invoice_create')

        try:
            with transaction.atomic():
                invoice = InventoryInvoice.objects.create(
                    admin=admin, customer=customer_obj,
                    issue_date=issue_date, due_date=due_date,
                    discount_amount=discount_amt, tax_amount=tax_amt,
                    notes=notes, terms=terms, reference=reference,
                    amount_paid=amount_paid, status='draft',
                )

                paid_remaining = amount_paid
                lines_with_items = []
                lines_without_items = []

                for i, desc in enumerate(descriptions):
                    if not desc.strip(): continue
                    try:
                        qty   = Decimal(quantities[i] or '1')
                        price = Decimal(unit_prices[i] or '0')
                        iid   = item_ids[i] if i < len(item_ids) else ''
                    except Exception:
                        qty, price, iid = Decimal('1'), Decimal('0'), ''

                    line = InventoryInvoiceLine.objects.create(
                        invoice=invoice,
                        item_id=int(iid) if iid else None,
                        description=desc.strip(), quantity=qty, unit_price=price,
                    )
                    if iid:
                        lines_with_items.append(line)
                    else:
                        lines_without_items.append(line)

                invoice.recalculate_totals()

                # Create an InventorySale for each line that has an item
                total_line_amount = sum(ln.line_total for ln in lines_with_items) or Decimal('1')
                for idx, line in enumerate(lines_with_items):
                    proportion   = line.line_total / total_line_amount
                    if idx == len(lines_with_items) - 1:
                        allocated = min(paid_remaining, line.line_total)
                    else:
                        allocated = min((amount_paid * proportion).quantize(Decimal('0.01')), paid_remaining)
                    paid_remaining -= allocated

                    pay_status = 'paid' if allocated >= line.line_total and line.line_total > 0 else (
                        'partial' if allocated > 0 else 'unpaid'
                    )

                    # InventorySale.save() will create its own invoice stub — we skip that
                    # here because we are manually managing the invoice. We therefore call
                    # create() via a flag approach by creating the sale and then linking it
                    # to this invoice's line.
                    sale = InventorySale(
                        admin=admin, item=line.item, customer=customer_obj,
                        quantity=line.quantity, unit_price=line.unit_price,
                        sale_date=issue_date, payment_method='cash' if pay_status == 'paid' else 'credit',
                        payment_status=pay_status, amount_received=allocated,
                        notes=f'Auto-created from Invoice {invoice.invoice_number}',
                        reference=reference, status='completed',
                    )
                    # Skip auto-invoice creation: set invoice FK before save via
                    # post-create update to avoid the InventorySale.save() creating
                    # a duplicate invoice.
                    sale.save()
                    # Link the sale's auto-created invoice back — or override with ours
                    if sale.invoice_id and sale.invoice_id != invoice.id:
                        # Delete the auto-stub and link to the real invoice instead
                        try:
                            InventoryInvoice.objects.filter(pk=sale.invoice_id).delete()
                        except Exception:
                            pass
                    InventorySale.objects.filter(pk=sale.pk).update(invoice=invoice)
                    InventoryInvoiceLine.objects.filter(pk=line.pk).update(sale=sale)

                invoice.update_status()

            messages.success(request, f'Invoice {invoice.invoice_number} created.')
            return redirect('inventory_invoice_detail', pk=invoice.pk)
        except Exception as e:
            messages.error(request, f'Error creating invoice: {e}')
            return redirect('inventory_invoice_create')

    ctx = {
        'items': items, 'today': today,
        'due_default': today + datetime.timedelta(days=30),
        'PAYMENT_METHODS': InventoryInvoicePayment.METHODS,
        'customer_search_url': '/inventory/api/customer-search/',
        'customers_exist': True,
    }
    return render(request, 'inventory/invoice_form.html', ctx)


@login_required
def invoice_detail(request, pk):
    admin    = _get_admin(request)
    invoice  = get_object_or_404(InventoryInvoice, pk=pk, admin=admin)
    lines    = invoice.lines.select_related('item')
    payments = invoice.payments.order_by('-payment_date')
    ctx = {
        'invoice': invoice, 'lines': lines, 'payments': payments,
        'today': timezone.now().date(), 'PAYMENT_METHODS': InventoryInvoicePayment.METHODS,
    }
    return render(request, 'inventory/invoice_detail.html', ctx)


@_shop_admin_required
@require_POST
def invoice_record_payment(request, pk):
    admin   = _get_admin(request)
    invoice = get_object_or_404(InventoryInvoice, pk=pk, admin=admin)
    is_ajax = request.headers.get('x-requested-with') == 'XMLHttpRequest'

    try:
        amount   = Decimal(request.POST.get('amount', '0'))
        method   = request.POST.get('method', 'cash')
        notes    = request.POST.get('notes', '').strip()
        date_raw = request.POST.get('payment_date', '') or str(timezone.now().date())
        pay_date = datetime.date.fromisoformat(date_raw)
        if amount <= 0: raise ValueError('Amount must be positive')
    except Exception as e:
        msg = f'Invalid input: {e}'
        if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=400)
        messages.error(request, msg); return redirect('inventory_invoice_detail', pk=pk)

    if amount > invoice.balance_due:
        msg = f'Payment exceeds balance due ({invoice.balance_due}).'
        if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=400)
        messages.error(request, msg); return redirect('inventory_invoice_detail', pk=pk)

    invoice.record_payment(amount, method=method, notes=notes, payment_date=pay_date)

    # Sync InventoryReceivable
    try:
        sale = invoice.sale
        if sale and sale.receivable_entry:
            rec = sale.receivable_entry
            rec.amount_paid = min(rec.total_amount, rec.amount_paid + amount)
            rec.save()
    except Exception:
        pass

    # Sync accounts.ReceivableLedger (credit entry — customer paid)
    try:
        from accounts.models import ReceivableLedger
        if invoice.customer_id:
            customer = invoice.customer
            ReceivableLedger.objects.create(
                admin=admin,
                shop=customer.shop,
                customer=customer,
                date=pay_date,
                transaction_type='payment',
                debit=Decimal('0.00'),
                credit=amount,
                description=f"Payment for Inventory Invoice {invoice.invoice_number}",
            )
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning(f"[invoice_record_payment] ReceivableLedger credit failed: {e}")

    msg = f'Payment of {amount} recorded. Balance: {invoice.balance_due}'
    if is_ajax:
        return JsonResponse({
            'ok': True, 'message': msg,
            'balance_due': float(invoice.balance_due),
            'status': invoice.get_status_display(),
            'amount_paid': float(invoice.amount_paid),
        })
    messages.success(request, msg)
    return redirect('inventory_invoice_detail', pk=pk)


@_shop_admin_required
@require_POST
def invoice_cancel(request, pk):
    admin   = _get_admin(request)
    invoice = get_object_or_404(InventoryInvoice, pk=pk, admin=admin)
    if invoice.status == 'paid':
        messages.error(request, 'Cannot cancel a paid invoice.')
        return redirect('inventory_invoice_detail', pk=pk)
    invoice.status = 'cancelled'
    invoice.save(update_fields=['status'])
    messages.success(request, f'Invoice {invoice.invoice_number} cancelled.')
    return redirect('inventory_invoice_list')


@_shop_admin_required
def invoice_edit(request, pk):
    admin   = _get_admin(request)
    invoice = get_object_or_404(InventoryInvoice, pk=pk, admin=admin)
    items   = InventoryItem.objects.filter(admin=admin, is_active=True)

    if invoice.status in ('paid', 'cancelled'):
        messages.error(request, f'Cannot edit a {invoice.get_status_display()} invoice.')
        return redirect('inventory_invoice_detail', pk=pk)

    if request.method == 'POST':
        customer_id = request.POST.get('customer_id', '').strip()
        if not customer_id:
            messages.error(request, 'Please select a customer.')
            return redirect('inventory_invoice_edit', pk=pk)
        try:
            invoice.customer = Customer.objects.get(pk=int(customer_id), shop__admin=admin, is_deleted=False)
        except (Customer.DoesNotExist, ValueError):
            messages.error(request, 'Invalid customer selected.')
            return redirect('inventory_invoice_edit', pk=pk)

        due_raw = request.POST.get('due_date', '').strip()
        try:
            invoice.due_date        = datetime.date.fromisoformat(due_raw) if due_raw else None
            invoice.discount_amount = Decimal(request.POST.get('discount_amount', '0') or '0')
            invoice.tax_amount      = Decimal(request.POST.get('tax_amount', '0') or '0')
        except Exception as e:
            messages.error(request, f'Invalid value: {e}')
            return redirect('inventory_invoice_edit', pk=pk)

        invoice.notes     = request.POST.get('notes', '').strip()
        invoice.terms     = request.POST.get('terms', '').strip()
        invoice.reference = request.POST.get('reference', '').strip()
        invoice.save()

        invoice.lines.all().delete()
        descriptions = request.POST.getlist('descriptions[]')
        item_ids     = request.POST.getlist('line_item_ids[]')
        quantities   = request.POST.getlist('line_quantities[]')
        unit_prices  = request.POST.getlist('line_unit_prices[]')
        for i, desc in enumerate(descriptions):
            if not desc.strip(): continue
            try:
                qty   = Decimal(quantities[i] or '1')
                price = Decimal(unit_prices[i] or '0')
                iid   = item_ids[i] if i < len(item_ids) else ''
            except Exception:
                qty, price, iid = Decimal('1'), Decimal('0'), ''
            InventoryInvoiceLine.objects.create(
                invoice=invoice, item_id=int(iid) if iid else None,
                description=desc.strip(), quantity=qty, unit_price=price,
            )
        invoice.recalculate_totals()
        invoice.update_status()
        messages.success(request, f'Invoice {invoice.invoice_number} updated.')
        return redirect('inventory_invoice_detail', pk=pk)

    ctx = {
        'invoice': invoice, 'lines': invoice.lines.all(), 'items': items,
        'today': timezone.now().date(), 'due_default': invoice.due_date or (timezone.now().date() + datetime.timedelta(days=30)),
        'PAYMENT_METHODS': InventoryInvoicePayment.METHODS,
        'editing': True, 'customer_search_url': '/inventory/api/customer-search/',
        'customers_exist': True,
    }
    return render(request, 'inventory/invoice_form.html', ctx)


# ══════════════════════════════════════════════════════════════════════════════
# RECEIVABLES
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def receivable_list(request):
    admin = _get_admin(request)
    qs    = InventoryReceivable.objects.filter(admin=admin).select_related('customer')

    status_filter = request.GET.get('status', '')
    search        = request.GET.get('search', '').strip()

    if status_filter: qs = qs.filter(status=status_filter)
    if search:
        qs = qs.filter(
            Q(customer__first_name__icontains=search) |
            Q(customer__last_name__icontains=search)  |
            Q(customer__company_name__icontains=search)|
            Q(customer__phone_number__icontains=search)
        )

    totals = qs.aggregate(total_due=Sum('total_amount'), total_paid=Sum('amount_paid'))
    outstanding = (totals['total_due'] or 0) - (totals['total_paid'] or 0)

    paginator = Paginator(qs, 30)
    page      = paginator.get_page(request.GET.get('page', 1))
    ctx = {
        'receivables': page, 'status_filter': status_filter, 'search': search,
        'totals': totals, 'outstanding': outstanding,
        'STATUS_CHOICES': InventoryReceivable.STATUS_CHOICES,
    }
    return render(request, 'inventory/receivable_list.html', ctx)


@_shop_admin_required
@require_POST
def receivable_collect(request, pk):
    admin   = _get_admin(request)
    rec     = get_object_or_404(InventoryReceivable, pk=pk, admin=admin)
    is_ajax = request.headers.get('x-requested-with') == 'XMLHttpRequest'

    try:
        amount = Decimal(request.POST.get('amount', '0'))
        if amount <= 0:        raise ValueError('Amount must be positive')
        if amount > rec.balance_due: raise ValueError(f'Exceeds balance due ({rec.balance_due})')
    except Exception as e:
        msg = str(e)
        if is_ajax: return JsonResponse({'ok': False, 'message': msg}, status=400)
        messages.error(request, msg); return redirect('inventory_receivable_list')

    rec.amount_paid += amount
    rec.save()

    # Sync parent sale
    try:
        sale = rec.sale
        if sale:
            sale.amount_received += amount
            sale.payment_status = 'paid' if sale.amount_received >= sale.total_amount else 'partial'
            InventorySale.objects.filter(pk=sale.pk).update(
                amount_received=sale.amount_received, payment_status=sale.payment_status,
            )
    except Exception:
        pass

    # Credit accounts.ReceivableLedger
    try:
        from accounts.models import ReceivableLedger
        if rec.customer_id:
            customer = rec.customer
            pay_date = request.POST.get('payment_date', '') or str(timezone.now().date())
            ReceivableLedger.objects.create(
                admin=admin, shop=customer.shop, customer=customer,
                date=datetime.date.fromisoformat(pay_date),
                transaction_type='payment',
                debit=Decimal('0.00'), credit=amount,
                description=f"Payment for Inventory Receivable #{rec.id}",
            )
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning(f"[receivable_collect] ReceivableLedger credit failed: {e}")

    msg = f'Collected {amount}. Balance: {rec.balance_due}'
    if is_ajax:
        return JsonResponse({'ok': True, 'message': msg, 'balance_due': float(rec.balance_due), 'status': rec.get_status_display()})
    messages.success(request, msg)
    return redirect('inventory_receivable_list')