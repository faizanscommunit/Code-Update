# ================================================================================
# inventory/apps.py
# ================================================================================
from django.apps import AppConfig


class InventoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name  = 'inventory'
    label = 'inventory'

    def ready(self):
        import inventory.signals  # noqa: F401 — connect signal handlers