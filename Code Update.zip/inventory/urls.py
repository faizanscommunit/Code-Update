# ================================================================================
# ADD THESE PATHS TO: inventory/urls.py
# ================================================================================
# Add the following imports at the top (already present for views):
#   from . import views
#
# Then append these paths to urlpatterns:

from django.urls import path
from . import views

# --- NEW paths to add ---
extra_urlpatterns = [
    # Sales
    path('sales/',                        views.sale_list,          name='inventory_sale_list'),
    path('sales/create/',                 views.sale_create,        name='inventory_sale_create'),
    path('sales/<int:pk>/',               views.sale_detail,        name='inventory_sale_detail'),
    path('sales/<int:pk>/cancel/',        views.sale_cancel,        name='inventory_sale_cancel'),

    # API helper — sale price lookup
    path('api/item/<int:pk>/sale-price/', views.api_item_sale_price,  name='inventory_api_item_sale_price'),
]

# ── Full updated urls.py (copy-paste this entire file) ───────────────────────

urlpatterns = [
    # Dashboard
    path('',                          views.inventory_dashboard,  name='inventory_dashboard'),

    # Items
    path('items/',                    views.item_list,            name='inventory_item_list'),
    path('items/create/',             views.item_create,          name='inventory_item_create'),
    path('items/<int:pk>/edit/',      views.item_edit,            name='inventory_item_edit'),
    path('items/<int:pk>/delete/',    views.item_delete,          name='inventory_item_delete'),

    # Stock movements
    path('movements/',                views.movement_list,        name='inventory_movement_list'),
    path('movements/stock-in/',       views.stock_in,             name='inventory_stock_in'),
    path('movements/stock-out/',      views.stock_out,            name='inventory_stock_out'),
    path('movements/adjustment/',     views.stock_adjustment,     name='inventory_stock_adjustment'),

    # Suppliers
    path('suppliers/',                views.supplier_list,        name='inventory_supplier_list'),
    path('suppliers/create/',         views.supplier_create,      name='inventory_supplier_create'),
    path('suppliers/<int:pk>/edit/',  views.supplier_edit,        name='inventory_supplier_edit'),
    path('suppliers/<int:pk>/delete/',views.supplier_delete,      name='inventory_supplier_delete'),

    # Purchase Orders
    path('purchase-orders/',          views.po_list,              name='inventory_po_list'),
    path('purchase-orders/create/',   views.po_create,            name='inventory_po_create'),
    path('purchase-orders/<int:pk>/', views.po_detail,            name='inventory_po_detail'),
    path('purchase-orders/<int:pk>/receive/', views.po_receive,   name='inventory_po_receive'),
    path('purchase-orders/<int:pk>/cancel/',  views.po_cancel,    name='inventory_po_cancel'),

    # Categories
    path('categories/',               views.category_list,        name='inventory_category_list'),
    path('categories/<int:pk>/delete/', views.category_delete,    name='inventory_category_delete'),

    # Alerts
    path('alerts/',                   views.alert_list,           name='inventory_alert_list'),
    path('alerts/<int:pk>/ack/',      views.alert_acknowledge,    name='inventory_alert_acknowledge'),

    # ── Sales (NEW) ──────────────────────────────────────────────────────
    path('sales/',                        views.sale_list,            name='inventory_sale_list'),
    path('sales/create/',                 views.sale_create,          name='inventory_sale_create'),
    path('sales/<int:pk>/',               views.sale_detail,          name='inventory_sale_detail'),
    path('sales/<int:pk>/cancel/',        views.sale_cancel,          name='inventory_sale_cancel'),

    # ── Reports ──────────────────────────────────────────────────────────
    path('reports/valuation/',            views.valuation_report,     name='inventory_valuation_report'),

    # ── API ───────────────────────────────────────────────────────────────
    path('api/item/<int:pk>/stock/',      views.api_item_stock,       name='inventory_api_item_stock'),
    path('api/item/<int:pk>/sale-price/', views.api_item_sale_price,  name='inventory_api_item_sale_price'),  # NEW
    path('api/low-stock-count/',          views.api_low_stock_count,  name='inventory_api_low_stock_count'),

    # ================================================================================
    # ADD TO: inventory/urls.py  — append inside urlpatterns list
    # ================================================================================

    # ── Invoices ──────────────────────────────────────────────────────────────
    path('invoices/',                             views.invoice_list,            name='inventory_invoice_list'),
    path('invoices/create/',                      views.invoice_create,          name='inventory_invoice_create'),
    path('invoices/<int:pk>/',                    views.invoice_detail,          name='inventory_invoice_detail'),
    path('invoices/<int:pk>/edit/',               views.invoice_edit,            name='inventory_invoice_edit'),
    path('invoices/<int:pk>/cancel/',             views.invoice_cancel,          name='inventory_invoice_cancel'),
    path('invoices/<int:pk>/payment/',            views.invoice_record_payment,  name='inventory_invoice_payment'),

    # ── Receivables ───────────────────────────────────────────────────────────
    path('receivables/',                          views.receivable_list,         name='inventory_receivable_list'),
    path('receivables/<int:pk>/collect/',         views.receivable_collect,      name='inventory_receivable_collect'),

    path('api/customer-search/', views.customer_search, name='inventory_customer_search'),
]