from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('inventory', '0005_alter_inventorysale_gross_profit_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='inventorysale',
            name='customer',
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='inventory_sales',
                to='accounts.customer',
            ),
        ),
        migrations.AddField(
            model_name='inventoryreceivable',
            name='customer',
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='inventory_receivables',
                to='accounts.customer',
            ),
        ),
    ]
