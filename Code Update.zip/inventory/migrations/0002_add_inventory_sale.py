# ================================================================================
# inventory/migrations/XXXX_add_inventory_sale.py
# Rename to match your next migration number, e.g. 0002_add_inventory_sale.py
# ================================================================================
from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone
from decimal import Decimal


class Migration(migrations.Migration):

    dependencies = [
        # Replace '0001_initial' with your most recent inventory migration
        ('inventory', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='InventorySale',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('customer_name',   models.CharField(blank=True, default='', max_length=200)),
                ('customer_phone',  models.CharField(blank=True, default='', max_length=30)),
                ('quantity',        models.DecimalField(decimal_places=2, max_digits=12)),
                ('unit_price',      models.DecimalField(decimal_places=2, max_digits=10)),
                ('cost_price',      models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=10)),
                ('total_amount',    models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=14)),
                ('total_cost',      models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=14)),
                ('gross_profit',    models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=14)),
                ('payment_method',  models.CharField(
                    choices=[('cash','Cash'),('bank','Bank Transfer'),('cheque','Cheque'),('credit','Credit (Receivable)'),('other','Other')],
                    default='cash', max_length=20)),
                ('payment_status',  models.CharField(
                    choices=[('paid','Paid'),('unpaid','Unpaid'),('partial','Partial')],
                    default='paid', max_length=20)),
                ('amount_received', models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=14)),
                ('status', models.CharField(
                    choices=[('pending','Pending'),('completed','Completed'),('cancelled','Cancelled'),('returned','Returned')],
                    default='completed', max_length=20)),
                ('sale_date',  models.DateField(default=django.utils.timezone.now)),
                ('notes',      models.TextField(blank=True, default='')),
                ('reference',  models.CharField(blank=True, default='', max_length=100)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('admin', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='inventory_sales',
                    to=settings.AUTH_USER_MODEL,
                )),
                ('item', models.ForeignKey(
                    on_delete=django.db.models.deletion.PROTECT,
                    related_name='sales',
                    to='inventory.inventoryitem',
                )),
                ('stock_movement', models.OneToOneField(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='sale',
                    to='inventory.stockmovement',
                )),
            ],
            options={'ordering': ['-sale_date', '-id']},
        ),
        migrations.AddIndex(
            model_name='inventorysale',
            index=models.Index(fields=['admin', 'sale_date'], name='inv_sale_admin_date_idx'),
        ),
        migrations.AddIndex(
            model_name='inventorysale',
            index=models.Index(fields=['item', 'sale_date'], name='inv_sale_item_date_idx'),
        ),
    ]