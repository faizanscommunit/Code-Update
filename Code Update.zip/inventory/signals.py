# ================================================================================
# inventory/signals.py
# Auto-deduct stock when a DailyDelivery is saved (if linked CanType has
# an InventoryItem with auto_deduct_on_delivery=True)
# ================================================================================
from django.dispatch import receiver
from django.db.models.signals import post_save, post_delete
from decimal import Decimal


@receiver(post_save, sender='accounts.DailyDelivery')
def auto_deduct_on_delivery(sender, instance, created, **kwargs):
    """
    When a delivery is saved, check if the delivered CanType has a linked
    InventoryItem with auto_deduct_on_delivery=True. If so, create/update
    a StockMovement OUT for the delivered quantity.

    We use get_or_create keyed on the delivery FK so editing a delivery
    adjusts the movement rather than duplicating it.
    """
    try:
        from inventory.models import InventoryItem, StockMovement
        can_type = getattr(instance, 'can_type', None)
        if not can_type:
            return

        try:
            inv_item = InventoryItem.objects.get(
                can_type=can_type,
                admin=instance.admin,
                auto_deduct_on_delivery=True,
                is_active=True,
            )
        except InventoryItem.DoesNotExist:
            return

        qty = Decimal(str(instance.quantity_delivered or 0))
        if qty <= 0:
            return

        # Try to update existing movement linked to this delivery
        existing = StockMovement.objects.filter(
            delivery=instance, item=inv_item, movement_type='out'
        ).first()

        if existing:
            if existing.quantity != qty:
                existing.quantity = qty
                existing.date     = instance.delivery_date
                existing.save()
        else:
            StockMovement.objects.create(
                admin=instance.admin,
                item=inv_item,
                delivery=instance,
                movement_type='out',
                reason='delivery',
                quantity=qty,
                date=instance.delivery_date,
                notes=f"Auto-deducted: Delivery #{instance.id} to {instance.customer.display_name}",
                reference=str(instance.id),
            )
    except Exception as e:
        # Never let inventory errors block delivery saves
        import logging
        logging.getLogger(__name__).warning(f"[Inventory auto-deduct] {e}")


@receiver(post_delete, sender='accounts.DailyDelivery')
def reverse_auto_deduct_on_delivery_delete(sender, instance, **kwargs):
    """
    When a delivery is deleted, remove its auto-deducted stock movement
    so inventory is correctly restored.
    """
    try:
        from inventory.models import StockMovement
        StockMovement.objects.filter(
            delivery=instance, movement_type='out', reason='delivery'
        ).delete()
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning(f"[Inventory delete-reverse] {e}")