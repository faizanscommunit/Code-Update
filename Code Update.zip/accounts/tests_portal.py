from django.test import TestCase, Client
from django.urls import reverse
from . import models
from django.utils import timezone
from datetime import timedelta
from decimal import Decimal

class PortalTests(TestCase):
    def setUp(self):
        self.user = models.User.objects.create_user(username='owner', password='testpass', role='shop_admin')
        self.shop = models.Shop.objects.create(name="Owner's Shop", admin=self.user)
        self.client = Client()
        self.client.login(username='owner', password='testpass')
        self.customer = models.Customer.objects.create(admin=self.user, shop=self.shop, first_name='John', last_name='Doe', email='a@example.com', phone_number='1234567890', whatsapp_number='1234567890', address='X')

    def test_outstanding_balance_calc(self):
        inv = models.Invoice.objects.create(invoice_number='INV-TEST', admin=self.user, shop=self.shop, customer=self.customer, total_amount=100, status='unpaid')
        p = models.Payment.objects.create(invoice=inv, admin=self.user, shop=self.shop, payer_customer=self.customer, amount=40, method='cash', status='completed')
        balance = self.customer.get_outstanding_balance()
        self.assertEqual(balance, Decimal('60'))

    def test_portal_token_and_access(self):
        # legacy token flow still works
        token = self.customer.generate_portal_token(expires_hours=1)
        pin = token.generate_pin()
        url = reverse('customer_portal', args=[token.token])
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'Enter 4-digit key')
        resp = self.client.post(url, {'action': 'verify_pin', 'pin': '0000'}, follow=True)
        self.assertContains(resp, 'Invalid PIN')
        resp = self.client.post(url, {'action': 'verify_pin', 'pin': pin}, follow=True)
        self.assertContains(resp, 'PIN verified')
        token.expires_at = timezone.now() - timedelta(hours=2)
        token.save()
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 403)

    def test_customer_login_session_flow(self):
        # customer.create now auto-generates a per-customer PIN when created via create view; test manual generation here
        pin = self.customer.generate_portal_pin()
        login_url = reverse('customer_login')
        portal_url = reverse('customer_portal_session')
        # GET login page
        resp = self.client.get(login_url)
        self.assertEqual(resp.status_code, 200)
        # wrong credentials
        resp = self.client.post(login_url, {'phone': self.customer.phone_number, 'pin': '0000'}, follow=True)
        self.assertContains(resp, 'Invalid PIN')
        # correct credentials
        resp = self.client.post(login_url, {'phone': self.customer.phone_number, 'pin': pin}, follow=True)
        self.assertRedirects(resp, portal_url)
        # access portal
        resp = self.client.get(portal_url)
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'Outstanding balance')

    def test_regenerate_and_clear_and_set_custom_pin(self):
        # model-level set/generate/clear pin behaviour
        raw = self.customer.generate_portal_pin()
        self.customer.refresh_from_db()
        self.assertTrue(self.customer.portal_is_active)
        self.assertIsNotNone(self.customer.portal_pin_hash)
        self.assertIsNotNone(self.customer.portal_last_pin_at)

        # set custom pin
        self.customer.set_portal_pin('4321')
        self.customer.refresh_from_db()
        self.assertTrue(self.customer.check_portal_pin('4321'))

        # clear pin
        self.customer.clear_portal_pin()
        self.customer.refresh_from_db()
        self.assertIsNone(self.customer.portal_pin_hash)
        self.assertFalse(self.customer.portal_is_active)

    def test_set_portal_username(self):
        self.customer.portal_username = 'john_doe_01'
        self.customer.save()
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.portal_username, 'john_doe_01')

    def test_admin_edit_generate_pin_redirects_to_edit(self):
        # shop-admin logs in via self.client
        edit_url = reverse('customer_edit', args=[self.customer.id])
        resp = self.client.post(edit_url, {'action': 'generate_pin'}, follow=False)
        # should redirect to edit page
        self.assertEqual(resp.status_code, 302)
        self.assertIn(reverse('customer_edit', args=[self.customer.id]), resp['Location'])

    def test_admin_edit_set_custom_pin_and_clear(self):
        edit_url = reverse('customer_edit', args=[self.customer.id])
        # set custom pin
        resp = self.client.post(edit_url, {'action': 'set_custom_pin', 'custom_pin': '5555'}, follow=True)
        self.assertContains(resp, 'Custom PIN set')
        self.customer.refresh_from_db()
        self.assertTrue(self.customer.check_portal_pin('5555'))
        # clear pin
        resp = self.client.post(edit_url, {'action': 'clear_pin'}, follow=True)
        self.assertContains(resp, 'Customer PIN cleared')
        self.customer.refresh_from_db()
        self.assertIsNone(self.customer.portal_pin_hash)

    def test_admin_set_custom_pin_does_not_change_username(self):
        # ensure setting a PIN doesn't overwrite an existing username
        self.customer.portal_username = 'old_name'
        self.customer.save()
        edit_url = reverse('customer_edit', args=[self.customer.id])
        resp = self.client.post(edit_url, {'action': 'set_custom_pin', 'custom_pin': '7777'}, follow=True)
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.portal_username, 'old_name')
        self.assertTrue(self.customer.check_portal_pin('7777'))

    def test_admin_update_username_only_updates_username(self):
        edit_url = reverse('customer_edit', args=[self.customer.id])
        resp = self.client.post(edit_url, {'action': 'update_username', 'portal_username': 'unique_name'}, follow=True)
        self.assertContains(resp, 'Portal username updated')
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.portal_username, 'unique_name')

    def test_admin_update_username_conflict_global(self):
        # another customer in the system has the username 'taken_name'
        other = models.Customer.objects.create(admin=self.user, shop=self.shop, first_name='Jane', last_name='Smith', portal_username='taken_name')
        edit_url = reverse('customer_edit', args=[self.customer.id])
        resp = self.client.post(edit_url, {'action': 'update_username', 'portal_username': 'taken_name'}, follow=True)
        # should show an error about uniqueness
        self.assertContains(resp, 'Portal username must be unique')
        self.customer.refresh_from_db()
        self.assertNotEqual(self.customer.portal_username, 'taken_name')

    def test_save_form_updates_profile(self):
        edit_url = reverse('customer_edit', args=[self.customer.id])
        resp = self.client.post(edit_url, {'action': 'save', 'first_name': 'Johnny', 'email': 'johnny@example.com', 'phone_number': self.customer.phone_number, 'whatsapp_number': self.customer.whatsapp_number, 'address': self.customer.address, 'month_start_day': self.customer.month_start_day, 'month_end_day': self.customer.month_end_day}, follow=True)
        self.assertEqual(resp.status_code, 200)
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.first_name, 'Johnny')

    def test_save_does_not_update_username_or_pin(self):
        # prepare existing username and pin
        self.customer.portal_username = 'old_user'
        self.customer.set_portal_pin('1234')
        self.customer.save()
        edit_url = reverse('customer_edit', args=[self.customer.id])
        # attempt to change username and pin (and portal active flag) via the main save action (should be ignored)
        self.customer.portal_is_active = True
        self.customer.save()
        resp = self.client.post(edit_url, {
            'action': 'save',
            'first_name': 'Newname',
            'portal_username': 'new_user',
            'custom_pin': '9999',
            'portal_is_active': '0',
            'phone_number': self.customer.phone_number,
            'whatsapp_number': self.customer.whatsapp_number,
            'address': self.customer.address,
            'month_start_day': self.customer.month_start_day,
            'month_end_day': self.customer.month_end_day
        }, follow=True)
        self.assertEqual(resp.status_code, 200)
        self.customer.refresh_from_db()
        # profile changed, but username and pin should remain
        self.assertEqual(self.customer.first_name, 'Newname')
        self.assertEqual(self.customer.portal_username, 'old_user')
        self.assertTrue(self.customer.check_portal_pin('1234'))
        self.assertTrue(self.customer.portal_is_active)

    def test_update_username_allows_setting_portal_active(self):
        edit_url = reverse('customer_edit', args=[self.customer.id])
        resp = self.client.post(edit_url, {'action': 'update_username', 'portal_username': 'portal_user', 'portal_is_active': '1'}, follow=True)
        self.assertContains(resp, 'Portal username updated')
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.portal_username, 'portal_user')
        self.assertTrue(self.customer.portal_is_active)

    def test_set_custom_pin_allows_setting_portal_active(self):
        edit_url = reverse('customer_edit', args=[self.customer.id])
        resp = self.client.post(edit_url, {'action': 'set_custom_pin', 'custom_pin': '8888', 'portal_is_active': '1'}, follow=True)
        self.assertContains(resp, 'Custom PIN set')
        self.customer.refresh_from_db()
        self.assertTrue(self.customer.check_portal_pin('8888'))
        self.assertTrue(self.customer.portal_is_active)
    def test_portal_profile_update(self):
        # simulate customer logged into portal
        session = self.client.session
        session['customer_portal_id'] = self.customer.id
        session.save()
        # GET the profile page
        get_url = reverse('customer_portal_profile', args=[self.customer.id])
        get_resp = self.client.get(get_url)
        self.assertEqual(get_resp.status_code, 200)
        self.assertContains(get_resp, 'Edit Contact Details')

        url = reverse('customer_portal_update_profile', args=[self.customer.id])
        resp = self.client.post(url, {'email': 'new@example.com', 'whatsapp': '0987654321'}, follow=True)
        self.assertEqual(resp.status_code, 200)
        self.customer.refresh_from_db()
        self.assertEqual(self.customer.email, 'new@example.com')
        self.assertEqual(self.customer.whatsapp_number, '0987654321')
        # message present
        self.assertContains(resp, 'Contact details updated')

    def test_create_customer_username_uniqueness_global(self):
        create_url = reverse('customer_create')
        # attempt to create a new customer with the same portal username as existing one
        self.customer.portal_username = 'existing_user'
        self.customer.save()
        resp = self.client.post(create_url, {
            'first_name': 'New', 'last_name': 'Cust', 'email': 'x@example.com', 'phone_number': '999', 'whatsapp_number': '999', 'address': 'Addr',
            'portal_username': 'existing_user'
        }, follow=True)
        self.assertContains(resp, 'Portal username already taken')

    def test_create_defaults_to_all_can_types_when_none_selected(self):
        # create some can types for the shop
        models.CanType.objects.create(admin=self.user, can_type='Can A', price=10)
        models.CanType.objects.create(admin=self.user, can_type='Can B', price=20)
        create_url = reverse('customer_create')
        resp = self.client.post(create_url, {'first_name': 'New', 'last_name': 'Cust', 'email': 'x@example.com', 'phone_number': '999', 'whatsapp_number': '999', 'address': 'Addr'}, follow=True)
        self.assertEqual(resp.status_code, 200)
        # ensure customer created and assigned both can types
        created = models.Customer.objects.filter(first_name='New', last_name='Cust').first()
        self.assertIsNotNone(created)
        cans = models.CustomerCanType.objects.filter(customer=created)
        self.assertEqual(cans.count(), 2)

    def test_edit_defaults_to_all_can_types_when_none_selected(self):
        # create some can types for the shop
        ct1 = models.CanType.objects.create(admin=self.user, can_type='Can X', price=11)
        ct2 = models.CanType.objects.create(admin=self.user, can_type='Can Y', price=22)
        edit_url = reverse('customer_edit', args=[self.customer.id])
        resp = self.client.post(edit_url, {'action': 'save', 'first_name': 'Name', 'email': self.customer.email, 'phone_number': self.customer.phone_number, 'whatsapp_number': self.customer.whatsapp_number, 'address': self.customer.address, 'month_start_day': self.customer.month_start_day, 'month_end_day': self.customer.month_end_day}, follow=True)
        self.assertEqual(resp.status_code, 200)
        self.customer.refresh_from_db()
        cans = models.CustomerCanType.objects.filter(customer=self.customer)
        self.assertEqual(cans.count(), 2)


    def test_zero_amount_invoice_is_unpaid_by_default(self):
        inv = models.Invoice.objects.create(invoice_number='INV-ZERO', admin=self.user, shop=self.shop, customer=self.customer, total_amount=0, status='unpaid')
        inv.refresh_from_db()
        self.assertEqual(inv.status, 'unpaid')

    def test_customer_can_download_invoice_pdf(self):
        # create invoice and attach a small PDF file
        inv = models.Invoice.objects.create(invoice_number='INV-DL', admin=self.user, shop=self.shop, customer=self.customer, total_amount=50)
        from django.core.files.uploadedfile import SimpleUploadedFile
        inv.pdf_file.save('test.pdf', SimpleUploadedFile('test.pdf', b'PDFDATA', content_type='application/pdf'))
        inv.save()
        session = self.client.session
        session['customer_portal_id'] = self.customer.id
        session.save()
        url = reverse('customer_portal_download_invoice', args=[self.customer.id, inv.id])
        resp = self.client.get(url)
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp['Content-Type'], 'application/pdf')
        self.assertIn('attachment', resp['Content-Disposition'])