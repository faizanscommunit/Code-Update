from django.test import TestCase, Client
from django.urls import reverse
from .models import User, Customer, CanType, DailyDelivery
from datetime import date

class AdminDeliveryCRUDTest(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_user(username='shopowner', password='pass', role='shop_admin')
        self.client = Client()
        self.client.login(username='shopowner', password='pass')
        # related objects
        self.customer = Customer.objects.create(admin=self.admin_user, shop=getattr(self.admin_user, 'shop', None) or None, first_name='Test', last_name='Cust', email='t@example.com', phone_number='0300', whatsapp_number='0300', address='Addr')
        self.can_type1 = CanType.objects.create(admin=self.admin_user, can_type='Small', price=10)
        self.can_type2 = CanType.objects.create(admin=self.admin_user, can_type='Large', price=20)

    def test_create_edit_delete_delivery(self):
        # create via POST
        resp = self.client.post(reverse('admin_delivery_create'), {'customer_id': self.customer.id, 'can_type': self.can_type1.id, 'quantity': '2', 'delivery_date': '2025-12-01', 'entry_date': '2025-11-30'})
        self.assertEqual(resp.status_code, 302)
        dd = DailyDelivery.objects.filter(customer=self.customer).first()
        self.assertIsNotNone(dd)
        self.assertEqual(dd.quantity_delivered, 2)
        # ensure delivery_date respected
        self.assertEqual(dd.delivery_date, date(2025, 12, 1))
        # ensure entry_date respected
        self.assertEqual(dd.entry_date, date(2025, 11, 30))
        # edit via POST
        resp = self.client.post(reverse('admin_delivery_edit', args=[dd.id]), {'customer_id': self.customer.id, 'can_type': self.can_type2.id, 'quantity': '5', 'delivery_date': '2025-12-02'})
        self.assertEqual(resp.status_code, 302)
        dd.refresh_from_db()
        self.assertEqual(dd.quantity_delivered, 5)
        self.assertEqual(int(dd.rate_given), int(self.can_type2.price))
        # delete via POST
        resp = self.client.post(reverse('admin_delivery_delete', args=[dd.id]))
        self.assertEqual(resp.status_code, 302)
        self.assertFalse(DailyDelivery.objects.filter(id=dd.id).exists())

    def test_create_delivery_with_date_attaches_to_existing_invoice(self):
        # create a monthly invoice for Dec 2025
        from .models import Invoice
        invoice = Invoice.objects.create(invoice_number='INV-DEC', admin=self.admin_user, shop=getattr(self.admin_user, 'shop', None) or None, customer=self.customer, total_amount=0, status='unpaid', invoice_year=2025, invoice_month=12)
        # create delivery via POST with date in Dec
        resp = self.client.post(reverse('admin_delivery_create'), {'customer_id': self.customer.id, 'can_type': self.can_type1.id, 'quantity': '2', 'delivery_date': '2025-12-01'})
        self.assertEqual(resp.status_code, 302)
        invoice.refresh_from_db()
        self.assertEqual(invoice.items.count(), 1)
        from decimal import Decimal
        self.assertEqual(invoice.total_amount, Decimal('20.00'))

    def test_customer_specific_can_rate_used_when_assigned(self):
        # assign Large can to customer with custom price
        from .models import CustomerCanType, DailyDelivery
        CustomerCanType.objects.create(admin=self.admin_user, customer=self.customer, can_type=self.can_type2, price=15)
        # submit delivery selecting the assigned can (no explicit rate passed)
        resp = self.client.post(reverse('admin_delivery_create'), {'customer_id': self.customer.id, 'can_type': self.can_type2.id, 'quantity': '1', 'delivery_date': '2025-12-05'})
        self.assertEqual(resp.status_code, 302)
        dd = DailyDelivery.objects.filter(customer=self.customer, can_type=self.can_type2).first()
        self.assertIsNotNone(dd)
        # rate should have been set to assigned price (15)
        self.assertEqual(int(dd.rate_given), 15)

    def test_cannot_create_delivery_with_unassigned_can_when_customer_has_assignments(self):
        from .models import CustomerCanType, DailyDelivery
        # assign only Large (can_type2)
        CustomerCanType.objects.create(admin=self.admin_user, customer=self.customer, can_type=self.can_type2, price=15)
        # try to create delivery using Small (can_type1) -> should be rejected
        resp = self.client.post(reverse('admin_delivery_create'), {'customer_id': self.customer.id, 'can_type': self.can_type1.id, 'quantity': '1', 'delivery_date': '2025-12-06'})
        # redirect back to create page on error, no delivery created
        self.assertEqual(resp.status_code, 302)
        self.assertFalse(DailyDelivery.objects.filter(customer=self.customer).exists())


