from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from . import models as mmodels
from decimal import Decimal
from datetime import date

class DeliveryInvoiceSyncTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(username='admin', password='pass', role='shop_admin')
        # ensure shop relation exists
        if not hasattr(self.user, 'shop') or not getattr(self.user, 'shop', None):
            self.user.shop = mmodels.Shop.objects.create(name='S', admin=self.user)
            self.user.save()
        self.customer = mmodels.Customer.objects.create(first_name='C', last_name='L', phone_number='+923001234567', shop=self.user.shop)
        self.can_type = mmodels.CanType.objects.create(admin=self.user, can_type='Small', price=10)

    def test_new_delivery_added_attaches_to_existing_monthly_invoice(self):
        # create invoice for Jan 2026
        inv = mmodels.Invoice.objects.create(invoice_number='INV-JAN', admin=self.user, shop=self.user.shop, customer=self.customer, total_amount=0, status='unpaid', invoice_year=2026, invoice_month=1)
        # ensure no items initially
        self.assertEqual(inv.items.count(), 0)

        # create delivery in Jan
        d = mmodels.DailyDelivery.objects.create(admin=self.user, customer=self.customer, can_type=self.can_type, quantity_delivered=2, rate_given=Decimal('10'), delivery_date=date(2026,1,15))

        inv.refresh_from_db()
        self.assertEqual(inv.items.count(), 1)
        self.assertEqual(inv.total_amount, Decimal('20.00'))

    def test_delivery_update_updates_invoice_totals(self):
        inv = mmodels.Invoice.objects.create(invoice_number='INV-JAN-2', admin=self.user, shop=self.user.shop, customer=self.customer, total_amount=0, status='unpaid', invoice_year=2026, invoice_month=1)
        d = mmodels.DailyDelivery.objects.create(admin=self.user, customer=self.customer, can_type=self.can_type, quantity_delivered=2, rate_given=Decimal('10'), delivery_date=date(2026,1,10))
        inv.refresh_from_db()
        self.assertEqual(inv.total_amount, Decimal('20.00'))
        # update delivery qty
        d.quantity_delivered = 3
        d.save()
        inv.refresh_from_db()
        self.assertEqual(inv.total_amount, Decimal('30.00'))

    def test_delivery_move_between_months_moves_invoice_item(self):
        inv_jan = mmodels.Invoice.objects.create(invoice_number='INV-JAN-3', admin=self.user, shop=self.user.shop, customer=self.customer, total_amount=0, status='unpaid', invoice_year=2026, invoice_month=1)
        inv_feb = mmodels.Invoice.objects.create(invoice_number='INV-FEB-3', admin=self.user, shop=self.user.shop, customer=self.customer, total_amount=0, status='unpaid', invoice_year=2026, invoice_month=2)
        d = mmodels.DailyDelivery.objects.create(admin=self.user, customer=self.customer, can_type=self.can_type, quantity_delivered=1, rate_given=Decimal('10'), delivery_date=date(2026,1,5))
        inv_jan.refresh_from_db()
        self.assertEqual(inv_jan.total_amount, Decimal('10.00'))
        # move to feb
        d.delivery_date = date(2026,2,6)
        d.save()
        inv_jan.refresh_from_db()
        inv_feb.refresh_from_db()
        self.assertEqual(inv_jan.total_amount, Decimal('0.00'))
        self.assertEqual(inv_feb.total_amount, Decimal('10.00'))
