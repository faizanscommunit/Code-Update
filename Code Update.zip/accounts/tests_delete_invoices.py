from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.urls import reverse
from . import models
import os
from django.conf import settings

User = get_user_model()

class InvoiceDeletionTests(TestCase):
    def setUp(self):
        # create a shop admin user
        self.user = User.objects.create_user(username='admin', password='pass', role='shop_admin')
        self.user.shop = models.Shop.objects.create(name='Test Shop', admin=self.user)
        self.user.save()
        self.client = Client()
        self.client.login(username='admin', password='pass')

    def _create_invoice_with_payment_and_pdf(self, invoice_number='INV-TEST'):
        cust = models.Customer.objects.create(admin=self.user, shop=self.user.shop, first_name='John', last_name='Doe', email='a@example.com', phone_number='123', whatsapp_number='123', address='X')
        inv = models.Invoice.objects.create(invoice_number=invoice_number, admin=self.user, shop=self.user.shop, customer=cust, total_amount=100, status='unpaid')
        # attach a fake pdf file
        f = SimpleUploadedFile(name='test.pdf', content=b'testpdf', content_type='application/pdf')
        inv.pdf_file.save('test.pdf', f)
        inv.save()
        p = models.Payment.objects.create(invoice=inv, admin=self.user, shop=self.user.shop, payer_customer=cust, amount=100, method='cash', status='completed')
        return inv, p

    def test_delete_invoice_deletes_payments_and_pdf(self):
        inv, p = self._create_invoice_with_payment_and_pdf('INV-DEL-1')
        # ensure file exists
        file_path = os.path.join(settings.MEDIA_ROOT, inv.pdf_file.name)
        self.assertTrue(os.path.exists(file_path))
        # delete via view
        resp = self.client.post(reverse('delete_invoice', args=[inv.id]))
        self.assertRedirects(resp, reverse('invoices_list'))
        # invoice is gone
        self.assertFalse(models.Invoice.objects.filter(id=inv.id).exists())
        # payment should be deleted because of CASCADE
        self.assertFalse(models.Payment.objects.filter(id=p.id).exists())
        # file removed
        self.assertFalse(os.path.exists(file_path))

    def test_delete_all_invoices_deletes_all(self):
        inv1, p1 = self._create_invoice_with_payment_and_pdf('INV-ALL-1')
        inv2, p2 = self._create_invoice_with_payment_and_pdf('INV-ALL-2')
        file1 = os.path.join(settings.MEDIA_ROOT, inv1.pdf_file.name)
        file2 = os.path.join(settings.MEDIA_ROOT, inv2.pdf_file.name)
        self.assertTrue(os.path.exists(file1))
        self.assertTrue(os.path.exists(file2))
        resp = self.client.post(reverse('delete_all_invoices'), follow=True)
        self.assertRedirects(resp, reverse('invoices_list'))
        self.assertFalse(models.Invoice.objects.filter(admin=self.user).exists())
        self.assertFalse(models.Payment.objects.filter(admin=self.user).exists())
        self.assertFalse(os.path.exists(file1))
        self.assertFalse(os.path.exists(file2))

        # message should report number of invoices deleted (not total cascading deletions)
        from django.contrib.messages import get_messages
        messages = list(get_messages(resp.wsgi_request))
        self.assertTrue(any('Deleted 2 invoice' in str(m) for m in messages))

    def test_delete_filtered_invoices_by_customer_and_month(self):
        cust1 = models.Customer.objects.create(admin=self.user, shop=self.user.shop, first_name='Alice', last_name='Smith', email='a1@example.com', phone_number='111', whatsapp_number='111', address='A')
        cust2 = models.Customer.objects.create(admin=self.user, shop=self.user.shop, first_name='Bob', last_name='Jones', email='b1@example.com', phone_number='222', whatsapp_number='222', address='B')
        inv1 = models.Invoice.objects.create(invoice_number='INV-FILT-1', admin=self.user, shop=self.user.shop, customer=cust1, total_amount=100, status='unpaid', invoice_year=2024, invoice_month=5)
        inv2 = models.Invoice.objects.create(invoice_number='INV-FILT-2', admin=self.user, shop=self.user.shop, customer=cust2, total_amount=200, status='unpaid', invoice_year=2024, invoice_month=5)

        resp = self.client.post(reverse('delete_filtered_invoices'), {
            'customer_id': str(cust1.id),
            'month': '2024-05',
        }, follow=True)

        self.assertRedirects(resp, reverse('invoices_list'))
        self.assertFalse(models.Invoice.objects.filter(id=inv1.id).exists())
        self.assertTrue(models.Invoice.objects.filter(id=inv2.id).exists())

        from django.contrib.messages import get_messages
        messages = list(get_messages(resp.wsgi_request))
        self.assertTrue(any('Deleted 1 filtered invoice' in str(m) for m in messages))
