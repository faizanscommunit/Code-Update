from django.test import TestCase, Client
from django.urls import reverse
from . import models
from django.contrib.auth import get_user_model
from datetime import date
from decimal import Decimal

User = get_user_model()

class PartialInvoiceGenerationTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='admin2', password='pass', role='shop_admin')
        self.shop = models.Shop.objects.create(name='Partial Shop', admin=self.user)
        # customer 1 has deliveries
        self.cust1 = models.Customer.objects.create(admin=self.user, shop=self.shop, first_name='Alpha', last_name='One', email='a@one.com', phone_number='111', whatsapp_number='111', address='Addr')
        models.DailyDelivery.objects.create(admin=self.user, customer=self.cust1, rate_given=50, quantity_delivered=1, delivery_date=date(2026,1,5), can_type=models.CanType.objects.create(admin=self.user, can_type='ct1', price=50))
        # customer 2 has deliveries
        self.cust2 = models.Customer.objects.create(admin=self.user, shop=self.shop, first_name='Beta', last_name='Two', email='b@two.com', phone_number='222', whatsapp_number='222', address='Addr')
        models.DailyDelivery.objects.create(admin=self.user, customer=self.cust2, rate_given=75, quantity_delivered=2, delivery_date=date(2026,1,12), can_type=models.CanType.objects.create(admin=self.user, can_type='ct2', price=75))
        self.client = Client()
        self.client.force_login(self.user)

    def test_partial_generation_creates_missing_invoice(self):
        # Manually create invoice for cust1 only
        inv_existing = models.Invoice.objects.create(invoice_number='INV-C1', admin=self.user, shop=self.shop, customer=self.cust1, total_amount=0, status='unpaid', invoice_year=2026, invoice_month=1)
        # Now run generation for Jan 2026
        url = reverse('auto_generate_invoices')
        resp = self.client.post(url, {'month': '2026-01'}, follow=True)
        # Should have created an invoice for cust2 only -> total invoices = 2
        self.assertEqual(models.Invoice.objects.filter(admin=self.user, invoice_year=2026, invoice_month=1).count(), 2)
        # Check message mentions created count of 1
        self.assertContains(resp, 'Created 1 invoice(s) for Jan 2026')
