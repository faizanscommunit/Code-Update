from django.test import TestCase, override_settings
from django.urls import reverse
from django.contrib.auth import get_user_model
from unittest.mock import patch
from . import models as mmodels


class WhatsAppMetaTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(username='admin', password='pass', role='shop_admin')
        # create customer
        self.customer = mmodels.Customer.objects.create(first_name='C', last_name='L', phone_number='+923001234567', admin=self.user)
        # create invoice
        self.invoice = mmodels.Invoice.objects.create(admin=self.user, customer=self.customer, invoice_number='INV1', total_amount=100)

    @override_settings(META_WHATSAPP_PHONE_NUMBER_ID='12345', META_WHATSAPP_ACCESS_TOKEN='token_abcd')
    @patch('accounts.views.requests.post')
    def test_send_whatsapp_via_meta(self, mock_post):
        mock_resp = mock_post.return_value
        mock_resp.status_code = 200
        mock_resp.json.return_value = {'messages': [{'id': 'gBEGkYiEB1VXAglK1ZEqA1YKPrU'}]}
        mock_resp.raise_for_status.return_value = None

        self.client.login(username='admin', password='pass')
        url = reverse('send_invoice', args=[self.invoice.id])
        resp = self.client.post(url, {'method': 'whatsapp_api', 'message': 'Test message'})
        # should redirect back to invoice
        self.assertEqual(resp.status_code, 302)
        mock_post.assert_called()
        called_url = mock_post.call_args[0][0]
        self.assertIn('12345', called_url)
