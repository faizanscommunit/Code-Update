from django.urls import path
from . import views, profit_loss_view, customer_views, invoice_views
from dairy import settings
from django.conf.urls.static import static
from django.urls import include

urlpatterns = [
    path('', views.admin_dashboard, name='admin_dashboard'),
    path('terms/', views.terms, name='terms'),
    path("record-delivery/", views.record_delivery, name="record_delivery"),
    
    # Invoices
    path("view-bill/", views.view_bill_home, name="view_bill"),
    path("generate_bill/<int:customer_id>", views.generate_bill, name="generate_bill"),
    path("invoices/", invoice_views.invoices_list, name='invoices_list'),
    path("invoices/send-all/", invoice_views.send_all_invoices, name='send_all_invoices'),
    path("invoices/auto-generate/", invoice_views.auto_generate_invoices, name='auto_generate_invoices'),
    path("invoices/delete-filtered/", invoice_views.delete_filtered_invoices, name='delete_filtered_invoices'),
    path("invoices/delete-all/", invoice_views.delete_all_invoices, name='delete_all_invoices'),
    path("invoices/download-all/", invoice_views.download_all_invoices, name='download_all_invoices'),
    path("invoice/<int:invoice_id>/", invoice_views.invoice_detail, name='invoice_detail'),
    path("invoice/<int:invoice_id>/delete/", invoice_views.delete_invoice, name='delete_invoice'),
    path("invoice/<int:invoice_id>/generate-pdf/", invoice_views.generate_invoice_pdf, name='generate_invoice_pdf'),
    path("invoice/<int:invoice_id>/download/", invoice_views.download_invoice_pdf, name='download_invoice_pdf'),
    path("invoice/<int:invoice_id>/send/", views.send_invoice, name='send_invoice'),
    path("invoice/<int:invoice_id>/pay/", invoice_views.record_payment, name='invoice_pay'),
    path("invoice/<int:invoice_id>/mark-paid/", invoice_views.mark_invoice_paid, name='mark_invoice_paid'),
    
    # Payments
    path("payments/", views.payments_list, name='payments_list'),
    path("payments/search/", views.payments_search, name='payments_search'),
    path("invoices/search/", views.invoices_search, name='invoices_search'),
    path("payment/<int:payment_id>/", views.payment_detail, name='payment_detail'),
    path("payment/<int:payment_id>/edit/", views.payment_edit, name='payment_edit'),
    path("payment/<int:payment_id>/delete/", views.delete_payment, name='delete_payment'),
    path("payments/delete-all/", views.delete_all_payments, name='delete_all_payments'),
    path("payment/<int:payment_id>/mark-received/", views.mark_payment_received, name='mark_payment_received'),
    path("receive-payment/", views.receive_payment, name='receive_payment'),
    path("webhook/payment/", views.payment_webhook, name='payment_webhook'),
    # AJAX endpoint: unpaid invoices/deliveries for a customer
    path('customers/<int:customer_id>/unpaid/', views.customer_unpaid_json, name='customer_unpaid_json'),

    # Customers
    path("customers/", views.customers_list, name='customers_list'),
    path("customers/search/", views.customers_search, name='customers_search'),
    path("customer/create/", customer_views.customer_create, name='customer_create'),
    path("customer/<int:customer_id>/edit/", customer_views.customer_edit, name='customer_edit'),
    # Hard delete (existing — keeps your original view for permanent deletion if needed)
    path("customer/<int:customer_id>/delete/", views.customer_delete, name='customer_delete'),
    # Soft delete — archives the customer without destroying any financial records
    path("customer/<int:customer_id>/archive/", customer_views.customer_soft_delete, name='customer_soft_delete'),
    # Can statement (ledger)
    path("customers/<int:customer_id>/can-statement/", views.can_statement, name='can_statement'),
    path("customers/<int:customer_id>/can-statement/add-opening/", views.add_opening_balance, name='add_opening_balance'),
    path("customers/<int:customer_id>/can-statement/add-adjustment/", views.add_adjusting_entry, name='add_adjusting_entry'),

    # Deliveries (admin)
    path("deliveries/", views.deliveries_list, name='deliveries_list'),
    path("deliveries/create/", views.admin_delivery_create, name='admin_delivery_create'),
    path("deliveries/<int:delivery_id>/edit/", views.admin_delivery_edit, name='admin_delivery_edit'),
    path("deliveries/<int:delivery_id>/delete/", views.admin_delivery_delete, name='admin_delivery_delete'),

    # Staff management (employees)
    path("staff/", views.staff_list, name='staff_list'),
    path("staff/create/", views.staff_create, name='staff_create'),
    path("staff/<int:staff_id>/edit/", views.staff_edit, name='staff_edit'),
    path("staff/<int:staff_id>/delete/", views.staff_delete, name='staff_delete'),
    path("staff/<int:staff_id>/deliveries/", views.staff_deliveries, name='staff_deliveries'),

    # Can types (shop admin pages)
    path('can-types/', views.can_types_list, name='can_types_list'),
    path('can-types/create/', views.can_type_create, name='can_type_create'),
    path('can-types/<int:can_type_id>/edit/', views.can_type_edit, name='can_type_edit'),
    path('can-types/<int:can_type_id>/delete/', views.can_type_delete, name='can_type_delete'),

    path('logout/', views.user_logout, name='logout'),
    path("login/", views.loginUser, name="login"),
    # redirect after login based on role
    path("role-redirect/", views.role_redirect, name="role_redirect"),

    # Profile
    path('profile/', views.profile, name='profile'),

    # Customer Portal
    path('customer-portal/', views.customer_dashboard, name='customer_portal'),
    path('customer-portal/invoices/', views.customer_portal_invoices, name='customer_portal_invoices'),
    path('customer-portal/payments/', views.customer_portal_payments, name='customer_portal_payments'),
    path('customer-portal/<int:customer_id>/invoice/<int:invoice_id>/download/', views.customer_portal_download_invoice, name='customer_portal_download_invoice'),

    # Delivery Assignment
    # add these to urlpatterns
    path('assignments/',                        views.assignments_list,   name='assignments_list'),
    path('assignments/create/',                 views.assignment_create,  name='assignment_create'),
    path('assignments/<int:assignment_id>/delete/', views.assignment_delete, name='assignment_delete'),
    path('rider/dashboard/',                    views.rider_dashboard,    name='rider_dashboard'),
    path('rider/mark-done/<int:assignment_id>/', views.rider_mark_done,  name='rider_mark_done'),
    path('rider/mark-failed/<int:assignment_id>/', views.rider_mark_failed, name='rider_mark_failed'),
    # Recent activities JSON endpoint used by topbar dropdown
    path('recent-activities/', views.recent_activities, name='recent_activities'),

    # Expense
    path('expenses/', include('accounts.expense_urls')),

    # Website
    path('website/', views.website, name='website'),
    path('shop/<slug:slug>/', views.public_shop_page, name='public_shop_page'),

    # Profit and Loss Statement
    path(
        "profit-loss/",
        profit_loss_view.profit_loss_statement,
        name="profit_loss_statement",
    ),
    
]

# safe fallback for test_smtp: avoid import-time AttributeError if view is not present
from django.http import HttpResponseNotFound
try:
    test_smtp_view = views.test_smtp
except AttributeError:
    def test_smtp_view(request):
        return HttpResponseNotFound('test_smtp view not available')

# append the pattern
urlpatterns += [
    path('profile/test-smtp/', test_smtp_view, name='test_smtp'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)