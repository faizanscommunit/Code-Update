# -------------------- models.py --------------------
from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from decimal import Decimal
from django.contrib.auth.hashers import make_password, check_password
from django.utils.translation import gettext_lazy as _
from django.db.models import Q, Sum
"""
PATCH — Drop this into your models.py to replace Invoice + InvoiceItem.

Changes
-------
* InvoiceItem  — adds `discount_amount` and `tax_amount` columns; `save()` now
                 honours the linked customer's discount_percent / tax_rate /
                 is_tax_exempt settings and stores percentage discount per line.
* Invoice      — applies `customer.discount_flat` once at invoice total level
                 rather than to every item line.
* New helper   — `compute_line_totals(qty, unit_price, customer)` can be called
                 anywhere (views, management commands) to get a consistent dict of
                 {gross, discount, tax, net} without touching the DB.

How discount/tax is applied (per line)
---------------------------------------
  gross      = qty × unit_price
  disc_pct   = customer.discount_percent  (0-100, default 0)
  discount   = gross × (disc_pct / 100)        ← capped at gross
  after_disc = gross − discount
  tax        = after_disc × (tax_rate / 100)  if not is_tax_exempt else 0
  net        = after_disc + tax
  line_total = net   ← this is what's stored and summed on the invoice

No other files need to change for the maths; the view/template simply reads
the new columns.
"""

from decimal import Decimal
from django.db import models
from django.db.models import Q, Sum
from django.utils import timezone
from django.conf import settings
from django.utils.translation import gettext_lazy as _


# ──────────────────────────────────────────────────────────────────────────────
# STANDALONE HELPER  (import-able from views / management commands)
# ──────────────────────────────────────────────────────────────────────────────
def compute_line_totals(qty, unit_price, customer=None):
    """
    Compute line amounts for one InvoiceItem.
 
    Since discount and tax are applied at INVOICE TOTAL level (not per line),
    this function returns gross = qty × unit_price with no deductions.
    The customer parameter is accepted for API compatibility but not used here.
 
    Returns
    -------
    {
        'gross'      : Decimal,   # qty × unit_price
        'discount'   : Decimal,   # always 0  (applied at invoice level)
        'after_disc' : Decimal,   # same as gross
        'tax'        : Decimal,   # always 0  (applied at invoice level)
        'net'        : Decimal,   # same as gross  (line_total = gross)
    }
    """
    qty        = Decimal(str(qty or 0))
    unit_price = Decimal(str(unit_price or 0))
    gross      = qty * unit_price
 
    return {
        'gross':      gross.quantize(Decimal('0.01')),
        'discount':   Decimal('0.00'),
        'after_disc': gross.quantize(Decimal('0.01')),
        'tax':        Decimal('0.00'),
        'net':        gross.quantize(Decimal('0.01')),
    }
 

# ──────────────────────────────────────────────────────────────────────────────
# INVOICE MODEL  (replace the existing class entirely)
# ──────────────────────────────────────────────────────────────────────────────

class Invoice(models.Model):
    STATUS_CHOICES = (
        ("draft",      "Draft"),
        ("unpaid",     "Unpaid"),
        ("partial",    "Partially Paid"),
        ("paid",       "Paid"),
        ("cancelled",  "Cancelled"),
    )

    invoice_number = models.CharField(max_length=50, unique=True)
    admin          = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="invoices", verbose_name="Shop Owner"
    )
    shop     = models.ForeignKey("Shop",     on_delete=models.CASCADE, related_name="invoices")
    customer = models.ForeignKey("Customer", on_delete=models.CASCADE, related_name="invoices")

    # Cached summary columns — kept in sync by save()
    subtotal       = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))
    total_discount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))
    total_tax      = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))
    total_amount   = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0'))

    due_date = models.DateField(null=True, blank=True)
    status   = models.CharField(max_length=20, choices=STATUS_CHOICES, default="unpaid")
    notes    = models.TextField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    pdf_file   = models.FileField(
        upload_to='invoices/', null=True, blank=True,
        help_text="Generated invoice PDF"
    )

    invoice_year  = models.PositiveSmallIntegerField(
        null=True, blank=True,
        help_text="Year of invoice (for monthly invoices)"
    )
    invoice_month = models.PositiveSmallIntegerField(
        null=True, blank=True,
        help_text="Month (1-12) of invoice (for monthly invoices)"
    )

    # ── Rate snapshots — frozen at invoice creation, never updated ───────────
    discount_percent_snapshot = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal('0.00'),
        help_text="Customer discount % at time of invoice creation — never changes"
    )
    discount_flat_snapshot = models.DecimalField(
        max_digits=8, decimal_places=2, default=Decimal('0.00'),
        help_text="Customer flat discount at time of invoice creation — never changes"
    )
    tax_rate_snapshot = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal('0.00'),
        help_text="Customer tax rate % at time of invoice creation — never changes"
    )
    is_tax_exempt_snapshot = models.BooleanField(
        default=True,
        help_text="Customer tax exempt status at time of invoice creation — never changes"
    )
    snapshots_frozen = models.BooleanField(
        default=False,
        help_text="True once snapshots have been set — prevents overwrite on subsequent saves"
    )

    # ── helpers ──────────────────────────────────────────────────────────────

    def __str__(self):
        return f"{self.invoice_number} - {self.customer.display_name}"

    def get_delivery_ids(self):
        try:
            return [d for d in self.items.values_list('delivery', flat=True) if d]
        except Exception:
            return []

    def get_paid_total(self):
        """Sum of completed payments applied to this invoice or its deliveries."""
        try:
            from django.apps import apps
            Payment = apps.get_model('accounts', 'Payment')
            delivery_ids = self.get_delivery_ids()
            paid = Payment.objects.filter(status='completed').filter(
                Q(invoice=self) | Q(delivery_id__in=delivery_ids)
            ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
            return paid
        except Exception:
            return Decimal('0')

    def get_effective_total(self):
        """
        Preferred invoice total.

        Priority:
          1. Sum of item line_totals (already net of discount + tax) when items exist.
          2. Stored total_amount as fallback (e.g. manually set invoices).
        """
        items_total = Decimal('0')
        try:
            for it in self.items.all():
                items_total += (it.line_total or Decimal('0'))
        except Exception:
            items_total = Decimal('0')

        if items_total > Decimal('0'):
            return items_total
        return self.total_amount or Decimal('0')

    def get_subtotal(self):
        """Gross before any discount/tax — sum of (qty × unit_price) across items."""
        try:
            return sum(
                (it.gross_amount or Decimal('0')) for it in self.items.all()
            )
        except Exception:
            return self.subtotal or Decimal('0')

    def get_total_discount(self):
        try:
            return self.total_discount or Decimal('0')
        except Exception:
            return Decimal('0')

    def get_total_tax(self):
        try:
            return self.total_tax or Decimal('0')
        except Exception:
            return Decimal('0')

    def get_remaining(self):
        eff  = self.get_effective_total() or Decimal('0')
        paid = self.get_paid_total()      or Decimal('0')
        return max(eff - paid, Decimal('0'))

    @property
    def remaining(self):
        return self.get_remaining()

    # ── save ─────────────────────────────────────────────────────────────────

    def _freeze_rate_snapshots(self):
        if self.snapshots_frozen:
            return

        customer = None
        try:
            customer = self.customer
        except Exception:
            pass

        if customer:
            try:
                self.discount_percent_snapshot = Decimal(str(customer.discount_percent or 0))
            except Exception:
                pass
            try:
                self.discount_flat_snapshot = Decimal(str(customer.discount_flat or 0))
            except Exception:
                pass
            try:
                self.is_tax_exempt_snapshot = bool(customer.is_tax_exempt)
            except Exception:
                pass
            if not self.is_tax_exempt_snapshot:
                try:
                    self.tax_rate_snapshot = Decimal(str(customer.tax_rate or 0))
                except Exception:
                    pass

        self.snapshots_frozen = True

    def _recompute_summary(self):
        """
        Rebuild cached summary columns from items.
 
        Discount and tax are applied on the SUBTOTAL (sum of all gross line amounts),
        not on individual lines. This matches the business rule: discount and tax
        are negotiated at contract/invoice level.
 
        Flow:
            subtotal       = Σ(gross_amount per item)
            pct_discount   = subtotal × (snapshot_discount_percent / 100)
            total_discount = pct_discount + snapshot_discount_flat
            after_discount = subtotal − total_discount    (floored at 0)
            total_tax      = after_discount × (snapshot_tax_rate / 100)  if not exempt
            total_amount   = after_discount + total_tax
        """
        sub = Decimal('0')
        try:
            for it in self.items.all():
                sub += (it.gross_amount or Decimal('0'))
        except Exception:
            pass
 
        discount_pct  = Decimal('0')
        discount_flat = Decimal('0')
        tax_rate      = Decimal('0')
        is_exempt     = True
 
        if self.snapshots_frozen:
            discount_pct  = self.discount_percent_snapshot or Decimal('0')
            discount_flat = self.discount_flat_snapshot or Decimal('0')
            tax_rate      = self.tax_rate_snapshot or Decimal('0')
            is_exempt     = self.is_tax_exempt_snapshot
        else:
            customer = None
            try:
                customer = self.customer
            except Exception:
                pass
            if customer:
                try:
                    discount_pct = Decimal(str(customer.discount_percent or 0))
                except Exception:
                    pass
                try:
                    discount_flat = Decimal(str(customer.discount_flat or 0))
                except Exception:
                    pass
                try:
                    is_exempt = bool(customer.is_tax_exempt)
                except Exception:
                    pass
                if not is_exempt:
                    try:
                        tax_rate = Decimal(str(customer.tax_rate or 0))
                    except Exception:
                        pass
 
        pct_disc       = sub * discount_pct / Decimal('100')
        total_disc     = pct_disc + discount_flat
        after_discount = max(sub - total_disc, Decimal('0'))
        total_tax      = (after_discount * tax_rate / Decimal('100')) if not is_exempt else Decimal('0')
        net            = after_discount + total_tax
 
        self.subtotal       = sub
        self.total_discount = total_disc
        self.total_tax      = total_tax
        self.total_amount   = max(net, Decimal('0'))
        
    def save(self, *args, **kwargs):
        if self.total_amount is None:
            self.total_amount = Decimal('0')

        if not self.snapshots_frozen:
            self._freeze_rate_snapshots()

        # Recompute summary from items (no-op on first save before items exist)
        self._recompute_summary()

        effective_total = self.get_effective_total()

        paid_total = Decimal('0')
        if self.pk:
            try:
                from django.apps import apps
                Payment = apps.get_model('accounts', 'Payment')
                delivery_ids = self.get_delivery_ids()
                paid_total = Payment.objects.filter(status='completed').filter(
                    Q(invoice=self) | Q(delivery_id__in=delivery_ids)
                ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
            except Exception:
                paid_total = Decimal('0')

        # Status decision
        if effective_total == Decimal('0'):
            if paid_total > Decimal('0') or self.status == 'paid':
                self.status = 'paid'
            else:
                self.status = 'unpaid'
        else:
            if paid_total >= effective_total:
                self.status = 'paid'
            elif paid_total > Decimal('0'):
                self.status = 'partial'
            else:
                self.status = 'unpaid'

        super().save(*args, **kwargs)

        # Mark linked deliveries as paid when invoice is fully paid
        try:
            if self.status == 'paid':
                for it in self.items.select_related('delivery').all():
                    if it.delivery and getattr(it.delivery, 'payment_status', None) != 'paid':
                        try:
                            it.delivery.payment_status = 'paid'
                            it.delivery.save()
                        except Exception:
                            pass
        except Exception:
            pass

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['customer', 'invoice_year', 'invoice_month'],
                name='unique_customer_invoice_month_year'
            )
        ]


# ──────────────────────────────────────────────────────────────────────────────
# INVOICE ITEM MODEL  (replace the existing class entirely)
# ──────────────────────────────────────────────────────────────────────────────

class InvoiceItem(models.Model):
    invoice  = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name="items")
    delivery = models.ForeignKey(
        "DailyDelivery", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="invoice_items"
    )
    description = models.CharField(max_length=255)
    quantity    = models.DecimalField(max_digits=8,  decimal_places=2, default=Decimal("0.00"))
    unit_price  = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, default=Decimal("0.00"))

    # ── NEW columns ───────────────────────────────────────────────────────────
    gross_amount    = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"),
                                         help_text="qty × unit_price before any discount/tax")
    discount_amount = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"),
                                         help_text="Discount applied to this line")
    tax_amount      = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"),
                                         help_text="Tax applied after discount")
    # ─────────────────────────────────────────────────────────────────────────

    line_total = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"),
                                     help_text="Net amount = gross − discount + tax")

    def save(self, *args, **kwargs):
        # Pull values from linked delivery when fields are missing
        if self.delivery:
            if not self.description:
                self.description = f"Delivery #{self.delivery.id}"
            if (self.quantity is None or self.quantity == Decimal("0.00")) and getattr(self.delivery, "quantity_delivered", None) is not None:
                self.quantity = self.delivery.quantity_delivered
            if (self.unit_price is None or self.unit_price == Decimal("0.00")) and getattr(self.delivery, "rate_given", None) is not None:
                self.unit_price = self.delivery.rate_given
 
        qty        = self.quantity   or Decimal("0.00")
        unit_price = self.unit_price or Decimal("0.00")
 
        # IMPORTANT: Discount and tax are applied at INVOICE TOTAL level, not per line.
        # Line items store raw gross only.
        gross = qty * unit_price
 
        self.gross_amount    = gross
        self.discount_amount = Decimal("0.00")   # no per-line discount
        self.tax_amount      = Decimal("0.00")   # no per-line tax
        self.line_total      = gross              # line_total = gross
 
        super().save(*args, **kwargs)


from django.db import transaction
from django.core.exceptions import ValidationError

# -------------------- Account Receivable Ledger --------------------
from django.db import models, transaction
from django.core.exceptions import ValidationError
from decimal import Decimal
from django.db.models import Q

# Accounts Receivable ka Ledger hai ye Grok se banaya hai 
class ReceivableLedger(models.Model):
     """Har customer ka alag Account Receivable Ledger (simple & automatic)"""

     admin = models.ForeignKey(
          settings.AUTH_USER_MODEL, 
          on_delete=models.CASCADE, 
          related_name="receivable_ledgers",
          verbose_name="Shop Owner"
     )
     shop = models.ForeignKey("Shop", on_delete=models.CASCADE, related_name="receivable_ledgers")
     customer = models.ForeignKey("Customer", on_delete=models.CASCADE, related_name="receivable_ledgers")

     date = models.DateField(default=timezone.now)
     created_at = models.DateTimeField(auto_now_add=True)

     TRANSACTION_TYPE_CHOICES = (
          ('opening', 'Opening Balance'),
          ('delivery', 'Delivery / Sale'),
          ('payment', 'Payment Received'),
          ('adjustment', 'Adjustment'),
     )
     transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPE_CHOICES, default='delivery')

     # Source links (audit trail ke liye)
     delivery = models.ForeignKey(
          'DailyDelivery', 
          on_delete=models.SET_NULL, 
          null=True, blank=True, 
          related_name='ledger_entry'
     )
     #  add option for invoice 
     invoice = models.ForeignKey(
          'Invoice', 
          on_delete=models.CASCADE,
          null=True,
          blank=True,
          related_name = "invoice_ledger_entry",
     )
     payment = models.ForeignKey(
          'Payment', 
          on_delete=models.CASCADE, 
          null=True, blank=True, 
          related_name='ledger_entries',
          unique=False,
     )

     debit = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))   # Sale / Debit
     credit = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))  # Payment / Credit
     balance_after = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal('0.00'))

     description = models.CharField(max_length=255, blank=True)
     notes = models.TextField(blank=True, null=True)

     class Meta:
          ordering = ['customer', 'date', 'id']
          unique_together = [
               ('delivery', 'transaction_type'),   # ek delivery ka sirf ek ledger entry
               ('payment', 'transaction_type'),
          ]
          indexes = [
               models.Index(fields=['customer', 'date']),
          ]

     def __str__(self):
          return f"{self.customer.display_name} | {self.get_transaction_type_display()} | {self.date} | Bal: {self.balance_after}"

     def save(self, *args, **kwargs):
          """Running balance maintain karta hai (CanTransaction jaisa logic)"""
          if not self.customer_id or not self.admin_id:
               raise ValidationError('ReceivableLedger must have customer and admin.')

          current_id = self.id or 0

          # Opening balance sirf pehli entry ho sakti hai
          if self.transaction_type == 'opening':
               if ReceivableLedger.objects.filter(
                    customer=self.customer, admin=self.admin, transaction_type='opening'
               ).exclude(id=self.id).exists():
                    raise ValidationError('Ek customer ke liye sirf ek Opening Balance ho sakti hai.')

          with transaction.atomic():
               base_qs = ReceivableLedger.objects.select_for_update().filter(
                    customer=self.customer, admin=self.admin
               )

               # Previous balance (exclude opening balances from calculation)
               if self.id:
                    prev = base_qs.exclude(id=self.id).exclude(transaction_type='opening').filter(
                         Q(date__lt=self.date) | Q(date=self.date, id__lt=self.id)
                    ).order_by('-date', '-id').first()
               else:
                    prev = base_qs.exclude(transaction_type='opening').filter(date__lte=self.date).order_by('-date', '-id').first()

               prev_balance = prev.balance_after if prev else Decimal('0')

               # Current transaction ka net effect
               net = self.debit - self.credit
               running = prev_balance + net

               if running < 0 and self.transaction_type != 'opening':
                    # Negative balance allowed nahi (optional - agar chaaho to allow kar sakte hain)
                    pass

               self.balance_after = running

               super().save(*args, **kwargs)

               # Baad ki sab entries ka balance update karo
               later_entries = base_qs.exclude(id=self.id).filter(
                    Q(date__gt=self.date) | Q(date=self.date, id__gt=self.id)
               ).order_by('date', 'id')

               current = running
               for entry in later_entries:
                    current += (entry.debit - entry.credit)
                    if entry.balance_after != current:
                         ReceivableLedger.objects.filter(id=entry.id).update(balance_after=current)

          # Customer ke outstanding_balance ko bhi sync kar do (optional but recommended)
          try:
               self.customer.outstanding_balance = self.customer.get_outstanding_balance()
               self.customer.save(update_fields=['outstanding_balance'])
          except:
               pass


class Payment(models.Model):
     METHOD_CHOICES = (
          ("cash", "Cash"),
          ("bank_transfer", "Bank Transfer"),
          ("card", "Card"),
          ("other", "Other"),
     )
     STATUS_CHOICES = (
          ("completed", "Completed"),
          ("refunded", "Refunded"),
     )
     # When an Invoice is removed, cascade and delete associated Payment records to keep data consistent
     invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, null=True, blank=True, related_name="payments")
     # Optional: link a payment directly to a DailyDelivery entry (payment received for a single delivery)
     # When a delivery entry is deleted, cascade and delete associated Payment records
     delivery = models.ForeignKey('DailyDelivery', on_delete=models.CASCADE, null=True, blank=True, related_name='payments')
     admin = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="payments", verbose_name="Shop Owner")
     shop = models.ForeignKey("Shop", on_delete=models.CASCADE, related_name="payments")

     # optional: who actually paid (customer). If null this might be a shop/platform payment.
     payer_customer = models.ForeignKey("Customer", on_delete=models.SET_NULL, null=True, blank=True, related_name="payments_made")
     # mark if this payment is for shop's subscription to the platform
     is_subscription_payment = models.BooleanField(default=False, help_text="True if this is a shop -> platform subscription payment")

     amount = models.DecimalField(max_digits=12, decimal_places=2)
     method = models.CharField(max_length=30, choices=METHOD_CHOICES)
     transaction_id = models.CharField(max_length=255, null=True, blank=True)
     status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
     paid_at = models.DateTimeField(null=True, blank=True)
     created_at = models.DateTimeField(auto_now_add=True)

     def __str__(self):
          return f"Payment {self.id} - {self.amount}"

     def save(self, *args, **kwargs):
          """Enforce that completed payments cannot cause total paid > invoice total.

          This uses a SELECT FOR UPDATE on the invoice inside an atomic transaction to avoid race conditions.
          Raises ValidationError when the payment would overpay the invoice.
          """
          from django.apps import apps
          # Set paid_at for completed payments
          if self.status == 'completed' and not self.paid_at:
               self.paid_at = timezone.now()

          if self.invoice and self.status == 'completed':
               # Ensure atomicity with locking
               with transaction.atomic():
                    inv = Invoice.objects.select_for_update().get(id=self.invoice_id)
                    # include payments applied to this invoice as well as payments applied to deliveries
                    try:
                         Payment = apps.get_model('accounts', 'Payment')
                         delivery_ids = inv.get_delivery_ids() if hasattr(inv, 'get_delivery_ids') else [d for d in inv.items.values_list('delivery', flat=True) if d]
                         paid_total = Payment.objects.filter(status='completed').exclude(id=self.id).filter(
                              Q(invoice=inv) | Q(delivery_id__in=delivery_ids)
                         ).aggregate(total=models.Sum('amount'))['total'] or Decimal('0')
                    except Exception:
                         paid_total = inv.payments.filter(status='completed').exclude(id=self.id).aggregate(total=models.Sum('amount'))['total'] or Decimal('0')
                    remaining = (inv.total_amount or Decimal('0')) - paid_total
                    if self.amount > remaining:
                         raise ValidationError(_('Payment amount exceeds invoice remaining amount (remaining: %(remaining)s)') % {'remaining': remaining})
                    # all good, proceed to save
                    super().save(*args, **kwargs)

                    # Payment.save() ke andar, completed payment ke baad --- Accounts Receivable Ledger Code here
                    if self.status == 'completed' and self.payer_customer:
                         ReceivableLedgerModel = apps.get_model('accounts', 'ReceivableLedger')
                         ledger, _ = ReceivableLedgerModel.objects.get_or_create(
                              payment=self,
                              defaults={
                                   'admin': self.admin,
                                   'shop': self.shop,
                                   'customer': self.payer_customer,
                                   'date': self.paid_at.date() if self.paid_at else timezone.now().date(),
                                   'transaction_type': 'payment',
                                   'debit': Decimal('0'),
                                   'credit': self.amount,
                                   'description': f"Payment received - {self.get_method_display()}",
                              }
                         )
                         if ledger.credit != self.amount:
                              ledger.credit = self.amount
                              ledger.save()

                         # Clear dashboard cache after ledger update
                         from django.core.cache import cache
                         cache_key = f"dashboard_{self.admin_id}"
                         cache.delete(cache_key)
          elif self.delivery and self.status == 'completed' and self.payer_customer:
               # Handle delivery payments - create ledger entry
               super().save(*args, **kwargs)
               ReceivableLedgerModel = apps.get_model('accounts', 'ReceivableLedger')
               ledger, _ = ReceivableLedgerModel.objects.get_or_create(
                    payment=self,
                    defaults={
                         'admin': self.admin,
                         'shop': self.shop,
                         'customer': self.payer_customer,
                         'date': self.paid_at.date() if self.paid_at else timezone.now().date(),
                         'transaction_type': 'payment',
                         'debit': Decimal('0'),
                         'credit': self.amount,
                         'description': f"Payment received - {self.get_method_display()}",
                    }
               )
               if ledger.credit != self.amount:
                    ledger.credit = self.amount
                    ledger.save()

               # Clear dashboard cache after ledger update
               from django.core.cache import cache
               cache_key = f"dashboard_{self.admin_id}"
               cache.delete(cache_key)
          else:
               super().save(*args, **kwargs)

          # After saving, if this payment was recorded against a delivery and is completed,
          # recompute the delivery's payment_status as paid/partial/unpaid based on completed payments.
          try:
               if getattr(self, 'delivery', None) and self.status == 'completed':
                    delivery = self.delivery
                    if delivery:
                         try:
                              # Sum all completed payments for this delivery
                              paid_total = Payment.objects.filter(status='completed', delivery=delivery).aggregate(total=models.Sum('amount'))['total'] or Decimal('0')
                         except Exception:
                              paid_total = Decimal('0')

                         # Compute delivery expected amount (quantity * rate)
                         try:
                              delivery_amount = (Decimal(delivery.quantity_delivered or 0) * (Decimal(delivery.rate_given or 0)))
                         except Exception:
                              delivery_amount = Decimal('0')

                         new_status = 'unpaid'
                         if paid_total >= delivery_amount and delivery_amount > Decimal('0'):
                              new_status = 'paid'
                         elif paid_total > Decimal('0'):
                              new_status = 'partial'

                         if delivery.payment_status != new_status:
                              delivery.payment_status = new_status
                              try:
                                   delivery.save()
                              except Exception:
                                   pass

                         # If this delivery is included on any invoice items, update those invoices' status
                         try:
                              from django.apps import apps
                              InvoiceModel = apps.get_model('accounts', 'Invoice')
                              invoices = InvoiceModel.objects.filter(items__delivery=delivery).distinct()
                              for inv in invoices:
                                   try:
                                        inv.save()
                                   except Exception:
                                        pass
                         except Exception:
                              pass
          except Exception:
               pass


class Refund(models.Model):
     payment = models.ForeignKey(Payment, on_delete=models.CASCADE, related_name="refunds")
     admin = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="refunds", verbose_name="Shop Owner")
     amount = models.DecimalField(max_digits=12, decimal_places=2)
     reason = models.TextField(null=True, blank=True)
     refunded_at = models.DateTimeField(default=timezone.now)
     approved = models.BooleanField(default=False)

     def __str__(self):
          return f"Refund {self.id} - {self.amount}"


class Subscription(models.Model):
     FREQUENCY_CHOICES = (
          ("daily", "Daily"),
          ("weekly", "Weekly"),
          ("monthly", "Monthly"),
     )
     admin = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="subscriptions", verbose_name="Shop Owner")
     shop = models.ForeignKey("Shop", on_delete=models.CASCADE, related_name="subscriptions")
     customer = models.ForeignKey("Customer", on_delete=models.CASCADE, related_name="subscriptions")
     quantity = models.DecimalField(max_digits=6, decimal_places=2, default=1)
     frequency = models.CharField(max_length=20, choices=FREQUENCY_CHOICES, default="monthly")
     next_billing_date = models.DateField(null=True, blank=True)
     is_active = models.BooleanField(default=True)
     created_at = models.DateTimeField(auto_now_add=True)

     def __str__(self):
          return f"Subscription {self.customer.phone_number} - {self.frequency}"


# New model: shop owner pays platform (subscription)
class ShopSubscriptionPayment(models.Model):
    admin = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="subscription_payments", verbose_name="Shop Owner")
    shop = models.ForeignKey("Shop", on_delete=models.CASCADE, related_name="subscription_payments")
    subscription = models.ForeignKey("Subscription", on_delete=models.SET_NULL, null=True, blank=True, related_name="payments")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    method = models.CharField(max_length=30, null=True, blank=True)
    transaction_id = models.CharField(max_length=255, null=True, blank=True)
    status = models.CharField(max_length=20, choices=(("pending","Pending"),("completed","Completed"),("failed","Failed")), default="pending")
    paid_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"ShopSubscriptionPayment {self.id} - {self.shop.name} - {self.amount}"

class User(AbstractUser):
     USER_ROLES = (
          ("super_admin", "Super Admin"),
          ("shop_admin", "Shop Admin"),
              ("staff", "Staff"),
              ("customer", "Customer"),
     )
     role = models.CharField(max_length=20, choices=USER_ROLES, default="staff")
     shop = models.ForeignKey("accounts.Shop", on_delete=models.SET_NULL, null=True, blank=True, related_name="users")
     SHOP_TYPES = (
          ("water", "Water"),
     )
     shop_type = models.CharField(max_length=10, choices=SHOP_TYPES, default="water", verbose_name="Shop Type")
     whatsapp_number = models.CharField(max_length=20, null=True, blank=True, verbose_name="Whatsapp/Contact Number")

     refund_account_title = models.CharField(max_length=255, null=True, blank=True, verbose_name="Refund Account Title")
     refund_account_number = models.CharField(max_length=100, null=True, blank=True, verbose_name="Refund Account Number")

     # SMTP/email settings (per-user optional)
     smtp_host = models.CharField(max_length=255, null=True, blank=True, verbose_name="SMTP Host")
     smtp_port = models.PositiveIntegerField(null=True, blank=True, verbose_name="SMTP Port")
     smtp_username = models.CharField(max_length=255, null=True, blank=True, verbose_name="SMTP Username")
     smtp_password = models.CharField(max_length=255, null=True, blank=True, verbose_name="SMTP Password")
     smtp_use_tls = models.BooleanField(default=False, verbose_name="SMTP Use TLS")
     smtp_use_ssl = models.BooleanField(default=False, verbose_name="SMTP Use SSL")
     smtp_from_email = models.CharField(max_length=255, null=True, blank=True, verbose_name="From Email")

     monthly_charges = models.DecimalField(max_digits=10, decimal_places=2, default=0.00, verbose_name="Monthly Charges")

     address = models.TextField(null=True, blank=True, verbose_name="Shop Address")

     # Demo flag: when True the shop admin is on a demo/subscription preview
     # Default to True so new installs start in demo mode unless changed
     is_demo = models.BooleanField(default=True, verbose_name="Demo Account / On Subscription", help_text="Check if this user/shop is running on a demo/subscription plan")

     def is_super_admin(self):
          return self.role == "super_admin"

     def is_shop_admin(self):
          return self.role == "shop_admin"

     def is_staff_user(self):
          return self.role == "staff"

from django.db import models
from django.contrib.auth import get_user_model
from django.utils.text import slugify

User = get_user_model()

CURRENCY_CHOICES = [
    ('PKR', 'PKR - Pakistani Rupee'),
    ('INR', 'INR - Indian Rupee'),
    ('BDT', 'BDT - Bangladeshi Taka'),
    ('AED', 'AED - UAE Dirham'),
    ('SAR', 'SAR - Saudi Riyal'),
    ('QAR', 'QAR - Qatari Riyal'),
    ('KWD', 'KWD - Kuwaiti Dinar'),
    ('BHD', 'BHD - Bahraini Dinar'),
    ('OMR', 'OMR - Omani Rial'),
    ('USD', 'USD - US Dollar'),
]

COUNTRY_CHOICES = [
    ('PK', 'Pakistan'), ('IN', 'India'), ('BD', 'Bangladesh'),
    ('AE', 'UAE'), ('SA', 'Saudi Arabia'), ('QA', 'Qatar'),
    ('KW', 'Kuwait'), ('BH', 'Bahrain'), ('OM', 'Oman'),
]


class Shop(models.Model):

    # ── Core identity ──────────────────────────────────────────────────────────
    name        = models.CharField(max_length=255, verbose_name="Shop Name")
    slug        = models.SlugField(max_length=255, blank=True,
                                   help_text="Auto-generated. Used as WSMS subdomain: slug.wsms.app")
    admin       = models.OneToOneField(
        User, on_delete=models.CASCADE,
        related_name="shop_admin", verbose_name="Shop Owner"
    )
    customer_limit = models.IntegerField(
        default=200, verbose_name="Customer Limit",
        help_text="Maximum number of customers this shop can have"
    )

    # ── Business info ──────────────────────────────────────────────────────────
    currency    = models.CharField(max_length=3, choices=CURRENCY_CHOICES,
                                   default='PKR', blank=True, null=True)
    country     = models.CharField(max_length=2, choices=COUNTRY_CHOICES,
                                   default='PK', blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True,
                                    verbose_name="Contact Number")
    email       = models.EmailField(blank=True, null=True)
    logo        = models.ImageField(upload_to='shop_logos/', blank=True, null=True)
    description = models.TextField(blank=True, null=True,
                                   help_text="Short tagline / overview shown on public page")
    registration_number = models.CharField(
        max_length=100, blank=True, null=True,
        verbose_name="NTN / STRN / Trade License"
    )

    # ── Location & delivery ────────────────────────────────────────────────────
    address     = models.TextField(blank=True, null=True,
                                   verbose_name="Shop / Warehouse Address")
    city        = models.CharField(max_length=100, blank=True, null=True, default="Karachi")
    latitude    = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    longitude   = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)

    # ── Operating hours ────────────────────────────────────────────────────────
    opening_time = models.TimeField(blank=True, null=True)
    closing_time = models.TimeField(blank=True, null=True)
    working_days = models.JSONField(
        default=list, blank=True, null=True,
        help_text="e.g. ['Mon','Tue','Wed','Thu','Fri','Sat']"
    )

    # ── Status ────────────────────────────────────────────────────────────────
    is_active   = models.BooleanField(default=True,
                                      help_text="Uncheck to pause all orders")

    # ══════════════════════════════════════════════════════════════════════════
    # WEBSITE & ONLINE PRESENCE  (all added for the Website tab)
    # ══════════════════════════════════════════════════════════════════════════

    # ── Website visibility & URL ───────────────────────────────────────────────
    website_enabled     = models.BooleanField(
        default=False,
        help_text="Show a public customer-facing page at the WSMS subdomain"
    )
    website_url         = models.URLField(
        max_length=255, blank=True, null=True,
        help_text="Custom domain (e.g. https://www.myshop.com). Leave blank to use slug.wsms.app"
    )
    website_brand_color = models.CharField(
        max_length=7, blank=True, null=True, default='#2563eb',
        help_text="Hex colour code for the public page accent (e.g. #2563eb)"
    )

    # ── SEO fields ────────────────────────────────────────────────────────────
    seo_title       = models.CharField(
        max_length=70, blank=True, null=True,
        verbose_name="SEO Page Title",
        help_text="Shown in Google results — 50–60 chars ideal"
    )
    seo_description = models.CharField(
        max_length=200, blank=True, null=True,
        verbose_name="Meta Description",
        help_text="140–160 chars ideal"
    )
    seo_keywords    = models.CharField(
        max_length=500, blank=True, null=True,
        verbose_name="SEO Keywords",
        help_text="Comma-separated keywords"
    )

    # ── Social media links ────────────────────────────────────────────────────
    social_facebook  = models.URLField(max_length=255, blank=True, null=True)
    social_instagram = models.URLField(max_length=255, blank=True, null=True)
    social_twitter   = models.URLField(max_length=255, blank=True, null=True)
    social_youtube   = models.URLField(max_length=255, blank=True, null=True)
    social_linkedin  = models.URLField(max_length=255, blank=True, null=True)
    social_tiktok    = models.URLField(max_length=255, blank=True, null=True)

    # ── Analytics & tracking ──────────────────────────────────────────────────
    ga_tracking_id   = models.CharField(
        max_length=30, blank=True, null=True,
        verbose_name="Google Analytics 4 ID",
        help_text="Measurement ID — format: G-XXXXXXXXXX"
    )
    meta_pixel_id    = models.CharField(
        max_length=20, blank=True, null=True,
        verbose_name="Meta / Facebook Pixel ID"
    )
    custom_head_script = models.TextField(
        blank=True, null=True,
        verbose_name="Custom <head> Script",
        help_text="Injected into <head> — use for Crisp, Hotjar, Tidio, etc."
    )

    # ── Timestamps ────────────────────────────────────────────────────────────
    created_at  = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at  = models.DateTimeField(auto_now=True, blank=True, null=True)

    class Meta:
        verbose_name        = "Shop"
        verbose_name_plural = "Shops"
        ordering            = ['-created_at']

    def __str__(self):
        return self.name

    # ── Helpers ───────────────────────────────────────────────────────────────

    @property
    def public_url(self):
        """
        Returns the canonical public URL for this shop's website page.
        Prefers custom domain if set; falls back to WSMS subdomain.
        """
        if self.website_url:
            return self.website_url
        return f"https://{self.slug}.wsms.app"

    @property
    def has_social_links(self):
        return any([
            self.social_facebook, self.social_instagram, self.social_twitter,
            self.social_youtube, self.social_linkedin, self.social_tiktok,
        ])

    @property
    def formatted_hours(self):
        if self.opening_time and self.closing_time:
            return f"{self.opening_time.strftime('%I:%M %p')} – {self.closing_time.strftime('%I:%M %p')}"
        return None

    @property
    def working_days_display(self):
        """Returns working days as a readable string e.g. 'Mon – Sat'"""
        days = self.working_days or []
        if not days:
            return "Mon – Sat"
        if len(days) == 1:
            return days[0]
        return f"{days[0]} – {days[-1]}"

    def save(self, *args, **kwargs):
        # Auto-generate slug from shop name (only on first save or if blank)
        if not self.slug:
            base = slugify(self.name)
            slug = base
            n = 1
            while Shop.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base}-{n}"
                n += 1
            self.slug = slug

        # Default working days
        if not self.working_days:
            self.working_days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

        # Default brand colour
        if not self.website_brand_color:
            self.website_brand_color = '#2563eb'

        super().save(*args, **kwargs)

class Staff(models.Model):
     # Link staff to shop admin (each shop has its own staff)
     admin = models.ForeignKey(User, on_delete=models.CASCADE, related_name="Admin", verbose_name="Shop Owner")

     user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="Staff")

     # Basic info
     first_name = models.CharField(max_length=100)
     last_name = models.CharField(max_length=100)
     phone_number = models.CharField(max_length=20, unique=True)
     cnic = models.CharField(max_length=15, unique=True, null=True, blank=True)  # Pakistani CNIC or ID
     address = models.TextField(blank=True, null=True)

     # Job details
     salary = models.DecimalField(max_digits=10, decimal_places=2)
     joining_date = models.DateField(auto_now_add=True)
     is_blocked = models.BooleanField(default=False)

     # Extra useful fields for a milk delivery boy
     shift_start = models.TimeField(null=True, blank=True)
     shift_end = models.TimeField(null=True, blank=True)
     assigned_area = models.CharField(max_length=255, null=True, blank=True)  # e.g., "Gulshan Block 5"
     # Customers assigned to this staff member for deliveries
     customers = models.ManyToManyField("Customer", blank=True, related_name="assigned_staff")
     # Tracking
     created_at = models.DateTimeField(auto_now_add=True)
     updated_at = models.DateTimeField(auto_now=True)

     def __str__(self):
          return f"{self.first_name} {self.last_name} ({self.admin.username})"


"""
================================================================================
WSMS Cloud System — Complete Customer Model
================================================================================
RO Water Supplier Management System

Fully integrated with your existing models:
    ✔ User (AbstractUser with roles)        ✔ Shop (OneToOne with admin)
    ✔ CanType / CustomerCanType             ✔ DailyDelivery
    ✔ ReceivableLedger (running balance)    ✔ Invoice / InvoiceItem
    ✔ Payment / Refund                      ✔ CanTransaction
    ✔ Staff (M2M customers)                 ✔ ExpenseLedger

Migration note:
    After replacing your Customer model, run:
        python manage.py makemigrations
        python manage.py migrate
================================================================================
"""

import uuid
from decimal import Decimal

from django.conf import settings
from django.core.validators import (
    MinValueValidator,
    MaxValueValidator,
    RegexValidator,
)
from django.db import models
from django.db.models import Q, Sum
from django.utils import timezone
from django.utils.translation import gettext_lazy as _


# ──────────────────────────────────────────────────────────────────────────────
# VALIDATORS
# ──────────────────────────────────────────────────────────────────────────────

phone_validator = RegexValidator(
    # Accepts optional leading + and country code, then 9-13 digits
    regex=r'^\+?1?\d{9,15}$',
    message=_("Phone number must be entered in the format: '+923001234567'. Up to 15 digits allowed.")
)

cnic_validator = RegexValidator(
    # Pakistani CNIC format: 12345-1234567-1
    regex=r'^\d{5}-\d{7}-\d{1}$',
    message=_("CNIC must be in the format: 12345-1234567-1")
)


# ──────────────────────────────────────────────────────────────────────────────
# CHOICE CLASSES
# All choices are grouped here so they are easy to find, extend, and reuse
# in serializers, forms, and admin filters.
# ──────────────────────────────────────────────────────────────────────────────

class CustomerType(models.TextChoices):
    """
    What kind of premises does this customer represent?
    Used for pricing tiers, delivery priority, and reporting segments.
    """
    RESIDENTIAL = 'residential', _('Residential (Home)')        # Regular home customer
    COMMERCIAL  = 'commercial',  _('Commercial (Office/Shop)')  # Office or retail business
    RESTAURANT  = 'restaurant',  _('Restaurant / Cafe')         # Food business — high volume
    HOSPITAL    = 'hospital',    _('Hospital / Clinic')         # Medical facility
    SCHOOL      = 'school',      _('School / Academy')          # Educational institution
    WHOLESALE   = 'wholesale',   _('Wholesale / Reseller')      # Buys in bulk to resell
    OTHER       = 'other',       _('Other')                     # Anything else


class CustomerStatus(models.TextChoices):
    """
    Full lifecycle status of a customer account.
    Replaces the single is_active boolean with a proper state machine.
    Each status affects whether deliveries/invoices can be created.
    """
    ACTIVE      = 'active',      _('Active')       # Normal delivering customer
    INACTIVE    = 'inactive',    _('Inactive')     # Voluntarily paused (e.g. on vacation)


class PaymentTerms(models.TextChoices):
    """
    Defines when payment is due after delivery.
    Drives overdue calculation, dunning reminders, and credit-limit enforcement.
    Matches your existing Payment / Invoice flow.
    """
    CASH_ON_DELIVERY = 'cod',      _('Cash on Delivery')  # Pay at time of each delivery
    WEEKLY           = 'weekly',   _('Weekly')            # Settle every 7 days
    BIWEEKLY         = 'biweekly', _('Bi-Weekly')         # Every 14 days
    MONTHLY          = 'monthly',  _('Monthly')           # End of month — matches invoice_cycle
    PREPAID          = 'prepaid',  _('Prepaid')           # Customer pays before delivery


class PreferredPaymentMethod(models.TextChoices):
    """
    Customer's preferred way to pay.
    Matches the METHOD_CHOICES in your existing Payment model — keep in sync.
    """
    CASH          = 'cash',          _('Cash')           # Matches Payment.METHOD_CHOICES
    BANK_TRANSFER = 'bank_transfer', _('Bank Transfer')  # Matches Payment.METHOD_CHOICES
    JAZZCASH      = 'jazzcash',      _('JazzCash')       # Popular Pakistani mobile wallet
    EASYPAISA     = 'easypaisa',     _('EasyPaisa')      # Popular Pakistani mobile wallet
    SADAPAY       = 'sadapay',       _('SadaPay')        # Pakistani neo-bank
    NAYAPAY       = 'nayapay',       _('NayaPay')        # Pakistani neo-bank
    CHEQUE        = 'cheque',        _('Cheque')         # For large commercial accounts
    OTHER         = 'other',         _('Other')          # Matches Payment.METHOD_CHOICES


class DeliveryDay(models.TextChoices):
    """Days of the week for recurring delivery scheduling."""
    MONDAY    = 'monday',    _('Monday')
    TUESDAY   = 'tuesday',   _('Tuesday')
    WEDNESDAY = 'wednesday', _('Wednesday')
    THURSDAY  = 'thursday',  _('Thursday')
    FRIDAY    = 'friday',    _('Friday')
    SATURDAY  = 'saturday',  _('Saturday')
    SUNDAY    = 'sunday',    _('Sunday')


class DeliveryShift(models.TextChoices):
    """Time-of-day window preferred by the customer for delivery."""
    MORNING   = 'morning',   _('Morning (8 AM – 12 PM)')
    AFTERNOON = 'afternoon', _('Afternoon (12 PM – 5 PM)')
    EVENING   = 'evening',   _('Evening (5 PM – 9 PM)')
    ANYTIME   = 'anytime',   _('Anytime')


# ──────────────────────────────────────────────────────────────────────────────
# CUSTOM MANAGERS
# ──────────────────────────────────────────────────────────────────────────────

class CustomerQuerySet(models.QuerySet):
    """
    Chainable queryset helpers so views stay clean.
    Usage examples:
        Customer.objects.active()
        Customer.objects.active().overdue()
        Customer.objects.for_shop(shop).by_area('DHA')
    """

    def active(self):
        """Only non-deleted, active-status customers."""
        return self.filter(is_deleted=False, status=CustomerStatus.ACTIVE)

    def inactive(self):
        """Customers who are voluntarily paused."""
        return self.filter(is_deleted=False, status=CustomerStatus.INACTIVE)

    def suspended(self):
        """Customers blocked due to overdue payments."""
        return self.filter(is_deleted=False, status=CustomerStatus.SUSPENDED)

    def for_shop(self, shop):
        """All non-deleted customers belonging to a specific shop."""
        return self.filter(is_deleted=False, shop=shop)

    def by_area(self, area):
        """Filter by neighbourhood/area — case-insensitive partial match."""
        return self.filter(area__icontains=area)

    def by_type(self, customer_type):
        """Filter by customer type (residential, commercial, etc.)."""
        return self.filter(customer_type=customer_type)

    def with_balance(self):
        """Customers who have any outstanding balance > 0."""
        return self.filter(outstanding_balance__gt=Decimal('0.00'))

    def overdue_credit(self):
        """Customers whose balance exceeds their credit limit (block deliveries)."""
        return self.filter(
            outstanding_balance__gte=models.F('credit_limit'),
            credit_limit__gt=Decimal('0.00'),
        )

    def assigned_to_staff(self, staff):
        """Customers assigned to a specific Staff member (via Staff.customers M2M)."""
        return self.filter(assigned_staff=staff)

    def dormant(self, days=30):
        """Customers who haven't received a delivery in the given number of days."""
        cutoff = timezone.now().date() - timezone.timedelta(days=days)
        return self.filter(
            Q(last_delivery_date__lt=cutoff) | Q(last_delivery_date__isnull=True)
        )


class CustomerManager(models.Manager):
    """
    Default manager — always excludes soft-deleted records.
    Exposes the full CustomerQuerySet API via .get_queryset().
    """

    def get_queryset(self):
        return CustomerQuerySet(self.model, using=self._db).filter(is_deleted=False)

    # ── Convenience passthroughs so you can write Customer.objects.active() ──
    def active(self):           return self.get_queryset().active()
    def inactive(self):         return self.get_queryset().inactive()
    def suspended(self):        return self.get_queryset().suspended()
    def for_shop(self, shop):   return self.get_queryset().for_shop(shop)
    def by_area(self, area):    return self.get_queryset().by_area(area)
    def with_balance(self):     return self.get_queryset().with_balance()
    def dormant(self, days=30): return self.get_queryset().dormant(days)


class AllCustomerManager(models.Manager):
    """
    Bypass manager — includes soft-deleted records.
    Use ONLY in admin panels and audit/recovery screens.
    Usage: Customer.all_objects.filter(is_deleted=True)
    """

    def get_queryset(self):
        return CustomerQuerySet(self.model, using=self._db)


# ──────────────────────────────────────────────────────────────────────────────
# MAIN CUSTOMER MODEL
# ──────────────────────────────────────────────────────────────────────────────

class Customer(models.Model):
    """
    Central customer record for the WSMS RO Water Supplier system.

    Designed to integrate seamlessly with:
        Shop, User, Staff, CanType, CustomerCanType,
        DailyDelivery, CanTransaction,
        Invoice, InvoiceItem, Payment, ReceivableLedger

    Sections:
        1.  System / Identity
        2.  Shop & User Linkage
        3.  Personal / Business Identity
        4.  Contact Information
        5.  Primary Delivery Address
        6.  Delivery Preferences      ← drives DailyDelivery defaults
        7.  Can & Pricing Config      ← integrates with CanType / CustomerCanType
        8.  Billing & Invoice Config  ← drives Invoice generation
        9.  Financial Tracking        ← mirrors ReceivableLedger running balance
        10. Can Deposit Tracking      ← mirrors CanTransaction balance
        11. Status & Lifecycle
        12. Staff Assignment          ← read-only reverse of Staff.customers M2M
        13. CRM & Internal Notes
        14. Soft Delete
        15. Audit Trail
    """

    # ══════════════════════════════════════════════════════════════════════════
    # 1. SYSTEM / IDENTITY
    # ══════════════════════════════════════════════════════════════════════════

    uuid = models.UUIDField(
        default=uuid.uuid4,
        editable=False,
        blank=True,
        null=True,
        db_index=True,
        help_text=_(
            "Globally unique identifier — safe to expose in URLs, QR codes, and "
            "API responses instead of the numeric primary key."
        ),
    )

    customer_code = models.CharField(
        max_length=30,
        unique=True,
        blank=True,
        null=True,
        db_index=True,
        help_text=_(
            "Human-readable unique code auto-generated on first save. "
            "Format: <CITY_INITIALS>-<ID> e.g. 'KHI-00142'. "
            "Printed on every Invoice for easy lookup."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 2. SHOP & USER LINKAGE
    # ══════════════════════════════════════════════════════════════════════════

    shop = models.ForeignKey(
        "Shop",
        on_delete=models.CASCADE,
        related_name="customers",
        help_text=_(
            "The water supplier shop this customer belongs to. "
            "Every customer is owned by exactly one Shop. "
            "shop.admin gives you the shop owner (User)."
        ),
    )

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        default=None,
        related_name="customer_accounts",
        help_text=_(
            "Optional Django User account linked to this customer. "
            "Role should be 'customer' (see User.USER_ROLES). "
            "Allows the customer to log in to a self-service portal. "
            "Populated by the management command that migrates legacy data."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 3. PERSONAL / BUSINESS IDENTITY
    # ══════════════════════════════════════════════════════════════════════════

    customer_type = models.CharField(
        max_length=20,
        choices=CustomerType.choices,
        default=CustomerType.RESIDENTIAL,
        db_index=True,
        help_text=_(
            "Type of customer premises. Used to apply different pricing tiers, "
            "delivery priority, and segment reports. "
            "Commercial/Wholesale customers typically get bulk discounts."
        ),
    )

    first_name = models.CharField(
        max_length=100,
        help_text=_("Customer's first name or the primary contact person's first name."),
    )

    last_name = models.CharField(
        max_length=100,
        blank=True,
        default='',
        help_text=_("Customer's last name. Recommended for formal invoice headers."),
    )

    company_name = models.CharField(
        max_length=200,
        blank=True,
        default='',
        help_text=_(
            "Business / company name for commercial or wholesale customers. "
            "When set, this is printed on Invoice headers above the contact name."
        ),
    )

    cnic = models.CharField(
        max_length=15,
        blank=True,
        default='',
        validators=[cnic_validator],
        help_text=_(
            "Pakistani National Identity Card number in format 12345-1234567-1. "
            "Matches the cnic field on your Staff model. "
            "Required for high-value credit accounts or legal documentation."
        ),
    )

    ntn = models.CharField(
        max_length=20,
        blank=True,
        default='',
        help_text=_(
            "National Tax Number — required on tax invoices for registered businesses. "
            "Leave blank for residential customers (most are tax-exempt)."
        ),
    )

    profile_photo = models.ImageField(
        upload_to='customers/photos/%Y/%m/',
        blank=True,
        null=True,
        help_text=_(
            "Optional photo of the customer or their premises. "
            "Helps delivery riders (Staff) identify the correct location or household."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 4. CONTACT INFORMATION
    # ══════════════════════════════════════════════════════════════════════════

    phone_number = models.CharField(
        max_length=20,
        validators=[phone_validator],
        help_text=_(
            "Primary contact number. Format: +923001234567. "
            "This is the number delivery riders (Staff) will call. "
            "Must match the format used on Staff.phone_number."
        ),
    )

    phone_number_2 = models.CharField(
        max_length=20,
        blank=True,
        default='',
        validators=[phone_validator],
        help_text=_(
            "Secondary / alternate contact number "
            "(e.g. spouse's number, office receptionist, building guard)."
        ),
    )

    whatsapp_number = models.CharField(
        max_length=20,
        blank=True,
        default='',
        validators=[phone_validator],
        help_text=_(
            "WhatsApp number for sending Invoices, delivery notifications, and "
            "payment reminders. May be different from phone_number. "
            "Used by whatsapp_link property to build wa.me deep-links."
        ),
    )

    email = models.EmailField(
        max_length=254,
        blank=True,
        default='',
        help_text=_(
            "Email address for digital invoice delivery. "
            "Synced from User.email when a linked User account exists."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 5. PRIMARY DELIVERY ADDRESS
    # ══════════════════════════════════════════════════════════════════════════

    address_line_1 = models.CharField(
        max_length=255,
        blank=True,
        help_text=_(
            "Street address, house number, flat number, or building name. "
            "Example: 'Flat 3B, Block 7, Gulshan-e-Iqbal'."
        ),
    )

    address_line_2 = models.CharField(
        max_length=255,
        blank=True,
        default='',
        help_text=_(
            "Additional address detail — floor number, nearby landmark, or "
            "society gate name. Example: 'Near Agha Khan Hospital'."
        ),
    )

    area = models.CharField(
        max_length=100,
        blank=True,
        default='',
        db_index=True,
        help_text=_(
            "Neighbourhood or area name. Example: 'DHA Phase 6', 'North Nazimabad Block D'. "
            "Used to group customers by delivery zone and filter in list views. "
            "Should match Staff.assigned_area for automatic staff-customer pairing suggestions."
        ),
    )

    city = models.CharField(
        max_length=100,
        default='Karachi',
        help_text=_(
            "City. Defaults to Karachi since most Pakistani RO suppliers operate locally. "
            "Used as prefix in auto-generated customer_code (e.g. KHI = Karachi)."
        ),
    )

    latitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        help_text=_(
            "GPS latitude of the delivery address. "
            "Enables map-based route planning and distance sorting for delivery riders."
        ),
    )

    longitude = models.DecimalField(
        max_digits=9,
        decimal_places=6,
        null=True,
        blank=True,
        help_text=_("GPS longitude of the delivery address."),
    )

    address_notes = models.TextField(
        blank=True,
        default='',
        help_text=_(
            "Freeform directions to help the rider find the address. "
            "Example: 'Green gate, ring the bell twice, guard will open'. "
            "Shown to the assigned Staff member on their delivery app."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 6. DELIVERY PREFERENCES
    # These fields drive defaults when creating a DailyDelivery for this customer.
    # ══════════════════════════════════════════════════════════════════════════

    default_can_type = models.ForeignKey(
        "CanType",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="default_customers",
        help_text=_(
            "The CanType this customer usually orders. "
            "Pre-filled as the default when creating a new DailyDelivery. "
            "Must be a CanType that belongs to this shop (CanType.admin = shop.admin). "
            "Per-customer pricing is stored in CustomerCanType."
        ),
    )

    default_quantity = models.PositiveSmallIntegerField(
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(500)],
        help_text=_(
            "Default number of cans per delivery. "
            "Pre-filled as DailyDelivery.quantity_delivered when creating a new delivery. "
            "The dispatcher can override this per individual order."
        ),
    )

    delivery_shift = models.CharField(
        max_length=15,
        choices=DeliveryShift.choices,
        default=DeliveryShift.ANYTIME,
        help_text=_(
            "Preferred time window for delivery. "
            "Helps the dispatcher assign the customer to the correct Staff shift. "
            "Matches Staff.shift_start / shift_end."
        ),
    )

    delivery_instructions = models.TextField(
        blank=True,
        default='',
        help_text=_(
            "Permanent delivery instructions applied to every order for this customer. "
            "Example: 'Place cans inside the gate, do not knock — baby sleeping'. "
            "Shown to the assigned Staff member on every delivery."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 7. CAN & PRICING CONFIGURATION
    # Works alongside CanType, CustomerCanType, and DailyDelivery.rate_given
    # ══════════════════════════════════════════════════════════════════════════

    price_per_can = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(Decimal('0.00'))],
        help_text=_(
            "Custom flat price per can for this specific customer. "
            "When set, this overrides CanType.price and CustomerCanType.price "
            "and is used as the default DailyDelivery.rate_given. "
            "Leave blank to use the CanType's standard price."
        ),
    )

    discount_percent = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00')), MaxValueValidator(Decimal('100.00'))],
        help_text=_(
            "Percentage discount applied automatically to every Invoice line for this customer. "
            "Example: 10.00 = 10% off. Set to 0.00 for no discount. "
            "Applied during Invoice.get_effective_total() calculation."
        ),
    )

    discount_flat = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        help_text=_(
            "Fixed flat discount amount (PKR) applied to the invoice total. "
            "Can be used alongside discount_percent or instead of it."
        ),
    )

    is_tax_exempt = models.BooleanField(
        default=True,
        help_text=_(
            "When True, no sales tax (GST) is added to this customer's Invoices. "
            "Most residential customers are tax-exempt. "
            "Commercial customers with NTN may need tax invoices — set to False."
        ),
    )

    tax_rate = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00')), MaxValueValidator(Decimal('100.00'))],
        help_text=_(
            "Tax rate (%) added to Invoices when is_tax_exempt is False. "
            "Example: 17.00 for 17% GST. Ignored when is_tax_exempt is True."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 8. BILLING & INVOICE CONFIGURATION
    # ══════════════════════════════════════════════════════════════════════════

    payment_terms = models.CharField(
        max_length=20,
        choices=PaymentTerms.choices,
        default=PaymentTerms.MONTHLY,
        help_text=_(
            "When this customer is expected to pay their invoice. "
            "Drives the is_overdue property and overdue suspension logic. "
            "Monthly matches your Invoice.invoice_month/invoice_year cycle."
        ),
    )

    preferred_payment_method = models.CharField(
        max_length=20,
        choices=PreferredPaymentMethod.choices,
        default=PreferredPaymentMethod.CASH,
        help_text=_(
            "Customer's preferred payment method. "
            "Pre-filled as default when creating a Payment record. "
            "Choices are aligned with your existing Payment.METHOD_CHOICES."
        ),
    )

    invoice_cycle_day = models.PositiveSmallIntegerField(
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(28)],
        help_text=_(
            "Day of the month on which the monthly Invoice is generated for this customer. "
            "Example: 1 = invoice generated on the 1st of every month. "
            "Capped at 28 to avoid issues with February."
        ),
    )

    invoice_notes = models.TextField(
        blank=True,
        default='',
        help_text=_(
            "Custom text printed at the bottom of every Invoice generated for this customer. "
            "Example: 'Payment due by 5th of the month. JazzCash: 0300-1234567'. "
            "Populated into Invoice.notes as the default when creating a new invoice."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 9. FINANCIAL TRACKING
    # These fields are CACHED summaries — ReceivableLedger is the source of truth.
    # ══════════════════════════════════════════════════════════════════════════

    outstanding_balance = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal('0.00'),
        help_text=_(
            "Cached outstanding receivable balance (PKR). "
            "Positive = customer owes money. Negative = customer has advance/overpaid. "
            "Source of truth is ReceivableLedger.balance_after — this is a fast-read cache. "
            "Auto-synced by ReceivableLedger.save() (already in your existing code)."
        ),
    )

    advance_balance = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        help_text=_(
            "Prepaid / advance amount (PKR) deposited by the customer that has not yet "
            "been applied to any Invoice. Reduces the next Invoice's payable amount."
        ),
    )

    total_invoiced_lifetime = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        help_text=_(
            "Cumulative sum of all Invoice totals ever generated for this customer (PKR). "
            "Useful for lifetime value reports and loyalty tier calculations."
        ),
    )

    total_paid_lifetime = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        help_text=_(
            "Cumulative sum of all completed Payment amounts ever received from this customer (PKR). "
            "Calculated as sum of Payment.amount where status='completed' and payer_customer=self."
        ),
    )

    last_payment_date = models.DateField(
        null=True,
        blank=True,
        help_text=_(
            "Date of the most recent completed Payment from this customer. "
            "Updated automatically when a Payment with payer_customer=this is saved. "
            "Used by is_overdue to calculate how long the balance has been unpaid."
        ),
    )

    last_payment_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        null=True,
        blank=True,
        help_text=_(
            "Amount (PKR) of the most recent completed Payment. "
            "Useful for displaying payment history in the customer dashboard."
        ),
    )

    last_invoice_date = models.DateField(
        null=True,
        blank=True,
        help_text=_(
            "Date of the most recently generated Invoice for this customer. "
            "Updated when a new Invoice is saved with customer=this."
        ),
    )

    last_delivery_date = models.DateField(
        null=True,
        blank=True,
        help_text=_(
            "Date of the most recent DailyDelivery for this customer. "
            "Updated automatically when a DailyDelivery is saved. "
            "Used to identify dormant customers (no delivery in 30+ days)."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 10. CAN DEPOSIT TRACKING
    # ══════════════════════════════════════════════════════════════════════════

    cans_with_customer = models.PositiveSmallIntegerField(
        default=0,
        help_text=_(
            "Number of company-owned water cans currently at the customer's premises. "
            "Cached from CanTransaction.balance_after_transaction (latest entry). "
            "Auto-updated when a CanTransaction is saved for this customer. "
            "Drives total_deposit_held = cans_with_customer × deposit_per_can."
        ),
    )

    deposit_per_can = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        help_text=_(
            "Refundable security deposit (PKR) charged per can given to this customer. "
            "Multiplied by cans_with_customer to compute total_deposit_held. "
            "Set when the customer receives their first can."
        ),
    )

    total_deposit_held = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=Decimal('0.00'),
        validators=[MinValueValidator(Decimal('0.00'))],
        help_text=_(
            "Total refundable deposit (PKR) currently held from this customer. "
            "= cans_with_customer × deposit_per_can. "
            "Recalculated by sync_can_deposit() whenever cans_with_customer changes."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 11. STATUS & LIFECYCLE
    # ══════════════════════════════════════════════════════════════════════════

    status = models.CharField(
        max_length=20,
        choices=CustomerStatus.choices,
        default=CustomerStatus.ACTIVE,
        db_index=True,
        help_text=_(
            "Full lifecycle status of the customer account. "
            "Active: deliveries allowed. Suspended: block deliveries until payment. "
            "Blacklisted: permanently blocked. Prospect: lead not yet active. "
            "Prefer updating this over toggling is_active directly."
        ),
    )

    is_active = models.BooleanField(
        default=True,
        db_index=True,
        help_text=_(
            "Quick active toggle — kept for backward compatibility with existing views. "
            "Automatically set to False when status changes to inactive/suspended/blacklisted. "
            "The CustomerManager.active() queryset filters on both is_active and status."
        ),
    )

    suspension_reason = models.TextField(
        blank=True,
        default='',
        help_text=_(
            "Reason recorded when status is set to 'suspended' or 'blacklisted'. "
            "Example: 'Overdue balance of PKR 5,000 for 45 days'. "
            "Shown to shop admin on the customer detail page."
        ),
    )

    joined_date = models.DateField(
        default=timezone.now,
        help_text=_(
            "Date this customer started receiving water from this shop. "
            "Defaults to today. Used for tenure calculations, anniversary discounts, "
            "and the is_overdue fallback when no payment has been made yet."
        ),
    )

    contract_start_date = models.DateField(
        null=True,
        blank=True,
        help_text=_(
            "Start date of a formal service contract with this customer. "
            "Relevant for commercial/wholesale customers with signed agreements."
        ),
    )

    contract_end_date = models.DateField(
        null=True,
        blank=True,
        help_text=_(
            "Expiry date of the service contract. "
            "System should alert the shop admin when this date is within 30 days."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 12. STAFF ASSIGNMENT (reverse of Staff.customers ManyToManyField)
    # Staff.customers is already defined in your Staff model as:
    #   customers = models.ManyToManyField("Customer", blank=True, related_name="assigned_staff")
    # So customer.assigned_staff.all() gives all Staff members assigned to this customer.
    # ══════════════════════════════════════════════════════════════════════════

    # customer.assigned_staff.all()   → QuerySet of Staff objects
    # customer.assigned_staff.first() → Primary assigned rider
    # Staff.objects.filter(customers=customer) → Same thing

    # ══════════════════════════════════════════════════════════════════════════
    # 13. CRM & INTERNAL NOTES
    # ══════════════════════════════════════════════════════════════════════════

    internal_notes = models.TextField(
        blank=True,
        default='',
        help_text=_(
            "Private notes visible only to shop staff — NEVER shown to the customer. "
            "Example: 'Difficult to collect payment from, always call twice before visiting'. "
            "Not printed on Invoices."
        ),
    )

    tags = models.CharField(
        max_length=300,
        blank=True,
        default='',
        help_text=_(
            "Comma-separated tags for quick filtering and segmentation. "
            "Example: 'vip,rooftop-delivery,bulk-buyer,referred'. "
            "For large-scale use, replace with a ManyToManyField to a Tag model."
        ),
    )

    referral_source = models.CharField(
        max_length=100,
        blank=True,
        default='',
        help_text=_(
            "How did this customer hear about the service? "
            "Example: 'Facebook Ad', 'Pamphlet', 'Walk-in', 'Referred by Ahmed Khan'."
        ),
    )

    referred_by = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='referrals',
        help_text=_(
            "If this customer was referred by another existing customer, link them here. "
            "customer.referrals.count() gives the number of customers this person has referred. "
            "Use for referral reward programs."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 14. SOFT DELETE
    # ══════════════════════════════════════════════════════════════════════════

    is_deleted = models.BooleanField(
        default=False,
        db_index=True,
        help_text=_(
            "Soft-delete flag. True means this customer is hidden from all normal queries "
            "but the record is preserved for Invoice history, ReceivableLedger, and audit. "
            "The default CustomerManager always filters is_deleted=False. "
            "Use Customer.all_objects to include deleted records (admin/recovery only)."
        ),
    )

    deleted_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text=_(
            "Timestamp of when this customer was soft-deleted via soft_delete(). "
            "Null means the customer has never been deleted."
        ),
    )

    # ══════════════════════════════════════════════════════════════════════════
    # 15. AUDIT TRAIL
    # ══════════════════════════════════════════════════════════════════════════

    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text=_("Timestamp when this customer record was first created. Set automatically."),
    )

    updated_at = models.DateTimeField(
        auto_now=True,
        help_text=_("Timestamp of the last update to any field on this record. Set automatically."),
    )

    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='customers_created',
        help_text=_(
            "The User (shop admin or staff) who created this customer record. "
            "Set in the view/API: customer.created_by = request.user before saving."
        ),
    )

    updated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='customers_updated',
        help_text=_(
            "The User who last modified this customer record. "
            "Set in the view/API: customer.updated_by = request.user before saving."
        ),
    )

    # ──────────────────────────────────────────────────────────────────────────
    # MANAGERS
    # ──────────────────────────────────────────────────────────────────────────

    objects     = CustomerManager()     # Default — excludes soft-deleted records
    all_objects = AllCustomerManager()  # Includes soft-deleted (admin/audit only)

    # ──────────────────────────────────────────────────────────────────────────
    # META
    # ──────────────────────────────────────────────────────────────────────────

    class Meta:
        verbose_name        = _('Customer')
        verbose_name_plural = _('Customers')
        ordering            = ['first_name', 'last_name']

        indexes = [
            models.Index(fields=['shop', 'status'],            name='idx_customer_shop_status'),
            models.Index(fields=['shop', 'area'],              name='idx_customer_shop_area'),
            models.Index(fields=['phone_number'],              name='idx_customer_phone'),
            models.Index(fields=['customer_code'],             name='idx_customer_code'),
            models.Index(fields=['outstanding_balance'],       name='idx_customer_balance'),
            models.Index(fields=['last_delivery_date'],        name='idx_customer_last_delivery'),
            models.Index(fields=['customer_type'],             name='idx_customer_type'),
            models.Index(fields=['shop', 'is_deleted'],        name='idx_customer_shop_deleted'),
        ]

    # ──────────────────────────────────────────────────────────────────────────
    # PROPERTIES
    # ──────────────────────────────────────────────────────────────────────────

    @property
    def full_name(self) -> str:
        personal = f"{self.first_name} {self.last_name}".strip()
        if self.company_name:
            return f"{self.company_name} ({personal})" if personal else self.company_name
        return personal

    @property
    def display_name(self) -> str:
        return self.company_name or f"{self.first_name} {self.last_name}".strip()

    @property
    def display_first_name(self) -> str:
        try:
            if self.user_id and self.user:
                return self.user.first_name or self.first_name
        except Exception:
            pass
        return self.first_name

    @property
    def display_last_name(self) -> str:
        try:
            if self.user_id and self.user:
                return self.user.last_name or self.last_name
        except Exception:
            pass
        return self.last_name

    @property
    def display_email(self) -> str:
        try:
            if self.user_id and self.user:
                return self.user.email or self.email
        except Exception:
            pass
        return self.email

    @property
    def full_address(self) -> str:
        parts = [p for p in [
            self.address_line_1,
            self.address_line_2,
            self.area,
            self.city,
        ] if p]
        return ', '.join(parts)

    @property
    def address(self) -> str:
        """Compatibility alias for templates and legacy code using customer.address."""
        return f"{self.address_line_1}...{self.area}"

    @property
    def whatsapp_link(self) -> str | None:
        number = self.whatsapp_number or self.phone_number
        if number:
            digits = ''.join(ch for ch in number if ch.isdigit())
            return f"https://wa.me/{digits}"
        return None

    @property
    def is_overdue(self) -> bool:
        if self.outstanding_balance <= Decimal('0.00'):
            return False
        reference_date = self.last_payment_date or self.joined_date
        days_map = {
            PaymentTerms.CASH_ON_DELIVERY: 1,
            PaymentTerms.WEEKLY:           7,
            PaymentTerms.BIWEEKLY:         14,
            PaymentTerms.MONTHLY:          30,
            PaymentTerms.PREPAID:          0,
        }
        allowed_days  = days_map.get(self.payment_terms, 30)
        overdue_after = reference_date + timezone.timedelta(days=allowed_days)
        return timezone.now().date() > overdue_after

    @property
    def calculated_deposit(self) -> Decimal:
        return Decimal(self.cans_with_customer) * self.deposit_per_can

    @property
    def days_since_last_delivery(self) -> int | None:
        if not self.last_delivery_date:
            return None
        return (timezone.now().date() - self.last_delivery_date).days

    @property
    def primary_staff(self):
        return self.assigned_staff.first()

    # ──────────────────────────────────────────────────────────────────────────
    # METHODS
    # ──────────────────────────────────────────────────────────────────────────

    def get_current_receivable(self) -> Decimal:
        latest = ReceivableLedger.objects.filter(
            customer=self,
            admin=self.shop.admin
        ).order_by('-date', '-id').first()
        return latest.balance_after if latest else Decimal('0.00')

    def get_outstanding_balance(self) -> Decimal:
        return self.get_current_receivable()

    def get_can_balance(self) -> int:
        from django.apps import apps
        CanTransaction = apps.get_model('accounts', 'CanTransaction')
        latest = CanTransaction.objects.filter(
            customer=self,
            admin=self.shop.admin
        ).order_by('-date', '-id').first()
        return latest.balance_after_transaction if latest else 0

    def sync_can_deposit(self) -> None:
        live_balance = self.get_can_balance()
        self.cans_with_customer = live_balance
        self.total_deposit_held = Decimal(live_balance) * self.deposit_per_can
        Customer.objects.filter(pk=self.pk).update(
            cans_with_customer=self.cans_with_customer,
            total_deposit_held=self.total_deposit_held,
        )

    def sync_financial_summary(self) -> None:
        from django.apps import apps
        Payment = apps.get_model('accounts', 'Payment')

        self.outstanding_balance = self.get_current_receivable()

        payment_stats = Payment.objects.filter(
            payer_customer=self,
            status='completed',
        ).aggregate(total=Sum('amount'))
        self.total_paid_lifetime = payment_stats['total'] or Decimal('0.00')

        last_payment = Payment.objects.filter(
            payer_customer=self,
            status='completed',
        ).order_by('-paid_at').first()

        if last_payment:
            self.last_payment_date   = last_payment.paid_at.date() if last_payment.paid_at else None
            self.last_payment_amount = last_payment.amount
        else:
            self.last_payment_date   = None
            self.last_payment_amount = None

        Customer.objects.filter(pk=self.pk).update(
            outstanding_balance  = self.outstanding_balance,
            total_paid_lifetime  = self.total_paid_lifetime,
            last_payment_date    = self.last_payment_date,
            last_payment_amount  = self.last_payment_amount,
        )

    def soft_delete(self) -> None:
        self.is_deleted = True
        self.is_active  = False
        self.status     = CustomerStatus.INACTIVE
        self.deleted_at = timezone.now()
        self.save(update_fields=['is_deleted', 'is_active', 'status', 'deleted_at', 'updated_at'])

    def generate_customer_code(self) -> str:
        prefix = ''.join(word[0] for word in self.city.upper().split())[:3]
        return f"{prefix}-{self.id:05d}"

    def save(self, *args, **kwargs) -> None:
        is_new = self.pk is None
        self.is_active = self.status == CustomerStatus.ACTIVE
        super().save(*args, **kwargs)
        if is_new and not self.customer_code:
            self.customer_code = self.generate_customer_code()
            Customer.objects.filter(pk=self.pk).update(customer_code=self.customer_code)

    def __str__(self) -> str:
        return f"[{self.customer_code or self.id}] {self.display_name} — {self.city}"

    def __repr__(self) -> str:
        return (
            f"<Customer id={self.id} code={self.customer_code!r} "
            f"shop={self.shop_id} status={self.status!r} "
            f"balance={self.outstanding_balance}>"
        )


class CanType(models.Model):
     admin = models.ForeignKey(User, on_delete=models.CASCADE)
     can_type = models.CharField(max_length=100)
     price = models.DecimalField(max_digits=10, decimal_places=2)
     # Whether this can type is enabled for new selections. When disabled, existing
     # deliveries keep their original can_type but the type is hidden from admin/staff
     # selectors to avoid accidental reuse.
     enabled = models.BooleanField(default=True)

     class Meta:
          unique_together = (('admin', 'can_type'),)

     def __str__(self):
          return f"{self.can_type}"


class CanTransaction(models.Model):
     """Ledger entry for cans per customer."""
     admin = models.ForeignKey(User, on_delete=models.CASCADE, related_name='can_transactions')
     shop = models.ForeignKey('Shop', on_delete=models.CASCADE, related_name='can_transactions')
     customer = models.ForeignKey('Customer', on_delete=models.CASCADE, related_name='can_transactions')
     date = models.DateField(default=timezone.now)
     full_cans_delivered = models.PositiveIntegerField(default=0)
     empty_cans_received = models.PositiveIntegerField(default=0)
     balance_after_transaction = models.IntegerField(default=0)
     related_delivery = models.ForeignKey('DailyDelivery', on_delete=models.SET_NULL, null=True, blank=True, related_name='can_transactions')
     created_at = models.DateTimeField(auto_now_add=True)

     # Optional comments for adjustments or manual ledger notes.
     # Purpose:
     # - Stores a human-readable explanation for ADJUSTMENT entries or any
     #   manual ledger note that an operator/administrator wants to keep
     #   alongside the can-transaction row (examples: "corrected duplicate",
     #   "physical stock count adjustment", "daily reconciliation").
     # - This field is purely informational and does not affect balance
     #   calculations. It exists to improve auditability and make it easier
     #   to trace why a non-delivery adjustment was made.
     # Compatibility note:
     # - Adding this nullable field is backward-compatible: existing rows
     #   will have NULL comments and logic that computes balances remains
     #   unchanged. You still need to create and apply a migration to add
     #   the column to the database.
     comments = models.TextField(null=True, blank=True)

     TRANSACTION_TYPES = (
          ('OPENING', 'Opening Balance'),
          ('DELIVERY', 'Delivery'),
          # ADJUSTMENT is used for manual ledger edits that should NOT create
          # a DailyDelivery object. Typical uses: stock-count corrections,
          # reconciliation fixes, or administrative adjustments. The numeric
          # balance logic is identical to DELIVERY entries — the only
          # behavioural difference is that an ADJUSTMENT is unrelated to any
          # `DailyDelivery` and thus will not affect invoices/payments.
          ('ADJUSTMENT', 'Adjusting Entry'),
     )
     transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPES, default='DELIVERY')

     class Meta:
          ordering = ['date', 'id']
          unique_together = ('related_delivery', 'transaction_type')

     def save(self, *args, **kwargs):
          """Save a CanTransaction while preserving ledger consistency.

          Behaviour summary (keeps legacy behaviour intact):
          - Validates required fields and opening-entry constraints.
          - Uses an atomic block plus `select_for_update()` to avoid
               race conditions when multiple processes write the same
               customer's ledger at once.
          - Computes the running balance from the previous transaction
               and updates subsequent rows to keep stored balances correct.

          Adding `ADJUSTMENT` and `comments` does not alter the numeric
          accounting logic: ADJUSTMENT rows are treated the same as DELIVERY
          rows for balance computation but are intentionally not linked to
          `DailyDelivery` (so they don't create invoices/payments).
          """
          # Basic required fields
          if not self.customer_id:
               raise ValidationError('CanTransaction must be linked to a customer.')

          # Ensure admin is present for scoping
          if not getattr(self, 'admin', None):
               raise ValidationError('CanTransaction must be linked to an admin/shop.')

          # Use 0 when `self.id` is None to avoid passing None to id lookups
          current_id_for_compare = self.id or 0

          # If this is an OPENING transaction, ensure only one opening exists and it's the first
          if getattr(self, 'transaction_type', '') == 'OPENING':
               exists = CanTransaction.objects.filter(
                    customer=self.customer,
                    admin=self.admin,
                    transaction_type='OPENING'
               ).exclude(id=self.id)
               if exists.exists():
                    raise ValidationError('An opening balance already exists for this customer.')

               earlier = CanTransaction.objects.filter(
                    customer=self.customer,
                    admin=self.admin
               ).exclude(id=self.id).filter(
                    Q(date__lt=self.date) | Q(date=self.date, id__lt=current_id_for_compare)
               )
               # Ensure opening's empties are zero
               if (self.empty_cans_received or 0) > 0:
                    raise ValidationError('Opening balance cannot have empty cans returned.')

          # Main save + balance propagation in an atomic block with row locking where supported
          from django.apps import apps
          CanTransactionModel = apps.get_model('accounts', 'CanTransaction')
          with transaction.atomic():
               # Queryset scoped and locked for update to avoid concurrent races (if DB supports it)
               base_qs = CanTransactionModel.objects.select_for_update().filter(customer=self.customer, admin=self.admin)

               # Determine the previous transaction
               if getattr(self, 'id', None):
                    prev = base_qs.exclude(id=self.id).filter(
                         Q(date__lt=self.date) | Q(date=self.date, id__lt=self.id)
                    ).order_by('-date', '-id').first()
               else:
                    prev = base_qs.filter(date__lte=self.date).order_by('-date', '-id').first()
               prev_balance = prev.balance_after_transaction if prev else 0

               # Prevent accepting empty cans received greater than customer's outstanding balance
               try:
                    empty_received_val = int(self.empty_cans_received or 0)
               except Exception:
                    empty_received_val = 0
               allowed_empty = prev_balance + (int(self.full_cans_delivered or 0))
               if empty_received_val > allowed_empty:
                    raise ValidationError('Empty cans received cannot exceed previous outstanding plus full cans delivered in this transaction.')

               # Compute running balance and validate non-negative
               running = prev_balance + (self.full_cans_delivered or 0) - (self.empty_cans_received or 0)
               if running < 0:
                    raise ValidationError('Resulting can balance would be negative.')

               self.balance_after_transaction = running
               super().save(*args, **kwargs)

               # Propagate balance to later transactions (use locked queryset)
               later_qs = base_qs.exclude(id=self.id).filter(
                    Q(date__gt=self.date) | Q(date=self.date, id__gt=self.id)
               ).order_by('date', 'id')

               cur = running
               for t in later_qs:
                    cur = cur + (t.full_cans_delivered or 0) - (t.empty_cans_received or 0)
                    if t.balance_after_transaction != cur:
                         CanTransactionModel.objects.filter(id=t.id).update(balance_after_transaction=cur)


class CustomerCanType(models.Model):
     """Assign a CanType to a Customer with an optional per-customer price override."""
     admin = models.ForeignKey(User, on_delete=models.CASCADE)
     customer = models.ForeignKey('Customer', on_delete=models.CASCADE, related_name='customer_cans')
     can_type = models.ForeignKey(CanType, on_delete=models.CASCADE, related_name='customer_assignments')
     price = models.DecimalField(max_digits=10, decimal_places=2)

     class Meta:
          unique_together = (('customer', 'can_type'),)

     def save(self, *args, **kwargs):
          # Default price to the canonical can type price if not provided
          if (self.price is None or self.price == 0) and getattr(self, 'can_type', None):
               try:
                    self.price = self.can_type.price
               except Exception:
                    pass
          super().save(*args, **kwargs)

     def __str__(self):
          return f"{self.customer} - {self.can_type} @ {self.price}"

class DailyDelivery(models.Model):
     admin = models.ForeignKey(User, on_delete=models.CASCADE, related_name="admin", verbose_name="Shop Owner")
     customer = models.ForeignKey("Customer", on_delete=models.CASCADE, related_name="deliveries")
     staff = models.ForeignKey("Staff", on_delete=models.CASCADE, related_name="deliveries", null=True, blank=True)
     rate_given = models.DecimalField(default=0, decimal_places=2, max_digits=6, blank=True, verbose_name="Rate/Unit")

     delivery_date = models.DateField(default=timezone.now)
     entry_date = models.DateField(default=timezone.now, help_text="Date the delivery entry was recorded")
     delivered_time = models.TimeField(auto_now_add=True)
     quantity_delivered = models.PositiveIntegerField(help_text="Cans delivered", default=0)
     empty_cans_received = models.PositiveIntegerField(help_text="Empty cans returned by customer", default=0)
     can_type = models.ForeignKey('CanType', on_delete=models.CASCADE, related_name="deliveries")
     created_at = models.DateTimeField(auto_now_add=True)

     PAYMENT_STATUS_CHOICES = (
          ("unpaid", "Unpaid"),
          ("paid", "Paid"),
          ("partial", "Partially Paid"),
     )
     payment_status = models.CharField(max_length=10, choices=PAYMENT_STATUS_CHOICES, default="unpaid")

     class Meta:
          ordering = ['-id']

     def save(self, *args, **kwargs):
          # 1️⃣ Default rate
          if getattr(self, 'can_type', None) and (self.rate_given is None or self.rate_given == 0):
               try:
                    self.rate_given = self.can_type.price
               except Exception:
                    pass
          from django.apps import apps
          CanTransactionModel = apps.get_model('accounts', 'CanTransaction')

          # 2️⃣ Save delivery first to get ID
          with transaction.atomic():
               super().save(*args, **kwargs)

               # 3️⃣ Create or update CanTransaction for this delivery
               ct, created = CanTransactionModel.objects.get_or_create(
                    related_delivery=self,
                    defaults={
                         'admin': self.admin,
                         'shop': getattr(self.admin, 'shop_admin', getattr(self.admin, 'shop', None)),
                         'customer': self.customer,
                         'date': self.delivery_date,
                         'full_cans_delivered': self.quantity_delivered,
                         'empty_cans_received': self.empty_cans_received,
                    }
               )

               if not created:
                    ct.full_cans_delivered = self.quantity_delivered
                    ct.empty_cans_received = self.empty_cans_received
                    ct.date = self.delivery_date

               # 4️⃣ Save CanTransaction → will compute running balance & propagate
               ct.save()

               # DailyDelivery.save() ke andar (super().save ke baad aur CanTransaction ke baad)
               # ... existing code ...

               # 5️⃣ Automatic Receivable Ledger Entry (Debit)
               from django.apps import apps
               ReceivableLedgerModel = apps.get_model('accounts', 'ReceivableLedger')

               ledger, created = ReceivableLedgerModel.objects.get_or_create(
                    delivery=self,
                    defaults={
                         'admin': self.admin,
                         'shop': getattr(self.admin, 'shop_admin', getattr(self.admin, 'shop', None)),
                         'customer': self.customer,
                         'date': self.delivery_date,
                         'transaction_type': 'delivery',
                         'debit': Decimal(self.quantity_delivered) * Decimal(self.rate_given or 0),
                         'credit': Decimal('0'),
                         'description': f"Delivery #{self.id} - {self.quantity_delivered} cans @ {self.rate_given}",
                    }
               )
               if not created:
                    ledger.debit = Decimal(self.quantity_delivered) * Decimal(self.rate_given or 0)
                    ledger.date = self.delivery_date
                    ledger.save()

               # Clear dashboard cache after ledger update
               from django.core.cache import cache
               cache_key = f"dashboard_{self.admin_id}"
               cache.delete(cache_key)

     def __str__(self):
          return f"Delivery to {self.customer.display_name} on {self.delivery_date}"




# -------------------- EXPENSE LEDGER (Complete - Compatible with your WSMS models) --------------------
# Paste this at the bottom of your models.py
# Make sure these imports are at the top of models.py (add if missing):
# from django.apps import apps
# from django.db import transaction
# from django.core.exceptions import ValidationError
# from decimal import Decimal
# from django.db.models import Q

class ExpenseCategory(models.Model):
    """Categories for expenses e.g. Rent, Fuel, Salary, Maintenance"""
    admin = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="expense_categories"
    )
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)

    class Meta:
        unique_together = (('admin', 'name'),)

    def __str__(self):
        return self.name


class Expense(models.Model):
    STATUS_CHOICES = (
        ("pending", "Pending"),
        ("paid", "Paid"),
        ("cancelled", "Cancelled"),
    )

    admin = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="expenses"
    )
    shop = models.ForeignKey(
        "Shop",
        on_delete=models.CASCADE,
        related_name="expenses"
    )
    category = models.ForeignKey(
        ExpenseCategory,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="expenses"
    )

    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    expense_date = models.DateField(default=timezone.now)

    PAYMENT_METHOD_CHOICES = (
        ("cash", "Cash"),
        ("bank_transfer", "Bank Transfer"),
        ("card", "Card"),
        ("other", "Other"),
    )
    payment_method = models.CharField(
        max_length=50,
        choices=PAYMENT_METHOD_CHOICES,
        blank=True,
        null=True
    )
    reference = models.CharField(max_length=100, blank=True, null=True)
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default="paid"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-expense_date', '-id']

    def __str__(self):
        return f"{self.title} - {self.amount}"

    def save(self, *args, **kwargs):
        """
        Save the expense and automatically create/update its ExpenseLedger entry.
        Only 'paid' expenses create a ledger debit.
        Cancelled expenses create a credit (reversal) if a ledger entry existed.
        """
        from django.apps import apps

        is_new = self.pk is None

        # Get old status before saving (to detect status changes)
        old_status = None
        if not is_new:
            try:
                old_status = Expense.objects.get(pk=self.pk).status
            except Expense.DoesNotExist:
                pass

        super().save(*args, **kwargs)  # Save first to get self.pk (fixes the id=0 bug)

        ExpenseLedgerModel = apps.get_model('accounts', 'ExpenseLedger')

        if self.status == 'paid':
            # Create or update the debit ledger entry
            ledger, created = ExpenseLedgerModel.objects.get_or_create(
                expense=self,
                transaction_type='expense',
                defaults={
                    'admin': self.admin,
                    'shop': self.shop,
                    'date': self.expense_date,
                    'debit': self.amount,
                    'credit': Decimal('0.00'),
                    'description': self.title,
                    'category': self.category,
                }
            )
            if not created:
                # Update existing ledger entry if amount, date, or description changed
                changed = (
                    ledger.debit != self.amount
                    or ledger.date != self.expense_date
                    or ledger.description != self.title
                    or ledger.category != self.category
                )
                if changed:
                    ledger.debit = self.amount
                    ledger.date = self.expense_date
                    ledger.description = self.title
                    ledger.category = self.category
                    ledger.save()  # This triggers running balance recalculation

        elif self.status == 'cancelled':
            # If expense was previously 'paid', reverse it via a credit entry
            # Check if a debit ledger entry exists for this expense
            try:
                existing_debit = ExpenseLedgerModel.objects.get(
                    expense=self,
                    transaction_type='expense'
                )
                # Create a reversal/credit entry if it doesn't already exist
                ExpenseLedgerModel.objects.get_or_create(
                    expense=self,
                    transaction_type='adjustment',
                    defaults={
                        'admin': self.admin,
                        'shop': self.shop,
                        'date': timezone.now().date(),
                        'debit': Decimal('0.00'),
                        'credit': existing_debit.debit,  # Reverse the original amount
                        'description': f"Reversal: {self.title} (Cancelled)",
                        'category': self.category,
                    }
                )
            except ExpenseLedgerModel.DoesNotExist:
                pass  # No ledger entry existed, nothing to reverse

        # Clear dashboard cache
        try:
            from django.core.cache import cache
            cache.delete(f"dashboard_{self.admin_id}")
        except Exception:
            pass


class ExpenseLedger(models.Model):
    """
    Running expense ledger scoped per (admin, shop).
    Mirrors ReceivableLedger's pattern but for outgoing money.

    debit  = money OUT (expense paid)
    credit = money back IN (refund, reversal, cancellation)
    balance_after = cumulative total spent (debit - credit running sum)
    """

    TRANSACTION_TYPE_CHOICES = (
        ('expense', 'Expense'),
        ('adjustment', 'Adjustment / Reversal'),
    )

    admin = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="expense_ledgers"
    )
    shop = models.ForeignKey(
        "Shop",
        on_delete=models.CASCADE,
        related_name="expense_ledgers"
    )
    expense = models.ForeignKey(
        "Expense",
        on_delete=models.CASCADE,
        related_name="ledger_entries",
        null=True,
        blank=True
    )
    category = models.ForeignKey(
        "ExpenseCategory",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="ledger_entries"
    )

    date = models.DateField(default=timezone.now)
    transaction_type = models.CharField(
        max_length=20,
        choices=TRANSACTION_TYPE_CHOICES,
        default='expense'
    )

    debit = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        default=Decimal('0.00'),
        help_text="Money OUT (expense paid)"
    )
    credit = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        default=Decimal('0.00'),
        help_text="Money back IN (refund or reversal)"
    )
    balance_after = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        default=Decimal('0.00'),
        help_text="Cumulative total spent after this entry"
    )

    description = models.CharField(max_length=255, blank=True)
    notes = models.TextField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['date', 'id']
        indexes = [
            models.Index(fields=['admin', 'shop', 'date']),
            models.Index(fields=['admin', 'shop', 'date', 'id']),
        ]

    def __str__(self):
        return f"{self.shop} | {self.get_transaction_type_display()} | {self.date} | {self.description} | Bal: {self.balance_after}"

    def save(self, *args, **kwargs):
        """
        Compute running balance and propagate to all later entries.
        Mirrors ReceivableLedger.save() exactly.

        FIX vs your original code:
        - For new entries (no self.id yet), super().save() is called FIRST
          to get a real pk, THEN the balance is computed.
          This fixes the id__lt=0 bug that always returned prev=None.
        """
        from django.db.models import Q

        if not self.admin_id or not self.shop_id:
            raise ValidationError('ExpenseLedger must have admin and shop.')

        with transaction.atomic():
            base_qs = ExpenseLedger.objects.select_for_update().filter(
                admin=self.admin,
                shop=self.shop,
            )

            is_new = self.pk is None

            if is_new:
                # Step 1: Save first to get a real pk
                # Find prev BEFORE saving (date filter only, since id doesn't exist yet)
                prev = base_qs.filter(
                    date__lt=self.date
                ).order_by('-date', '-id').first()

                if prev is None:
                    # Check same-date entries (none exist yet for this entry since pk is None)
                    prev = base_qs.filter(date=self.date).order_by('-date', '-id').first()

                prev_balance = prev.balance_after if prev else Decimal('0.00')
                self.balance_after = prev_balance + (self.debit - self.credit)

                super().save(*args, **kwargs)  # Now has a real pk

            else:
                # Existing entry: find prev excluding self
                prev = base_qs.exclude(id=self.pk).filter(
                    Q(date__lt=self.date) | Q(date=self.date, id__lt=self.pk)
                ).order_by('-date', '-id').first()

                prev_balance = prev.balance_after if prev else Decimal('0.00')
                self.balance_after = prev_balance + (self.debit - self.credit)

                super().save(*args, **kwargs)

            # Step 2: Propagate updated balance to all later entries
            later_entries = base_qs.exclude(id=self.pk).filter(
                Q(date__gt=self.date) | Q(date=self.date, id__gt=self.pk)
            ).order_by('date', 'id')

            current = self.balance_after
            for entry in later_entries:
                current += (entry.debit - entry.credit)
                if entry.balance_after != current:
                    ExpenseLedger.objects.filter(id=entry.id).update(balance_after=current)


import math

class DeliveryAssignment(models.Model):
    STATUS_CHOICES = (
        ('pending',    'Pending'),
        ('in_progress','In Progress'),
        ('done',       'Done'),
        ('failed',     'Failed / Not Delivered'),
    )

    admin    = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name='assigned_deliveries_created', verbose_name='Shop Owner',
    )
    shop     = models.ForeignKey('Shop', on_delete=models.CASCADE, related_name='assigned_deliveries')
    staff    = models.ForeignKey(
        'Staff', on_delete=models.CASCADE,
        related_name='assigned_deliveries', verbose_name='Assigned Rider',
    )
    customer = models.ForeignKey('Customer', on_delete=models.CASCADE, related_name='assigned_deliveries')
    can_type = models.ForeignKey('CanType', on_delete=models.CASCADE, related_name='assigned_deliveries')

    quantity_to_deliver = models.PositiveIntegerField(default=1)
    rate_given          = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    delivery_date       = models.DateField(default=timezone.now)
    notes               = models.TextField(blank=True, null=True)

    status         = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending', db_index=True)
    completed_at   = models.DateTimeField(null=True, blank=True)
    failure_reason = models.CharField(max_length=255, blank=True, null=True)

    resulting_delivery = models.OneToOneField(
        'DailyDelivery', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='assigned_delivery_source',
    )
    sort_order = models.PositiveSmallIntegerField(default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['delivery_date', 'sort_order', 'id']
        indexes = [
            models.Index(fields=['staff', 'delivery_date', 'status'], name='idx_ad_staff_date_status'),
            models.Index(fields=['admin', 'delivery_date'],            name='idx_ad_admin_date'),
            models.Index(fields=['customer', 'delivery_date'],         name='idx_ad_customer_date'),
        ]

    def __str__(self):
        return f"[{self.delivery_date}] {self.staff.first_name} → {self.customer.display_name} × {self.quantity_to_deliver} ({self.get_status_display()})"

    def mark_done(self, empty_cans_received=0):
        from django.apps import apps
        if self.status == 'done':
            return self.resulting_delivery
        DailyDeliveryModel = apps.get_model('accounts', 'DailyDelivery')
        delivery = DailyDeliveryModel.objects.create(
            admin=self.admin,
            staff=self.staff,
            customer=self.customer,
            can_type=self.can_type,
            quantity_delivered=self.quantity_to_deliver,
            empty_cans_received=int(empty_cans_received or 0),
            delivery_date=self.delivery_date,
            rate_given=self.rate_given,
        )
        self.status = 'done'
        self.completed_at = timezone.now()
        self.resulting_delivery = delivery
        self.save(update_fields=['status', 'completed_at', 'resulting_delivery', 'updated_at'])
        return delivery

    def mark_failed(self, reason=''):
        self.status = 'failed'
        self.failure_reason = reason or 'Not delivered'
        self.completed_at = timezone.now()
        self.save(update_fields=['status', 'failure_reason', 'completed_at', 'updated_at'])

    @property
    def is_done(self):
        return self.status == 'done'

    @property
    def is_pending(self):
        return self.status == 'pending'


