from django import template
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

register = template.Library()

@register.filter
def multiply(value, arg):
    """Multiply two numbers safely using Decimal and return with 2 decimal places."""
    try:
        a = Decimal(value)
        b = Decimal(arg)
        res = a * b
        # round to 2 decimal places for currency-like display
        res = res.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        return str(res)
    except (InvalidOperation, TypeError, ValueError):
        try:
            return str(float(value) * float(arg))
        except Exception:
            return ""
