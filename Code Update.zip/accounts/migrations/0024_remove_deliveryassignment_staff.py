
# Generated manually to remove staff field from DeliveryAssignment

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('accounts', '0023_deliveryassignment_and_more'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='deliveryassignment',
            name='staff',
        ),
    ]
