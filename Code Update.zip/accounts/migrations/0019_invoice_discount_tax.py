"""
Django migration — add discount/tax columns to Invoice and InvoiceItem,
and add the three cached summary columns to Invoice.

Apply with:
    python manage.py migrate accounts
"""

from django.db import migrations, models
import decimal


class Migration(migrations.Migration):

    # ── IMPORTANT: replace 'XXXX_previous_migration' with the name of
    #    your latest migration file in accounts/migrations/
    dependencies = [
        ('accounts', '0018_remove_shop_delivery_radius_km'),   # <─ CHANGE THIS to your latest migration name
    ]

    operations = [

        # ────────────────────────────────────────────────────────────────────
        # InvoiceItem — new columns
        # ────────────────────────────────────────────────────────────────────
        migrations.AddField(
            model_name='invoiceitem',
            name='gross_amount',
            field=models.DecimalField(
                max_digits=12,
                decimal_places=2,
                default=decimal.Decimal('0.00'),
                help_text='qty × unit_price before any discount/tax',
            ),
        ),
        migrations.AddField(
            model_name='invoiceitem',
            name='discount_amount',
            field=models.DecimalField(
                max_digits=12,
                decimal_places=2,
                default=decimal.Decimal('0.00'),
                help_text='Discount applied to this line',
            ),
        ),
        migrations.AddField(
            model_name='invoiceitem',
            name='tax_amount',
            field=models.DecimalField(
                max_digits=12,
                decimal_places=2,
                default=decimal.Decimal('0.00'),
                help_text='Tax applied after discount',
            ),
        ),

        # ────────────────────────────────────────────────────────────────────
        # Invoice — change max_digits on total_amount (old: 999999999 → 14)
        # and add cached summary columns
        # ────────────────────────────────────────────────────────────────────
        migrations.AlterField(
            model_name='invoice',
            name='total_amount',
            field=models.DecimalField(
                max_digits=14,
                decimal_places=2,
                default=decimal.Decimal('0'),
            ),
        ),
        migrations.AddField(
            model_name='invoice',
            name='subtotal',
            field=models.DecimalField(
                max_digits=14,
                decimal_places=2,
                default=decimal.Decimal('0'),
                help_text='Sum of gross_amount across all items (before disc/tax)',
            ),
        ),
        migrations.AddField(
            model_name='invoice',
            name='total_discount',
            field=models.DecimalField(
                max_digits=14,
                decimal_places=2,
                default=decimal.Decimal('0'),
                help_text='Sum of discount_amount across all items',
            ),
        ),
        migrations.AddField(
            model_name='invoice',
            name='total_tax',
            field=models.DecimalField(
                max_digits=14,
                decimal_places=2,
                default=decimal.Decimal('0'),
                help_text='Sum of tax_amount across all items',
            ),
        ),
    ]