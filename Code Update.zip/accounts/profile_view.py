from accounts import models  # adjust import path as needed
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils.translation import gettext as _
import json


# Re-export constants so template can receive them via context
CURRENCY_CHOICES = [
    ('PKR', 'PKR - Pakistani Rupee'),
    ('INR', 'INR - Indian Rupee'),
    ('BDT', 'BDT - Bangladeshi Taka'),
    ('AED', 'AED - UAE Dirham'),
    ('SAR', 'SAR - Saudi Riyal'),
    ('QAR', 'QAR - Qatari Riyal'),
    ('KWD', 'KWD - Kuwaiti Dinar'),
    ('BHD', 'BHD - Bahraini Dinar'),
    ('OMR', 'OMR - Omani Rial'),
    ('USD', 'USD - US Dollar'),
]

COUNTRY_CHOICES = [
    ('PK', 'Pakistan'), ('IN', 'India'), ('BD', 'Bangladesh'),
    ('AE', 'UAE'), ('SA', 'Saudi Arabia'), ('QA', 'Qatar'),
    ('KW', 'Kuwait'), ('BH', 'Bahrain'), ('OM', 'Oman'),
]

DAYS_OF_WEEK = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']


@login_required
def profile(request):
    """Show and edit profile and shop settings."""
    user = request.user
    shop = getattr(user, 'shop', None)

    if request.method == 'POST':
        # ── Personal / Account fields ──────────────────────────────────────
        user.first_name = request.POST.get('first_name') or user.first_name
        user.last_name  = request.POST.get('last_name')  or user.last_name
        user.email      = request.POST.get('email')      or user.email
        user.whatsapp_number = request.POST.get('whatsapp_number') or user.whatsapp_number

        # ── API Keys (JSON) ────────────────────────────────────────────────
        api_keys_raw = request.POST.get('api_keys', '').strip()
        if api_keys_raw:
            try:
                user.api_keys = json.loads(api_keys_raw)
            except (ValueError, TypeError):
                messages.error(request, _('API Keys field contains invalid JSON. Please fix it and try again.'))
                return redirect('profile')
        else:
            # Clear keys if field was emptied
            user.api_keys = None

        # ── WhatsApp API credentials ────────────────────────────────────────
        wa_phone_id = request.POST.get('meta_whatsapp_phone_number_id', '').strip()
        if wa_phone_id:
            user.meta_whatsapp_phone_number_id = wa_phone_id

        wa_token = request.POST.get('meta_whatsapp_access_token', '').strip()
        if wa_token:
            user.meta_whatsapp_access_token = wa_token

        # ── SMTP fields ────────────────────────────────────────────────────
        user.smtp_host       = request.POST.get('smtp_host', '').strip() or user.smtp_host
        user.smtp_from_email = request.POST.get('smtp_from_email', '').strip() or user.smtp_from_email
        user.smtp_username   = request.POST.get('smtp_username', '').strip() or user.smtp_username
        user.smtp_use_tls    = bool(request.POST.get('smtp_use_tls'))
        user.smtp_use_ssl    = bool(request.POST.get('smtp_use_ssl'))

        smtp_port_raw = request.POST.get('smtp_port', '').strip()
        if smtp_port_raw:
            try:
                user.smtp_port = int(smtp_port_raw)
            except ValueError:
                messages.error(request, _('Invalid SMTP port — must be a number.'))
                return redirect('profile')

        smtp_password = request.POST.get('smtp_password', '').strip()
        if smtp_password:
            user.smtp_password = smtp_password

        user.save()

        # ── Shop fields ────────────────────────────────────────────────────
        shop_name = request.POST.get('shop_name', '').strip()
        if shop_name:
            if not shop:
                shop = models.Shop.objects.create(name=shop_name, admin=user)
            else:
                shop.name = shop_name

        if shop:
            shop.phone_number       = request.POST.get('shop_phone', '').strip() or shop.phone_number
            shop.email              = request.POST.get('shop_email', '').strip() or None
            shop.description        = request.POST.get('description', '').strip() or ''
            shop.registration_number= request.POST.get('registration_number', '').strip() or ''
            shop.currency           = request.POST.get('currency') or shop.currency or 'PKR'
            shop.country            = request.POST.get('country')  or shop.country  or 'PK'
            shop.address            = request.POST.get('shop_address', '').strip() or ''
            shop.city               = request.POST.get('city', '').strip() or 'Karachi'
            shop.is_active          = bool(request.POST.get('is_active'))
            shop.opening_time       = request.POST.get('opening_time') or None
            shop.closing_time       = request.POST.get('closing_time') or None

            # Customer limit
            limit_raw = request.POST.get('customer_limit', '').strip()
            if limit_raw:
                try:
                    shop.customer_limit = int(limit_raw)
                except ValueError:
                    messages.error(request, _('Customer limit must be a whole number.'))
                    return redirect('profile')

            # GPS coordinates
            lat_raw = request.POST.get('latitude', '').strip()
            lng_raw = request.POST.get('longitude', '').strip()
            if lat_raw and lng_raw:
                try:
                    shop.latitude  = float(lat_raw)
                    shop.longitude = float(lng_raw)
                except ValueError:
                    messages.error(request, _('Invalid GPS coordinates.'))
                    return redirect('profile')

            # Working days — multiple checkbox values
            working_days = request.POST.getlist('working_days')
            shop.working_days = working_days if working_days else []

            # Logo upload
            if request.FILES.get('logo'):
                # Delete old logo to save storage
                if shop.logo:
                    try:
                        shop.logo.delete(save=False)
                    except Exception:
                        pass
                shop.logo = request.FILES['logo']

            shop.save()

        messages.success(request, _('Profile and shop settings updated successfully.'))
        return redirect('profile')

    # ── GET — build context ────────────────────────────────────────────────
    working_days_list = shop.working_days if (shop and shop.working_days) else []
    # Normalise to list in case it's stored as something else
    if not isinstance(working_days_list, list):
        working_days_list = list(working_days_list)

    context = {
        'user': user,
        'shop': shop,
        'currency_choices': CURRENCY_CHOICES,
        'country_choices':  COUNTRY_CHOICES,
        'days_of_week':     DAYS_OF_WEEK,
        'working_days_list': working_days_list,
    }
    return render(request, 'accounts/profile.html', context)