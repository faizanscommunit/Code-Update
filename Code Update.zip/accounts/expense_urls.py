# -------------------- urls/expense_urls.py --------------------
# Add these to your main urls.py with:
#   path('expenses/', include('accounts.expense_urls')),
# OR paste directly into your existing urls.py

from django.urls import path
from . import expense_views   # or wherever your views live

urlpatterns = [
    # List
    path('',                          expense_views.expense_list,           name='expense_list'),
    # Add / Edit / Cancel
    path('add/',                      expense_views.expense_add,            name='expense_add'),
    path('<int:pk>/edit/',            expense_views.expense_edit,           name='expense_edit'),
    path('<int:pk>/cancel/',          expense_views.expense_cancel,         name='expense_cancel'),
    # Ledger report
    path('ledger/',                   expense_views.expense_ledger_report,  name='expense_ledger_report'),
    # Categories
    path('categories/',               expense_views.expense_category_list,  name='expense_category_list'),
    path('categories/add/',           expense_views.expense_category_add,   name='expense_category_add'),
    path('delete-all/', expense_views.expense_delete_all, name='expense_delete_all'),
]