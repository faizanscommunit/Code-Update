from django.test import TestCase
from django.urls import reverse
from . import models
from django.contrib.auth import get_user_model

User = get_user_model()

class StaffAssignedCustomersTests(TestCase):
    def setUp(self):
        # create admin/shop
        self.admin = User.objects.create_user(username='admin1', password='pass', role='shop_admin')
        shop = models.Shop.objects.create(name='Test Shop', admin=self.admin)
        self.admin.shop = shop
        self.admin.save()

        # create customers
        self.c1 = models.Customer.objects.create(admin=self.admin, shop=shop, first_name='A', last_name='B', email='a@e', phone_number='1', whatsapp_number='1', address='addr')
        self.c2 = models.Customer.objects.create(admin=self.admin, shop=shop, first_name='C', last_name='D', email='c@e', phone_number='2', whatsapp_number='2', address='addr2')

        # create staff and assign only c1
        self.staff_user = User.objects.create_user(username='staff1', password='pass', role='staff')
        self.staff_user.shop = shop
        self.staff_user.save()
        self.staff = models.Staff.objects.create(admin=self.admin, user=self.staff_user, first_name='S', last_name='T', phone_number='9', cnic='12345', address='a', salary=0)
        self.staff.customers.set([self.c1.id])

    def test_staff_sees_only_assigned_customers_on_record_delivery(self):
        self.client.login(username='staff1', password='pass')
        resp = self.client.get(reverse('record_delivery'))
        self.assertEqual(resp.status_code, 200)
        customers = resp.context['customers']
        self.assertQuerysetEqual(customers, [repr(self.c1)], ordered=False)

    def test_staff_delivery_uses_customer_specific_rate_when_assigned(self):
        # assign can type and custom price
        can = models.CanType.objects.create(admin=self.admin, can_type='Small', price=10)
        models.CustomerCanType.objects.create(admin=self.admin, customer=self.c1, can_type=can, price=15)
        # login as staff and submit delivery (no rate field posted)
        self.client.login(username='staff1', password='pass')
        resp = self.client.post(reverse('record_delivery'), {'customer_id': self.c1.id, 'can_type': can.id, 'quantity_cans': '2'}, follow=True)
        self.assertEqual(resp.status_code, 200)
        d = models.DailyDelivery.objects.filter(customer=self.c1, can_type=can).first()
        self.assertIsNotNone(d)
        self.assertEqual(int(d.rate_given), 15)

    def test_staff_cannot_use_unassigned_can_when_customer_has_assignments(self):
        # assign only can2 to customer
        can1 = models.CanType.objects.create(admin=self.admin, can_type='Small', price=10)
        can2 = models.CanType.objects.create(admin=self.admin, can_type='Large', price=20)
        models.CustomerCanType.objects.create(admin=self.admin, customer=self.c1, can_type=can2, price=18)
        self.client.login(username='staff1', password='pass')
        resp = self.client.post(reverse('record_delivery'), {'customer_id': self.c1.id, 'can_type': can1.id, 'quantity_cans': '1'})
        # Should be redirected back and not create delivery
        self.assertFalse(models.DailyDelivery.objects.filter(customer=self.c1).exists())
