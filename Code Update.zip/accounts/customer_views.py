"""
WSMS Cloud System — Customer Views  (complete replacement)
============================================================
Replaces the original customer_views.py.

What changed vs the previous version:
  • customer_create / customer_edit pass `price_per_can` from the form so admins
    can set a flat override.
  • customer_delete is now customer_soft_delete (uses Customer.soft_delete()).
  • A hard_delete helper is kept for admin panel use only.
  • Invoice-aware: no invoice logic here; that lives in views.py.
"""

from django.contrib import messages
from django.db import transaction
from django.shortcuts import redirect, render, get_object_or_404
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from decimal import Decimal, InvalidOperation

from accounts import models
from .decorators import shop_admin_required          # decorator lives in decorators.py


# ─────────────────────────────────────────────────────────────────────────────
# INTERNAL HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_admin(request_user):
    """Return (admin_user, shop). Staff users are resolved to their shop admin."""
    admin_user = request_user
    try:
        if getattr(request_user, 'role', None) != 'shop_admin':
            st = models.Staff.objects.filter(user=request_user).first()
            if st and getattr(st, 'admin', None):
                admin_user = st.admin
    except Exception:
        pass
    shop = models.Shop.objects.filter(admin=admin_user).first()
    return admin_user, shop


def _decimal_or(val, default=Decimal('0.00')):
    """Parse a POST string to Decimal; return *default* on failure."""
    if val is None:
        return default
    s = str(val).strip()
    if not s:
        return default
    try:
        return Decimal(s)
    except InvalidOperation:
        return default


def _int_or(val, default=0):
    try:
        return int(str(val).strip())
    except (ValueError, TypeError):
        return default


def _bool_field(post, key):
    return post.get(key) in ('on', '1', 'true', 'True', True)


def _extract_customer_fields(post):
    """
    Pull every customer-model field from POST.
    Returns a plain dict — FK fields (default_can_type, referred_by) are
    handled separately by the caller after DB lookups.
    """
    return {
        # ── Identity ────────────────────────────────────────────────────────
        'customer_type': post.get('customer_type', 'residential'),
        'first_name':    post.get('first_name', '').strip(),
        'last_name':     post.get('last_name',  '').strip(),
        'company_name':  post.get('company_name', '').strip(),
        'cnic':          post.get('cnic', '').strip(),
        'ntn':           post.get('ntn',  '').strip(),

        # ── Contact ─────────────────────────────────────────────────────────
        'phone_number':    post.get('phone_number',   '').strip(),
        'phone_number_2':  post.get('phone_number_2', '').strip(),
        'whatsapp_number': post.get('whatsapp_number','').strip(),
        'email':           post.get('email',          '').strip(),

        # ── Address ─────────────────────────────────────────────────────────
        'address_line_1': post.get('address_line_1', '').strip(),
        'address_line_2': post.get('address_line_2', '').strip(),
        'area':           post.get('area',  '').strip(),
        'city':           post.get('city', 'Karachi').strip(),
        'address_notes':  post.get('address_notes', '').strip(),
        'latitude':       _decimal_or(post.get('latitude'),  None),
        'longitude':      _decimal_or(post.get('longitude'), None),

        # ── Delivery Preferences ─────────────────────────────────────────────
        # default_can_type resolved separately
        'default_quantity':      _int_or(post.get('default_quantity'), 1),
        'delivery_shift':        post.get('delivery_shift', 'anytime'),
        'delivery_instructions': post.get('delivery_instructions', '').strip(),

        # ── Pricing ──────────────────────────────────────────────────────────
        'price_per_can':    _decimal_or(post.get('price_per_can'), None),   # flat override
        'discount_percent': _decimal_or(post.get('discount_percent'), Decimal('0.00')),
        'discount_flat':    _decimal_or(post.get('discount_flat'),    Decimal('0.00')),
        'is_tax_exempt':    _bool_field(post, 'is_tax_exempt'),
        'tax_rate':         _decimal_or(post.get('tax_rate'), Decimal('0.00')),

        # ── Billing ──────────────────────────────────────────────────────────
        'payment_terms':            post.get('payment_terms', 'monthly'),
        'preferred_payment_method': post.get('preferred_payment_method', 'cash'),
        'invoice_cycle_day':        _int_or(post.get('invoice_cycle_day'), 1),
        'invoice_notes':            post.get('invoice_notes', '').strip(),

        # ── Can Deposits ─────────────────────────────────────────────────────
        'deposit_per_can': _decimal_or(post.get('deposit_per_can'), Decimal('0.00')),

        # ── Status / Lifecycle ───────────────────────────────────────────────
        'status':    post.get('status', 'active'),
        'is_active': post.get('status', 'active') == 'active',
        'joined_date': post.get('joined_date') or timezone.now().date(),

        # ── CRM ──────────────────────────────────────────────────────────────
        'internal_notes':  post.get('internal_notes',  '').strip(),
        'tags':            post.get('tags',            '').strip(),
        'referral_source': post.get('referral_source', '').strip(),
    }


def _resolve_default_can_type(post, admin_user, current=None):
    raw = post.get('default_can_type_id', None)
    if raw is None:
        return current
    raw = str(raw).strip()
    if not raw:
        return None
    try:
        return models.CanType.objects.get(id=int(raw), admin=admin_user)
    except (models.CanType.DoesNotExist, ValueError):
        return current


def _resolve_referred_by(post, shop, current=None):
    raw = post.get('referred_by_id', None)
    if raw is None:
        return current
    raw = str(raw).strip()
    if not raw:
        return None
    try:
        return models.Customer.objects.get(id=int(raw), shop=shop)
    except (models.Customer.DoesNotExist, ValueError):
        return None


def _process_can_assignments(post, customer, admin_user):
    """
    Sync CustomerCanType rows from submitted form data.

    Form fields expected:
      can_type[]   — list of CanType IDs (checked/visible rows)
      can_price[]  — parallel list of optional price overrides
    """
    try:
        ct_ids_raw = post.getlist('can_type')
        ct_prices  = post.getlist('can_price')
        ct_ids     = [cid for cid in ct_ids_raw if cid and str(cid).strip()]

        if not ct_ids:
            models.CustomerCanType.objects.filter(customer=customer).delete()
            return

        # id → first-submitted price  (handles accidental duplicate rows)
        price_map = {}
        for idx, cid in enumerate(ct_ids_raw):
            if not cid or not str(cid).strip():
                continue
            if cid not in price_map:
                price_map[cid] = ct_prices[idx] if idx < len(ct_prices) else None

        # deduplicate IDs, preserve order
        seen, unique_ids = set(), []
        for cid in ct_ids:
            if cid not in seen:
                seen.add(cid)
                unique_ids.append(cid)

        saved_ids = []
        for cid in unique_ids:
            try:
                ct = models.CanType.objects.get(id=int(cid), admin=admin_user)
            except Exception:
                continue

            price_raw = price_map.get(cid)
            try:
                custom = Decimal(str(price_raw).strip()) if price_raw and str(price_raw).strip() else None
                price  = custom if (custom and custom > 0) else ct.price
            except (InvalidOperation, AttributeError):
                price = ct.price

            obj, _ = models.CustomerCanType.objects.update_or_create(
                customer=customer,
                can_type=ct,
                defaults={'admin': admin_user, 'price': price},
            )
            saved_ids.append(obj.id)

        if saved_ids:
            models.CustomerCanType.objects.filter(customer=customer).exclude(id__in=saved_ids).delete()
        else:
            models.CustomerCanType.objects.filter(customer=customer).delete()

    except Exception:
        pass   # never block a customer save due to can-assignment errors


def _generate_user_account(post, admin_user, first_name, last_name,
                            email, phone_number, whatsapp_number):
    """
    Create the Django User that backs the customer's self-service portal login.
    Returns (user_obj, raw_password).
    Raises ValueError with a human-readable message on username conflict.
    """
    import random, string

    form_username = (post.get('user_username') or '').strip() or None
    form_password = (post.get('user_password') or '').strip() or None

    # Build a sensible base username from the phone number
    base = None
    try:
        if phone_number:
            digits = ''.join(ch for ch in str(phone_number) if ch.isdigit())
            if digits:
                base = f"cust{digits}"
    except Exception:
        pass

    if form_username:
        if models.User.objects.filter(username=form_username).exists():
            raise ValueError(_('Username "%(u)s" is already taken.') % {'u': form_username})
        username = form_username
    else:
        candidate = base or f"customer{int(timezone.now().timestamp())}"
        username, suffix = candidate, 0
        while models.User.objects.filter(username=username).exists():
            suffix += 1
            username = f"{candidate}_{suffix}"

    if not form_password:
        form_password = ''.join(
            random.choice(string.ascii_letters + string.digits) for _ in range(10)
        )

    user_obj = models.User.objects.create_user(
        username=username,
        email=email or '',
        password=form_password,
        **{
            'role': 'customer',
            'shop': getattr(admin_user, 'shop', None),
            'shop_type': getattr(admin_user, 'shop_type', 'water'),
            'first_name': first_name,
            'last_name': last_name,
            'whatsapp_number': whatsapp_number,
            'is_demo': getattr(admin_user, 'is_demo', False),
        }
    )
    return user_obj, form_password


def _apply_fields(customer, fields):
    """Apply a field dict to a Customer instance (setattr loop)."""
    for attr, value in fields.items():
        setattr(customer, attr, value)


# ─────────────────────────────────────────────────────────────────────────────
# CREATE
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
def customer_create(request):
    """Create a new Customer + linked Django User account."""
    admin_user, shop = _resolve_admin(request.user)
    customers = models.Customer.objects.filter(shop__admin=admin_user)
    can_types = models.CanType.objects.filter(admin=admin_user, enabled=True)

    if request.method != 'POST':
        return render(request, 'accounts/customer_form.html', {
            'customers':     customers,
            'can_types':     can_types,
            'customer_cans': [],
            'customer':      None,
            'all_customers': customers,
        })

    fields = _extract_customer_fields(request.POST)

    try:
        with transaction.atomic():
            # Customer limit guard
            if shop and shop.customer_limit:
                if models.Customer.objects.filter(shop=shop, is_active=True).count() >= shop.customer_limit:
                    messages.error(request, _('Customer limit reached for this shop.'))
                    return redirect('customer_create')

            # Create linked User
            user_obj, raw_password = _generate_user_account(
                request.POST, admin_user,
                fields['first_name'], fields['last_name'],
                fields['email'], fields['phone_number'], fields['whatsapp_number'],
            )

            default_can_type = _resolve_default_can_type(request.POST, admin_user)
            referred_by      = _resolve_referred_by(request.POST, shop)

            customer = models.Customer(
                user=user_obj,
                shop=shop,
                created_by=admin_user,
                updated_by=admin_user,
                default_can_type=default_can_type,
                referred_by=referred_by,
            )
            _apply_fields(customer, fields)
            customer.save()

            if request.FILES.get('profile_photo'):
                customer.profile_photo = request.FILES['profile_photo']
                customer.save(update_fields=['profile_photo'])

            _process_can_assignments(request.POST, customer, admin_user)

            # Store raw credentials in session for one-time display
            try:
                request.session[f'customer_raw_credentials_{customer.id}'] = {
                    'username': user_obj.username,
                    'password': raw_password,
                }
                request.session.modified = True
            except Exception:
                pass

    except ValueError as ve:
        messages.error(request, str(ve))
        return redirect('customer_create')
    except Exception as e:
        messages.error(request, _('Failed to create customer: %(err)s') % {'err': str(e)})
        return redirect('customer_create')

    messages.success(request, _('Customer created successfully.'))
    return redirect('customer_edit', customer_id=customer.id)


# ─────────────────────────────────────────────────────────────────────────────
# EDIT
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
def customer_edit(request, customer_id):
    """Edit an existing Customer record (and its linked User account)."""
    admin_user, shop = _resolve_admin(request.user)

    try:
        customer = models.Customer.objects.get(id=customer_id, shop__admin=admin_user)
    except models.Customer.DoesNotExist:
        messages.error(request, _('Customer not found.'))
        return redirect('customers_list')

    can_types     = models.CanType.objects.filter(admin=admin_user, enabled=True)
    customer_cans = models.CustomerCanType.objects.filter(customer=customer).select_related('can_type')
    raw_credentials = request.session.pop(f'customer_raw_credentials_{customer.id}', None)

    if request.method != 'POST':
        all_customers = models.Customer.objects.filter(shop=shop, is_deleted=False).exclude(pk=customer.pk)
        return render(request, 'accounts/customer_form.html', {
            'customer':        customer,
            'customers':       models.Customer.objects.filter(shop__admin=admin_user),
            'can_types':       can_types,
            'customer_cans':   customer_cans,
            'raw_credentials': raw_credentials,
            'all_customers':   all_customers,
        })

    fields = _extract_customer_fields(request.POST)

    try:
        with transaction.atomic():
            # Update linked User
            if customer.user:
                u = customer.user
                u.first_name      = fields['first_name']
                u.last_name       = fields['last_name']
                u.email           = fields['email']
                u.whatsapp_number = fields['whatsapp_number']

                new_un = (request.POST.get('user_username') or '').strip()
                if new_un and new_un != u.username:
                    if models.User.objects.filter(username=new_un).exclude(pk=u.pk).exists():
                        messages.error(request, _('Username "%(u)s" is already taken.') % {'u': new_un})
                        return redirect('customer_edit', customer_id=customer.id)
                    u.username = new_un

                new_pw = (request.POST.get('user_password') or '').strip()
                if new_pw:
                    u.set_password(new_pw)
                    # Show the new password once after redirect
                    try:
                        request.session[f'customer_raw_credentials_{customer.id}'] = {
                            'username': u.username,
                            'password': new_pw,
                        }
                        request.session.modified = True
                    except Exception:
                        pass
                else:
                    # Auto-generate a password if account has none (first-time portal access)
                    if not u.has_usable_password():
                        from django.utils.crypto import get_random_string
                        gen_pw = get_random_string(10)
                        u.set_password(gen_pw)
                        try:
                            request.session[f'customer_raw_credentials_{customer.id}'] = {
                                'username': u.username,
                                'password': gen_pw,
                            }
                            request.session.modified = True
                        except Exception:
                            pass
                u.save()

            default_can_type = _resolve_default_can_type(
                request.POST, admin_user, current=customer.default_can_type
            )
            referred_by = _resolve_referred_by(
                request.POST, shop, current=customer.referred_by
            )

            _apply_fields(customer, fields)
            customer.default_can_type = default_can_type
            customer.referred_by      = referred_by
            customer.updated_by       = admin_user

            if request.FILES.get('profile_photo'):
                customer.profile_photo = request.FILES['profile_photo']

            customer.save()
            _process_can_assignments(request.POST, customer, admin_user)

    except Exception as e:
        messages.error(request, _('Failed to update customer: %(err)s') % {'err': str(e)})
        return redirect('customer_edit', customer_id=customer.id)

    messages.success(request, _('Customer updated successfully.'))
    return redirect('customer_edit', customer_id=customer.id)


# ─────────────────────────────────────────────────────────────────────────────
# SOFT DELETE  (replaces the old hard-delete customer_delete)
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
def customer_soft_delete(request, customer_id):
    """
    Archive (soft-delete) a customer.

    Preserved: Invoices, Payments, Deliveries, ReceivableLedger, CanTransactions.
    The linked User account is left intact but the customer becomes invisible
    in all normal queries because CustomerManager filters is_deleted=False.
    """
    if request.method != 'POST':
        messages.error(request, _('Invalid request method.'))
        return redirect('customers_list')

    admin_user, shop = _resolve_admin(request.user)

    try:
        customer = models.Customer.all_objects.get(id=customer_id, shop__admin=admin_user)
    except models.Customer.DoesNotExist:
        messages.error(request, _('Customer not found.'))
        return redirect('customers_list')

    if customer.is_deleted:
        messages.warning(
            request,
            _('Customer "%(name)s" is already archived.') % {'name': customer.display_name},
        )
        return redirect('customers_list')

    outstanding   = customer.outstanding_balance
    customer_name = customer.display_name
    customer.soft_delete()

    if outstanding and outstanding > 0:
        messages.warning(
            request,
            _(
                'Customer "%(name)s" archived. '
                'Outstanding balance of %(currency)s %(bal)s remains — '
                'all invoices and payment records are preserved.'
            ) % {'name': customer_name, 'bal': outstanding, 'currency': customer.shop.currency or 'PKR'},
        )
    else:
        messages.success(
            request,
            _(
                'Customer "%(name)s" archived successfully. '
                'All historical records are preserved.'
            ) % {'name': customer_name},
        )
    return redirect('customers_list')


# ─────────────────────────────────────────────────────────────────────────────
# HARD DELETE  (admin-panel only — requires explicit confirmation token)
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
def customer_hard_delete(request, customer_id):
    """
    Permanently delete a customer record.
    Only accessible when the request includes confirm=DELETE_CONFIRMED in POST.
    Will refuse if the customer has Invoices, Payments, or Deliveries.
    """
    if request.method != 'POST':
        messages.error(request, _('Invalid request method.'))
        return redirect('customers_list')

    if request.POST.get('confirm') != 'DELETE_CONFIRMED':
        messages.error(request, _('Confirmation required to permanently delete a customer.'))
        return redirect('customers_list')

    admin_user, shop = _resolve_admin(request.user)

    try:
        customer = models.Customer.all_objects.get(id=customer_id, shop__admin=admin_user)
    except models.Customer.DoesNotExist:
        messages.error(request, _('Customer not found.'))
        return redirect('customers_list')

    # Safety: block deletion if financial records exist
    has_invoices  = models.Invoice.objects.filter(customer=customer).exists()
    has_payments  = models.Payment.objects.filter(payer_customer=customer).exists()
    has_deliveries = models.DailyDelivery.objects.filter(customer=customer).exists()

    if has_invoices or has_payments or has_deliveries:
        messages.error(
            request,
            _(
                'Cannot permanently delete "%(name)s": financial records exist. '
                'Use the archive (soft-delete) option instead.'
            ) % {'name': customer.display_name},
        )
        return redirect('customers_list')

    name = customer.display_name
    try:
        if customer.user:
            customer.user.delete()
    except Exception:
        pass
    customer.delete()

    messages.success(request, _('Customer "%(name)s" permanently deleted.') % {'name': name})
    return redirect('customers_list')