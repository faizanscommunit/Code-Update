# ─────────────────────────────────────────────────────────────────────────────
# accounts/assigned_delivery_views.py
# Paste these imports at the top of this file (they are already in views.py,
# but this file is self-contained for clarity).
# ─────────────────────────────────────────────────────────────────────────────

import math
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from django.contrib import messages
from django.utils import timezone
from django.db.models import Q
from decimal import Decimal

from accounts import models
from accounts.decorators import shop_admin_required, role_required


# ── Distance helper (Haversine, returns km) ───────────────────────────────────

def _haversine(lat1, lon1, lat2, lon2):
    R = 6371
    phi1, phi2 = math.radians(float(lat1)), math.radians(float(lat2))
    dphi = math.radians(float(lat2) - float(lat1))
    dlam = math.radians(float(lon2) - float(lon1))
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlam/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))


def _resolve_admin(request):
    """Return the admin user regardless of whether caller is admin or staff."""
    if getattr(request.user, 'role', None) == 'staff':
        st = models.Staff.objects.filter(user=request.user).select_related('admin').first()
        return st.admin if st else request.user
    return request.user


# ═════════════════════════════════════════════════════════════════════════════
# ADMIN VIEWS
# ═════════════════════════════════════════════════════════════════════════════

@shop_admin_required
def assigned_delivery_list(request):
    """
    Admin: list all assigned deliveries with filters.
    """
    user = request.user
    qs = models.AssignedDelivery.objects.filter(admin=user).select_related(
        'staff', 'customer', 'can_type', 'resulting_delivery'
    )

    # Filters
    date_filter  = request.GET.get('date')  or str(timezone.now().date())
    staff_filter = request.GET.get('staff') or ''
    status_filter= request.GET.get('status') or ''

    if date_filter:
        try:
            qs = qs.filter(delivery_date=date_filter)
        except Exception:
            pass
    if staff_filter:
        qs = qs.filter(staff_id=staff_filter)
    if status_filter:
        qs = qs.filter(status=status_filter)

    staff_list   = models.Staff.objects.filter(admin=user)
    total        = qs.count()
    done_count   = qs.filter(status='done').count()
    pending_count= qs.filter(status='pending').count()
    failed_count = qs.filter(status='failed').count()

    return render(request, 'accounts/assigned_deliveries.html', {
        'assignments':    qs,
        'staff_list':     staff_list,
        'total':          total,
        'done_count':     done_count,
        'pending_count':  pending_count,
        'failed_count':   failed_count,
        'filters': {
            'date':   date_filter,
            'staff':  staff_filter,
            'status': status_filter,
        },
        'status_choices': models.AssignedDelivery.STATUS_CHOICES,
    })


@shop_admin_required
def assigned_delivery_create(request):
    """
    Admin: form to assign a delivery to a rider.
    """
    user      = request.user
    customers = models.Customer.objects.filter(shop__admin=user, is_active=True)
    staff_qs  = models.Staff.objects.filter(admin=user)
    can_types = models.CanType.objects.filter(admin=user, enabled=True)

    if request.method == 'POST':
        is_ajax = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

        def err(msg):
            if is_ajax:
                return JsonResponse({'ok': False, 'message': str(msg)}, status=400)
            messages.error(request, str(msg))
            return redirect('assigned_delivery_create')

        def ok(msg):
            if is_ajax:
                return JsonResponse({'ok': True, 'message': str(msg)})
            messages.success(request, str(msg))
            return redirect('assigned_deliveries_list')

        customer_id  = request.POST.get('customer_id')
        staff_id     = request.POST.get('staff_id')
        can_type_id  = request.POST.get('can_type')
        quantity_raw = request.POST.get('quantity')
        date_raw     = request.POST.get('delivery_date') or str(timezone.now().date())
        notes        = request.POST.get('notes', '').strip()

        if not (customer_id and staff_id and can_type_id and quantity_raw):
            return err('Please fill in all required fields.')

        try:
            customer = models.Customer.objects.get(id=customer_id, shop__admin=user, is_active=True)
        except models.Customer.DoesNotExist:
            return err('Invalid customer.')

        try:
            staff = models.Staff.objects.get(id=staff_id, admin=user)
        except models.Staff.DoesNotExist:
            return err('Invalid staff member.')

        try:
            can_type = models.CanType.objects.get(id=can_type_id, admin=user, enabled=True)
        except models.CanType.DoesNotExist:
            return err('Invalid can type.')

        try:
            qty = int(quantity_raw)
            if qty < 1:
                raise ValueError()
        except Exception:
            return err('Quantity must be a positive whole number.')

        try:
            delivery_date = timezone.datetime.fromisoformat(date_raw).date()
        except Exception:
            delivery_date = timezone.now().date()

        # Resolve rate: customer-specific price → can type price
        rate = can_type.price
        try:
            cct = models.CustomerCanType.objects.get(customer=customer, can_type=can_type)
            rate = cct.price
        except models.CustomerCanType.DoesNotExist:
            pass
        # customer flat override
        if customer.price_per_can:
            rate = customer.price_per_can

        models.AssignedDelivery.objects.create(
            admin=user,
            shop=getattr(user, 'shop_admin', getattr(user, 'shop', None)),
            staff=staff,
            customer=customer,
            can_type=can_type,
            quantity_to_deliver=qty,
            rate_given=rate,
            delivery_date=delivery_date,
            notes=notes,
            status='pending',
        )

        return ok(f'Delivery assigned to {staff.first_name} for {customer.display_name}.')

    # Build customer→can_type map for JS
    customer_can_map = {}
    for c in customers:
        entries = []
        for ce in models.CustomerCanType.objects.filter(customer=c, can_type__enabled=True):
            entries.append({'id': ce.can_type.id, 'name': str(ce.can_type), 'price': str(ce.price)})
        customer_can_map[c.id] = entries

    return render(request, 'accounts/assign_delivery_form.html', {
        'customers':       customers,
        'staff_list':      staff_qs,
        'can_types':       can_types,
        'today':           timezone.now().date(),
        'customer_can_map': customer_can_map,
    })


@shop_admin_required
@require_POST
def assigned_delivery_delete(request, pk):
    ad = get_object_or_404(models.AssignedDelivery, pk=pk, admin=request.user)
    if ad.status == 'done':
        messages.error(request, 'Cannot delete a completed assignment.')
        return redirect('assigned_deliveries_list')
    ad.delete()
    messages.success(request, 'Assignment deleted.')
    return redirect('assigned_deliveries_list')


@shop_admin_required
@require_POST
def assigned_delivery_reassign(request, pk):
    """Admin can reassign a pending assignment to a different rider."""
    ad       = get_object_or_404(models.AssignedDelivery, pk=pk, admin=request.user)
    staff_id = request.POST.get('staff_id')
    if ad.status == 'done':
        messages.error(request, 'Cannot reassign a completed delivery.')
        return redirect('assigned_deliveries_list')
    try:
        new_staff = models.Staff.objects.get(id=staff_id, admin=request.user)
        ad.staff = new_staff
        ad.save(update_fields=['staff', 'updated_at'])
        messages.success(request, f'Reassigned to {new_staff.first_name}.')
    except Exception:
        messages.error(request, 'Invalid staff selected.')
    return redirect('assigned_deliveries_list')


# ═════════════════════════════════════════════════════════════════════════════
# STAFF / RIDER VIEWS
# ═════════════════════════════════════════════════════════════════════════════

@role_required(allowed_roles=['staff'])
def staff_assigned_dashboard(request):
    """
    Rider dashboard: shows today's assigned deliveries.
    Deliveries are sorted by nearest GPS location if rider's lat/lng available
    (passed as query params ?lat=xx&lng=xx from GPS snippet), otherwise by
    sort_order then id.
    """
    me = models.Staff.objects.filter(user=request.user).select_related('admin').first()
    if not me:
        return redirect('login')
    if me.is_blocked:
        messages.error(request, 'Your account is blocked. Contact admin.')
        return redirect('login')

    today = timezone.now().date()

    # Today's assignments for this rider
    qs = models.AssignedDelivery.objects.filter(
        staff=me,
        delivery_date=today,
    ).select_related('customer', 'can_type', 'resulting_delivery').order_by('sort_order', 'id')

    assignments = list(qs)

    # GPS-based nearest-next sorting
    rider_lat = request.GET.get('lat')
    rider_lng = request.GET.get('lng')

    if rider_lat and rider_lng:
        try:
            rlat = float(rider_lat)
            rlng = float(rider_lng)

            def dist_key(ad):
                clat = ad.customer.latitude
                clng = ad.customer.longitude
                if clat and clng:
                    return _haversine(rlat, rlng, clat, clng)
                return 9999  # no GPS → put at end

            pending = [a for a in assignments if a.status != 'done']
            done    = [a for a in assignments if a.status == 'done']
            pending.sort(key=dist_key)
            assignments = pending + done

        except Exception:
            pass  # fall back to default order

    # Stats for the day
    total   = len(assignments)
    done_c  = sum(1 for a in assignments if a.status == 'done')
    pending_c = sum(1 for a in assignments if a.status == 'pending')
    failed_c  = sum(1 for a in assignments if a.status == 'failed')

    # Next delivery (first pending)
    next_delivery = next((a for a in assignments if a.status == 'pending'), None)

    return render(request, 'accounts/staff_delivery_dashboard.html', {
        'me':           me,
        'assignments':  assignments,
        'today':        today,
        'total':        total,
        'done_count':   done_c,
        'pending_count':pending_c,
        'failed_count': failed_c,
        'next_delivery':next_delivery,
    })


@role_required(allowed_roles=['staff'])
@require_POST
def staff_mark_done(request, pk):
    """
    Rider marks an assigned delivery as done.
    Auto-creates the DailyDelivery record.
    """
    me = models.Staff.objects.filter(user=request.user).first()
    if not me:
        return JsonResponse({'ok': False, 'message': 'Staff record not found'}, status=403)

    ad = get_object_or_404(models.AssignedDelivery, pk=pk, staff=me)

    if ad.status == 'done':
        return JsonResponse({'ok': True, 'message': 'Already marked done', 'already_done': True})

    empty_cans = 0
    try:
        empty_cans = int(request.POST.get('empty_cans', 0) or 0)
    except Exception:
        pass

    is_ajax = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

    try:
        ad.mark_done(empty_cans_received=empty_cans)
    except Exception as e:
        if is_ajax:
            return JsonResponse({'ok': False, 'message': str(e)}, status=400)
        messages.error(request, str(e))
        return redirect('staff_delivery_dashboard')

    if is_ajax:
        return JsonResponse({
            'ok':      True,
            'message': f'Delivery for {ad.customer.display_name} marked done.',
            'done_count': models.AssignedDelivery.objects.filter(
                staff=me,
                delivery_date=ad.delivery_date,
                status='done'
            ).count(),
        })
    messages.success(request, f'Delivery for {ad.customer.display_name} marked done.')
    return redirect('staff_delivery_dashboard')


@role_required(allowed_roles=['staff'])
@require_POST
def staff_mark_failed(request, pk):
    """Rider marks a delivery as failed (not delivered)."""
    me = models.Staff.objects.filter(user=request.user).first()
    if not me:
        return JsonResponse({'ok': False, 'message': 'Staff record not found'}, status=403)

    ad     = get_object_or_404(models.AssignedDelivery, pk=pk, staff=me)
    reason = request.POST.get('reason', '').strip() or 'Customer not available'
    is_ajax = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

    if ad.status in ('done', 'failed'):
        if is_ajax:
            return JsonResponse({'ok': False, 'message': f'Already {ad.status}'})
        messages.error(request, f'Already {ad.status}.')
        return redirect('staff_delivery_dashboard')

    ad.mark_failed(reason=reason)

    if is_ajax:
        return JsonResponse({'ok': True, 'message': 'Marked as failed / not delivered.'})
    messages.warning(request, 'Delivery marked as not delivered.')
    return redirect('staff_delivery_dashboard')


@login_required
def assigned_delivery_api_today(request):
    """
    JSON endpoint: returns today's assignments for the calling rider.
    Used by the GPS snippet for nearest-next sorting.
    """
    me = models.Staff.objects.filter(user=request.user).first()
    if not me:
        return JsonResponse({'ok': False}, status=403)

    today = timezone.now().date()
    qs = models.AssignedDelivery.objects.filter(
        staff=me, delivery_date=today
    ).select_related('customer', 'can_type')

    data = []
    for ad in qs:
        data.append({
            'id':         ad.id,
            'status':     ad.status,
            'customer':   ad.customer.display_name,
            'address':    ad.customer.full_address,
            'lat':        float(ad.customer.latitude)  if ad.customer.latitude  else None,
            'lng':        float(ad.customer.longitude) if ad.customer.longitude else None,
            'quantity':   ad.quantity_to_deliver,
            'can_type':   str(ad.can_type),
            'notes':      ad.notes or '',
            'done_at':    ad.completed_at.isoformat() if ad.completed_at else None,
        })

    return JsonResponse({'ok': True, 'assignments': data, 'date': str(today)})