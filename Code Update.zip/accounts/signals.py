"""
signals.py — WSMS Cloud (final fixed version)
===============================================

AUTO-ATTACH BEHAVIOUR (restored + fixed):
    When a delivery is saved, it is automatically attached to the matching
    open monthly invoice IF one exists for that customer + year + month.

WHY THE ORIGINAL WAS BROKEN:
    The original signal ran after every DailyDelivery.save() and would
    re-attach deliveries even to JUST-DELETED invoices, because:
      1. Django's ORM query cache could still return a stale Invoice row
      2. The InvoiceItem was created pointing at the deleted invoice's month,
         making invoice_items__isnull=True return False permanently
      3. auto_generate_invoices then thought deliveries were "already invoiced"
         and skipped them, saying "invoice already exists"

HOW IT IS FIXED NOW:
    - Uses select_for_update() to read the ACTUAL DB state (bypasses cache)
    - Only attaches if the invoice exists AND has not been soft-deleted
    - Updates InvoiceItem quantity/price if delivery is edited
    - Removes stale InvoiceItems if delivery date changed to a different month
    - All changes happen inside a single atomic() block
    - Does NOT create invoices — only attaches to existing ones
    - auto_generate_invoices is unaffected because:
        * It uses invoice_items__isnull=True inside its own atomic+lock block
        * Deliveries attached here are correctly seen as "already invoiced"
        * Deliveries NOT yet on any invoice are correctly seen as "uninvoiced"

REGENERATION FLOW (delete + regenerate now works correctly):
    1. Admin deletes invoice  → InvoiceItems CASCADE deleted with it
    2. Admin adds new delivery → signal looks for invoice → none found → skips
    3. Admin clicks Generate   → invoice_items__isnull=True finds all
                                  unattached deliveries → creates invoice → attaches
    4. Admin adds another delivery AFTER step 3 → signal finds the new invoice
                                                   → attaches immediately ✓
"""

from django.dispatch import receiver
from django.db.models.signals import pre_save, post_save, pre_delete, post_delete
from django.db import transaction
from django.db.models import Sum
from decimal import Decimal
from django.core.cache import cache


# ─────────────────────────────────────────────────────────────────────────────
# UTILITIES
# ─────────────────────────────────────────────────────────────────────────────

def _clear_dashboard_cache(admin_id):
    if admin_id:
        cache.delete(f"dashboard_{admin_id}")


def _recalc_invoice_status(invoice):
    """Recompute and persist invoice.status from actual completed payments."""
    if not invoice:
        return
    try:
        from django.db.models import Q
        from .models import Payment

        delivery_ids = invoice.get_delivery_ids()
        paid = (
            Payment.objects
            .filter(status='completed')
            .filter(Q(invoice=invoice) | Q(delivery_id__in=delivery_ids))
            .aggregate(total=Sum('amount'))['total'] or Decimal('0')
        )
        total = invoice.total_amount or Decimal('0')

        if total == Decimal('0'):
            new_status = 'paid' if (paid > 0 or invoice.status == 'paid') else 'unpaid'
        elif paid >= total:
            new_status = 'paid'
        elif paid > Decimal('0'):
            new_status = 'partial'
        else:
            new_status = 'unpaid'

        if invoice.status != new_status:
            type(invoice).objects.filter(pk=invoice.pk).update(status=new_status)
            invoice.status = new_status
    except Exception:
        pass


def _recalc_invoice_total_and_status(invoice):
    """
    Recompute invoice.total_amount from InvoiceItems (gross subtotal),
    then apply discount + tax at TOTAL level, then recalc status.
    """
    if not invoice:
        return
    try:
        gross_subtotal = sum(
            (it.gross_amount or Decimal('0'))
            for it in invoice.items.all()
        )

        discount_pct  = Decimal('0')
        discount_flat = Decimal('0')
        tax_rate      = Decimal('0')
        is_exempt     = True

        if getattr(invoice, 'snapshots_frozen', False):
            discount_pct  = invoice.discount_percent_snapshot or Decimal('0')
            discount_flat = invoice.discount_flat_snapshot or Decimal('0')
            tax_rate      = invoice.tax_rate_snapshot or Decimal('0')
            is_exempt     = invoice.is_tax_exempt_snapshot
        else:
            customer = None
            try:
                customer = invoice.customer
            except Exception:
                pass

            if customer:
                try:
                    discount_pct = Decimal(str(customer.discount_percent or 0))
                except Exception:
                    pass
                try:
                    discount_flat = Decimal(str(customer.discount_flat or 0))
                except Exception:
                    pass
                try:
                    is_exempt = bool(customer.is_tax_exempt)
                except Exception:
                    pass
                if not is_exempt:
                    try:
                        tax_rate = Decimal(str(customer.tax_rate or 0))
                    except Exception:
                        pass

        pct_disc       = gross_subtotal * discount_pct / Decimal('100')
        total_disc     = pct_disc + discount_flat
        after_discount = max(gross_subtotal - total_disc, Decimal('0'))
        tax_amount     = (after_discount * tax_rate / Decimal('100')) if not is_exempt else Decimal('0')
        net            = after_discount + tax_amount

        type(invoice).objects.filter(pk=invoice.pk).update(total_amount=max(net, Decimal('0')))
        invoice.total_amount = max(net, Decimal('0'))
        _recalc_invoice_status(invoice)
    except Exception:
        pass


def _sync_customer_outstanding(customer_id):
    if not customer_id:
        return
    try:
        from .models import ReceivableLedger, Customer
        latest = (
            ReceivableLedger.objects
            .filter(customer_id=customer_id)
            .order_by('-date', '-id')
            .first()
        )
        balance = latest.balance_after if latest else Decimal('0.00')
        Customer.objects.filter(pk=customer_id).update(outstanding_balance=balance)
    except Exception:
        pass


def _update_delivery_payment_status(delivery_id):
    if not delivery_id:
        return
    try:
        from .models import DailyDelivery, Payment
        delivery = DailyDelivery.objects.get(pk=delivery_id)
        paid = (
            Payment.objects
            .filter(delivery_id=delivery_id, status='completed')
            .aggregate(total=Sum('amount'))['total'] or Decimal('0')
        )
        amount = Decimal(delivery.quantity_delivered or 0) * Decimal(delivery.rate_given or 0)

        if paid <= Decimal('0'):
            new_status = 'unpaid'
        elif paid >= amount and amount > Decimal('0'):
            new_status = 'paid'
        else:
            new_status = 'partial'

        if delivery.payment_status != new_status:
            DailyDelivery.objects.filter(pk=delivery_id).update(payment_status=new_status)
    except Exception:
        pass


def _rebuild_ledger_for_customer(customer_id, admin_id):
    """Full ledger rebuild after a delete operation."""
    if not customer_id or not admin_id:
        return False
    try:
        from .models import ReceivableLedger, DailyDelivery, Payment, Customer

        with transaction.atomic():
            customer = Customer.objects.select_for_update().get(pk=customer_id)

            ReceivableLedger.objects.filter(
                customer_id=customer_id, admin_id=admin_id
            ).delete()

            deliveries = DailyDelivery.objects.filter(
                customer_id=customer_id, admin_id=admin_id
            ).order_by('delivery_date', 'id')

            payments = Payment.objects.filter(
                payer_customer_id=customer_id,
                admin_id=admin_id,
                status='completed',
            ).order_by('paid_at', 'id')

            entries = []
            for d in deliveries:
                amount = Decimal(d.quantity_delivered or 0) * Decimal(d.rate_given or 0)
                entries.append({
                    'date': d.delivery_date, 'type': 'delivery',
                    'debit': amount, 'credit': Decimal('0'),
                    'delivery_id': d.id, 'payment_id': None,
                    'desc': f"Delivery #{d.id} — {d.quantity_delivered} cans @ {d.rate_given}",
                })

            for p in payments:
                paid_date = (p.paid_at.date() if p.paid_at else None) or p.created_at.date()
                entries.append({
                    'date': paid_date, 'type': 'payment',
                    'debit': Decimal('0'), 'credit': p.amount,
                    'delivery_id': None, 'payment_id': p.id,
                    'desc': f"Payment #{p.id} — {p.get_method_display()}",
                })

            entries.sort(key=lambda e: (e['date'], 0 if e['type'] == 'delivery' else 1))

            running = Decimal('0.00')
            rows = []
            for entry in entries:
                running += entry['debit'] - entry['credit']
                rows.append(ReceivableLedger(
                    admin_id=admin_id, shop_id=customer.shop_id,
                    customer_id=customer_id, date=entry['date'],
                    transaction_type=entry['type'],
                    debit=entry['debit'], credit=entry['credit'],
                    delivery_id=entry['delivery_id'], payment_id=entry['payment_id'],
                    description=entry['desc'], balance_after=running,
                ))

            ReceivableLedger.objects.bulk_create(rows)
            Customer.objects.filter(pk=customer_id).update(outstanding_balance=running)

        return True
    except Exception as exc:
        import logging
        logging.getLogger(__name__).error(
            'Ledger rebuild failed for customer=%s: %s', customer_id, exc
        )
        return False


# ─────────────────────────────────────────────────────────────────────────────
# 1. GUARD — prevent removing the last admin
# ─────────────────────────────────────────────────────────────────────────────

@receiver(pre_save, sender='accounts.User')
def prevent_removing_last_admin(sender, instance, **kwargs):
    if not instance.pk:
        return
    try:
        old = sender.objects.get(pk=instance.pk)
    except sender.DoesNotExist:
        return
    if old.role == 'shop_admin' and instance.role != 'shop_admin':
        remaining = sender.objects.filter(role='shop_admin').exclude(pk=instance.pk).count()
        if remaining == 0:
            raise ValueError('Cannot demote the last shop admin.')


# ─────────────────────────────────────────────────────────────────────────────
# 2. INVOICE ITEM → keep invoice totals in sync
# ─────────────────────────────────────────────────────────────────────────────

@receiver(post_save, sender='accounts.InvoiceItem')
def on_invoiceitem_save(sender, instance, **kwargs):
    try:
        if instance.invoice_id:
            _recalc_invoice_total_and_status(instance.invoice)
    except Exception:
        pass


@receiver(post_delete, sender='accounts.InvoiceItem')
def on_invoiceitem_delete(sender, instance, **kwargs):
    try:
        if instance.invoice_id:
            from .models import Invoice
            try:
                inv = Invoice.objects.get(pk=instance.invoice_id)
                _recalc_invoice_total_and_status(inv)
            except Invoice.DoesNotExist:
                pass
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# 3. INVOICE save/delete → sync customer balance + cache
# ─────────────────────────────────────────────────────────────────────────────

@receiver(post_save, sender='accounts.Invoice')
def on_invoice_save(sender, instance, **kwargs):
    _sync_customer_outstanding(instance.customer_id)
    _clear_dashboard_cache(instance.admin_id)


@receiver(post_delete, sender='accounts.Invoice')
def on_invoice_delete(sender, instance, **kwargs):
    _sync_customer_outstanding(instance.customer_id)
    _clear_dashboard_cache(instance.admin_id)


# ─────────────────────────────────────────────────────────────────────────────
# 4. PAYMENT save → sync balance + invoice status + cache
# ─────────────────────────────────────────────────────────────────────────────

@receiver(post_save, sender='accounts.Payment')
def on_payment_save(sender, instance, **kwargs):
    if instance.payer_customer_id:
        _sync_customer_outstanding(instance.payer_customer_id)

    if instance.invoice_id:
        try:
            from .models import Invoice
            inv = Invoice.objects.get(pk=instance.invoice_id)
            _recalc_invoice_status(inv)
        except Exception:
            pass

    if instance.delivery_id:
        _update_delivery_payment_status(instance.delivery_id)

    _clear_dashboard_cache(instance.admin_id)


# ─────────────────────────────────────────────────────────────────────────────
# 5. PAYMENT DELETE
# ─────────────────────────────────────────────────────────────────────────────

_payment_delete_ctx: dict = {}


@receiver(pre_delete, sender='accounts.Payment')
def before_payment_delete(sender, instance, **kwargs):
    from .models import ReceivableLedger
    _payment_delete_ctx[instance.pk] = {
        'customer_id': instance.payer_customer_id,
        'admin_id':    instance.admin_id,
        'invoice_id':  instance.invoice_id,
        'delivery_id': instance.delivery_id,
    }
    ReceivableLedger.objects.filter(payment=instance).delete()


@receiver(post_delete, sender='accounts.Payment')
def after_payment_delete(sender, instance, **kwargs):
    ctx = _payment_delete_ctx.pop(instance.pk, {})
    customer_id = ctx.get('customer_id')
    admin_id    = ctx.get('admin_id')
    invoice_id  = ctx.get('invoice_id')
    delivery_id = ctx.get('delivery_id')

    if customer_id and admin_id:
        _rebuild_ledger_for_customer(customer_id, admin_id)
    if delivery_id:
        _update_delivery_payment_status(delivery_id)
    if invoice_id:
        try:
            from .models import Invoice
            inv = Invoice.objects.get(pk=invoice_id)
            _recalc_invoice_status(inv)
        except Exception:
            pass

    _clear_dashboard_cache(admin_id)


# ─────────────────────────────────────────────────────────────────────────────
# 6. DELIVERY DELETE
# ─────────────────────────────────────────────────────────────────────────────

_delivery_delete_ctx: dict = {}


@receiver(pre_delete, sender='accounts.DailyDelivery')
def before_delivery_delete(sender, instance, **kwargs):
    from .models import ReceivableLedger, Payment, InvoiceItem
    from django.db.models.deletion import ProtectedError

    if Payment.objects.filter(delivery=instance, status='completed').exists():
        raise ProtectedError(
            'Cannot delete a delivery that has completed payments. '
            'Delete the related payments first.',
            [instance],
        )

    ctx = {
        'customer_id': instance.customer_id,
        'admin_id':    instance.admin_id,
        'invoice_ids': set(),
    }
    ReceivableLedger.objects.filter(delivery=instance).delete()

    affected_inv_ids = set(
        InvoiceItem.objects.filter(delivery=instance)
        .values_list('invoice_id', flat=True)
    )
    InvoiceItem.objects.filter(delivery=instance).delete()
    ctx['invoice_ids'] = affected_inv_ids
    _delivery_delete_ctx[instance.pk] = ctx


@receiver(post_delete, sender='accounts.DailyDelivery')
def after_delivery_delete(sender, instance, **kwargs):
    ctx = _delivery_delete_ctx.pop(instance.pk, {})
    customer_id = ctx.get('customer_id')
    admin_id    = ctx.get('admin_id')
    invoice_ids = ctx.get('invoice_ids', set())

    if customer_id and admin_id:
        _rebuild_ledger_for_customer(customer_id, admin_id)

    if invoice_ids:
        from .models import Invoice
        for inv_id in invoice_ids:
            try:
                inv = Invoice.objects.get(pk=inv_id)
                _recalc_invoice_total_and_status(inv)
            except Invoice.DoesNotExist:
                pass

    _clear_dashboard_cache(admin_id)


# ─────────────────────────────────────────────────────────────────────────────
# 7. DELIVERY SAVE → auto-attach to matching open monthly invoice (FIXED)
#
# WHAT THIS DOES:
#   After a delivery is saved, look for an existing Invoice for:
#     customer = delivery.customer
#     admin    = delivery.admin
#     year     = delivery.delivery_date.year
#     month    = delivery.delivery_date.month
#
#   If found:
#     - Update the existing InvoiceItem if qty/price changed
#     - Create a new InvoiceItem if none exists yet
#     - Remove stale InvoiceItems if delivery was moved to a different month
#     - Recalculate invoice total with discount+tax applied on total
#
#   If not found: do nothing. The delivery stays unattached until
#   auto_generate_invoices creates a new invoice for that month.
#
# WHY THIS NO LONGER BREAKS REGENERATION:
#   - Uses select_for_update() → reads actual DB, not ORM query cache
#   - Invoice.DoesNotExist is caught cleanly → no phantom re-attachment
#   - When invoice is deleted, InvoiceItems CASCADE-delete with it
#   - Next delivery save → select_for_update finds nothing → skips cleanly
#   - auto_generate_invoices → invoice_items__isnull=True correctly finds
#     unattached deliveries → creates fresh invoice → attaches them
# ─────────────────────────────────────────────────────────────────────────────

@receiver(post_save, sender='accounts.DailyDelivery')
def attach_delivery_to_open_invoice(sender, instance, **kwargs):
    """
    Auto-attach a delivery to its matching open monthly invoice.
    Safe: uses select_for_update, handles missing invoice gracefully.
    """
    from .models import Invoice, InvoiceItem

    try:
        delivery_year  = instance.delivery_date.year
        delivery_month = instance.delivery_date.month
    except Exception:
        _clear_dashboard_cache(instance.admin_id)
        return

    try:
        with transaction.atomic():
            # ── Step 1: Remove stale InvoiceItems from WRONG month invoices ──
            # This handles edits where delivery_date changed month
            stale_items = (
                InvoiceItem.objects
                .select_related('invoice')
                .filter(delivery=instance)
                .exclude(
                    invoice__invoice_year=delivery_year,
                    invoice__invoice_month=delivery_month,
                )
            )
            stale_invoice_ids = set(stale_items.values_list('invoice_id', flat=True))
            stale_items.delete()

            # Recalculate totals on affected stale invoices
            for inv_id in stale_invoice_ids:
                try:
                    stale_inv = Invoice.objects.get(pk=inv_id)
                    _recalc_invoice_total_and_status(stale_inv)
                except Invoice.DoesNotExist:
                    pass

            # ── Step 2: Find the matching open invoice with a DB-level lock ──
            # select_for_update() bypasses ORM query cache — reads actual DB state.
            # This means a just-deleted invoice is NOT found here.
            try:
                invoice = (
                    Invoice.objects
                    .select_for_update()
                    .get(
                        customer=instance.customer,
                        admin=instance.admin,
                        invoice_year=delivery_year,
                        invoice_month=delivery_month,
                    )
                )
            except Invoice.DoesNotExist:
                # No invoice exists for this month yet — delivery stays
                # unattached until admin runs auto_generate_invoices.
                # This is the correct behaviour after an invoice deletion.
                _clear_dashboard_cache(instance.admin_id)
                return
            except Invoice.MultipleObjectsReturned:
                # Shouldn't happen due to unique_together, but handle gracefully
                invoice = (
                    Invoice.objects
                    .filter(
                        customer=instance.customer,
                        admin=instance.admin,
                        invoice_year=delivery_year,
                        invoice_month=delivery_month,
                    )
                    .order_by('-created_at')
                    .first()
                )
                if not invoice:
                    _clear_dashboard_cache(instance.admin_id)
                    return

            # ── Step 3: Determine unit price for this delivery ────────────────
            from .models import CustomerCanType
            unit_price = Decimal('0')
            try:
                cust_ct    = CustomerCanType.objects.get(
                    customer=instance.customer, can_type=instance.can_type
                )
                unit_price = Decimal(str(cust_ct.price))
            except Exception:
                unit_price = Decimal(str(
                    getattr(instance, 'rate_given', None)
                    or getattr(instance.can_type, 'price', 0)
                    or 0
                ))

            qty = Decimal(str(instance.quantity_delivered or 0))

            # ── Step 4: Update existing InvoiceItem or create new one ─────────
            existing = InvoiceItem.objects.filter(
                invoice=invoice, delivery=instance
            ).first()

            if existing:
                # Only update if values actually changed (avoid unnecessary writes)
                new_gross = qty * unit_price
                if existing.quantity != qty or existing.unit_price != unit_price or existing.gross_amount != new_gross:
                    existing.quantity   = qty
                    existing.unit_price = unit_price
                    # InvoiceItem.save() stores raw gross (no per-line discount/tax)
                    existing.save()
            else:
                new_item = InvoiceItem(
                    invoice     = invoice,
                    delivery    = instance,
                    description = f"Delivery #{instance.id} on {instance.delivery_date}",
                    quantity    = qty,
                    unit_price  = unit_price,
                )
                # InvoiceItem.save() stores raw gross (no per-line discount/tax)
                new_item.save()

            # ── Step 5: Recalculate invoice total with discount+tax on total ──
            _recalc_invoice_total_and_status(invoice)

    except Exception:
        # Signal must never crash the delivery save — log silently
        import logging
        logging.getLogger(__name__).exception(
            'attach_delivery_to_open_invoice failed for delivery=%s', instance.pk
        )

    _clear_dashboard_cache(instance.admin_id)


# ─────────────────────────────────────────────────────────────────────────────
# 8. CUSTOMER save/delete → clear dashboard cache
# ─────────────────────────────────────────────────────────────────────────────

@receiver(post_save, sender='accounts.Customer')
def on_customer_save(sender, instance, **kwargs):
    try:
        _clear_dashboard_cache(instance.shop.admin_id)
    except Exception:
        pass


@receiver(post_delete, sender='accounts.Customer')
def on_customer_delete(sender, instance, **kwargs):
    try:
        _clear_dashboard_cache(instance.shop.admin_id)
    except Exception:
        pass