from django.test import TestCase, Client
from django.urls import reverse
from .models import User, Customer, CanType, DailyDelivery

class DeliveriesListViewTest(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_user(username='shopowner', password='pass', role='shop_admin')
        self.client = Client()
        self.client.login(username='shopowner', password='pass')

        self.customer = Customer.objects.create(admin=self.admin_user, shop=getattr(self.admin_user, 'shop', None) or None, first_name='Test', last_name='Cust', email='t@example.com', phone_number='0300', whatsapp_number='0300', address='Addr')
        self.ct = CanType.objects.create(admin=self.admin_user, can_type='Small', price=10)
        self.dd = DailyDelivery.objects.create(admin=self.admin_user, customer=self.customer, can_type=self.ct, quantity_delivered=3, rate_given=10)

    def test_deliveries_list_visible_in_sidebar(self):
        resp = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, reverse('deliveries_list'))

    def test_deliveries_list_view(self):
        resp = self.client.get(reverse('deliveries_list'))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, 'Deliveries')
        self.assertContains(resp, str(self.dd.id))
