# ── accounts/profit_loss_view.py  (IFRS IAS 1 – Statement of Profit or Loss) ──

import datetime
import json
from decimal import Decimal

from django.contrib.auth.decorators import login_required
from django.db.models import Count, OuterRef, Q, Subquery, Sum
from django.db.models.functions import TruncMonth
from django.shortcuts import render
from django.utils import timezone

from .models import (
    Customer,
    DailyDelivery,
    Expense,
    Payment,
    ReceivableLedger,
    Staff,
)

# ── Category classification ───────────────────────────────────────────────────
_COGS_KEYWORDS    = {"cost of sales", "cogs", "direct cost", "purchase", "cost of goods"}
_FINANCE_KEYWORDS = {"finance", "interest", "bank charge", "bank fee", "loan"}
_TAX_KEYWORDS     = {"income tax", "corporate tax", "tax", "withholding tax"}


def _classify(category_name: str) -> str:
    """Return 'cogs' | 'finance' | 'tax' | 'opex'."""
    if not category_name:
        return "opex"
    n = category_name.strip().lower()
    if any(k in n for k in _COGS_KEYWORDS):
        return "cogs"
    if any(k in n for k in _FINANCE_KEYWORDS):
        return "finance"
    if any(k in n for k in _TAX_KEYWORDS):
        return "tax"
    return "opex"


def _get_admin(request):
    user = request.user
    if hasattr(user, "role") and user.role == "staff":
        try:
            return Staff.objects.get(user=user).admin
        except Staff.DoesNotExist:
            pass
    return user


# ── Canonical receivable helper ───────────────────────────────────────────────

def _get_total_receivable(admin) -> Decimal:
    """
    Sum of the latest ReceivableLedger.balance_after per customer.
    Matches the admin dashboard KPI exactly.
    """
    latest_ledger_sq = (
        ReceivableLedger.objects
        .filter(customer=OuterRef("pk"), admin=admin)
        .order_by("-date", "-id")
        .values("balance_after")[:1]
    )
    result = (
        Customer.objects
        .filter(shop__admin=admin)
        .annotate(latest_balance=Subquery(latest_ledger_sq))
        .aggregate(total=Sum("latest_balance"))["total"]
    )
    return result or Decimal("0.00")


# ── Inventory sales helper ────────────────────────────────────────────────────

def _get_inventory_data(admin, from_date: datetime.date, to_date: datetime.date) -> dict:
    """
    Pull InventorySale figures for the given period.
    Returns a safe dict with zero-defaults if the inventory app is unavailable.
    """
    empty = {
        "inv_revenue":      Decimal("0.00"),
        "inv_cogs":         Decimal("0.00"),
        "inv_gross_profit": Decimal("0.00"),
        "inv_sale_count":   0,
        "inv_margin":       0.0,
        "inv_by_item":      [],
        "inv_monthly_dict": {},
    }
    try:
        from inventory.models import InventorySale

        inv_qs = InventorySale.objects.filter(
            admin=admin,
            status="completed",
            sale_date__gte=from_date,
            sale_date__lte=to_date,
        )

        totals = inv_qs.aggregate(
            inv_revenue      = Sum("total_amount"),
            inv_cogs         = Sum("total_cost"),
            inv_gross_profit = Sum("gross_profit"),
            inv_sale_count   = Count("id"),
        )

        inv_revenue      = totals["inv_revenue"]      or Decimal("0.00")
        inv_cogs         = totals["inv_cogs"]         or Decimal("0.00")
        inv_gross_profit = totals["inv_gross_profit"] or Decimal("0.00")
        inv_sale_count   = totals["inv_sale_count"]   or 0
        inv_margin = (
            round(float(inv_gross_profit) / float(inv_revenue) * 100, 1)
            if inv_revenue > 0 else 0.0
        )

        inv_by_item = list(
            inv_qs
            .values("item__id", "item__name", "item__unit")
            .annotate(
                qty     = Sum("quantity"),
                revenue = Sum("total_amount"),
                cogs    = Sum("total_cost"),
                profit  = Sum("gross_profit"),
            )
            .order_by("-revenue")
        )

        # Monthly dict used to align chart data with delivery labels
        inv_monthly = (
            InventorySale.objects
            .filter(admin=admin, status="completed")
            .annotate(month=TruncMonth("sale_date"))
            .values("month")
            .annotate(rev=Sum("total_amount"))
            .order_by("month")
        )
        inv_monthly_dict = {
            r["month"].strftime("%b %Y"): float(r["rev"] or 0)
            for r in inv_monthly
        }

        return {
            "inv_revenue":      inv_revenue,
            "inv_cogs":         inv_cogs,
            "inv_gross_profit": inv_gross_profit,
            "inv_sale_count":   inv_sale_count,
            "inv_margin":       inv_margin,
            "inv_by_item":      inv_by_item,
            "inv_monthly_dict": inv_monthly_dict,
        }

    except Exception:
        return empty


# ── Core P&L builder ─────────────────────────────────────────────────────────

def _build_ifrs_pnl(admin, from_date: datetime.date, to_date: datetime.date) -> dict:

    shop = getattr(admin, "shop_admin", None)

    # ── 1. Delivery revenue (accrual, IFRS 15) ────────────────────────────────
    revenue = (
        ReceivableLedger.objects.filter(
            admin=admin,
            transaction_type="delivery",
            date__gte=from_date,
            date__lte=to_date,
        ).aggregate(t=Sum("debit"))["t"]
        or Decimal("0.00")
    )

    total_cans = (
        DailyDelivery.objects.filter(
            admin=admin,
            delivery_date__gte=from_date,
            delivery_date__lte=to_date,
        ).aggregate(t=Sum("quantity_delivered"))["t"]
        or 0
    )

    # ── 2. Cash collected in period (disclosure sub-line only) ─────────────────
    cash_collected = (
        Payment.objects.filter(
            admin=admin,
            status="completed",
            is_subscription_payment=False,
            paid_at__date__gte=from_date,
            paid_at__date__lte=to_date,
        ).aggregate(t=Sum("amount"))["t"]
        or Decimal("0.00")
    )

    # ── 3. Trade receivables — canonical ledger balance ────────────────────────
    trade_receivables = _get_total_receivable(admin)

    # ── 4. Expenses — classified into IFRS buckets ────────────────────────────
    expenses_qs = Expense.objects.filter(
        admin=admin,
        shop=shop,
        status="paid",
        expense_date__gte=from_date,
        expense_date__lte=to_date,
    ).select_related("category")

    cogs_total    = Decimal("0.00")
    opex_total    = Decimal("0.00")
    finance_total = Decimal("0.00")
    tax_total     = Decimal("0.00")

    cogs_lines    = {}
    opex_lines    = {}
    finance_lines = {}
    tax_lines     = {}

    for exp in expenses_qs:
        cat_name = exp.category.name if exp.category else "Uncategorised"
        bucket   = _classify(cat_name)
        amt      = exp.amount or Decimal("0.00")

        if bucket == "cogs":
            cogs_total += amt
            cogs_lines[cat_name] = cogs_lines.get(cat_name, Decimal("0.00")) + amt
        elif bucket == "finance":
            finance_total += amt
            finance_lines[cat_name] = finance_lines.get(cat_name, Decimal("0.00")) + amt
        elif bucket == "tax":
            tax_total += amt
            tax_lines[cat_name] = tax_lines.get(cat_name, Decimal("0.00")) + amt
        else:
            opex_total += amt
            opex_lines[cat_name] = opex_lines.get(cat_name, Decimal("0.00")) + amt

    # ── 5. Inventory sales ────────────────────────────────────────────────────
    inv = _get_inventory_data(admin, from_date, to_date)

    # ── 6. Combined revenue & COGS ────────────────────────────────────────────
    total_revenue_combined = revenue + inv["inv_revenue"]
    cogs_total_combined    = cogs_total + inv["inv_cogs"]

    # ── 7. IFRS mandatory subtotals (using combined figures) ──────────────────
    gross_profit     = total_revenue_combined - cogs_total_combined
    operating_profit = gross_profit - opex_total
    pbt              = operating_profit - finance_total
    profit_period    = pbt - tax_total

    def _pct(numerator, denominator):
        if denominator and denominator != 0:
            return round(float(numerator) / float(denominator) * 100, 1)
        return 0.0

    gross_margin     = _pct(gross_profit,     total_revenue_combined)
    operating_margin = _pct(operating_profit, total_revenue_combined)
    net_margin       = _pct(profit_period,    total_revenue_combined)

    # ── 8. Monthly trend chart ─────────────────────────────────────────────────
    monthly_rev = list(
        ReceivableLedger.objects.filter(
            admin=admin,
            transaction_type="delivery",
            date__gte=from_date,
            date__lte=to_date,
        )
        .annotate(month=TruncMonth("date"))
        .values("month")
        .annotate(amt=Sum("debit"))
        .order_by("month")
    )
    monthly_exp = list(
        Expense.objects.filter(
            admin=admin,
            shop=shop,
            status="paid",
            expense_date__gte=from_date,
            expense_date__lte=to_date,
        )
        .annotate(month=TruncMonth("expense_date"))
        .values("month")
        .annotate(amt=Sum("amount"))
        .order_by("month")
    )

    month_map = {}
    for r in monthly_rev:
        k = r["month"].strftime("%b %Y")
        month_map.setdefault(k, {"rev": Decimal("0"), "exp": Decimal("0")})
        month_map[k]["rev"] = r["amt"] or Decimal("0")
    for r in monthly_exp:
        k = r["month"].strftime("%b %Y")
        month_map.setdefault(k, {"rev": Decimal("0"), "exp": Decimal("0")})
        month_map[k]["exp"] = r["amt"] or Decimal("0")

    chart_labels   = list(month_map.keys())
    chart_revenue  = [float(month_map[k]["rev"]) for k in chart_labels]
    chart_expenses = [float(month_map[k]["exp"]) for k in chart_labels]
    chart_profit   = [
        round(chart_revenue[i] - chart_expenses[i], 2)
        for i in range(len(chart_labels))
    ]

    # Align inventory monthly data to same chart labels
    inv_monthly_dict  = inv["inv_monthly_dict"]
    chart_inv_revenue = [inv_monthly_dict.get(lbl, 0) for lbl in chart_labels]

    return {
        # ── Delivery revenue ──────────────────────────────────────────────────
        "revenue":                 revenue,
        "total_cans":              total_cans,

        # ── Inventory sales ───────────────────────────────────────────────────
        "inv_revenue":             inv["inv_revenue"],
        "inv_cogs":                inv["inv_cogs"],
        "inv_gross_profit":        inv["inv_gross_profit"],
        "inv_sale_count":          inv["inv_sale_count"],
        "inv_margin":              inv["inv_margin"],
        "inv_by_item":             inv["inv_by_item"],

        # ── Combined totals ───────────────────────────────────────────────────
        "total_revenue_combined":  total_revenue_combined,
        "cogs_total_combined":     cogs_total_combined,

        # ── Expense buckets ───────────────────────────────────────────────────
        "cogs_total":              cogs_total,
        "cogs_lines":              sorted(cogs_lines.items(),    key=lambda x: -x[1]),
        "opex_total":              opex_total,
        "opex_lines":              sorted(opex_lines.items(),    key=lambda x: -x[1]),
        "finance_total":           finance_total,
        "finance_lines":           sorted(finance_lines.items(), key=lambda x: -x[1]),
        "tax_total":               tax_total,
        "tax_lines":               sorted(tax_lines.items(),     key=lambda x: -x[1]),

        # ── IFRS subtotals ────────────────────────────────────────────────────
        "gross_profit":            gross_profit,
        "gross_margin":            gross_margin,
        "operating_profit":        operating_profit,
        "operating_margin":        operating_margin,
        "pbt":                     pbt,
        "profit_period":           profit_period,
        "net_margin":              net_margin,
        "is_profit":               profit_period >= Decimal("0.00"),

        # ── Receivables / cash ────────────────────────────────────────────────
        "trade_receivables":       trade_receivables,
        "cash_collected":          cash_collected,

        # ── Chart ─────────────────────────────────────────────────────────────
        "chart_labels":            json.dumps(chart_labels),
        "chart_revenue":           json.dumps(chart_revenue),
        "chart_expenses":          json.dumps(chart_expenses),
        "chart_profit":            json.dumps(chart_profit),
        "chart_inv_revenue":       json.dumps(chart_inv_revenue),
    }


# ── Comparative period helper ─────────────────────────────────────────────────

def _comparative_dates(from_date, to_date):
    """Same duration, one year prior."""
    try:
        comp_from = from_date.replace(year=from_date.year - 1)
    except ValueError:
        comp_from = from_date - datetime.timedelta(days=365)
    try:
        comp_to = to_date.replace(year=to_date.year - 1)
    except ValueError:
        comp_to = to_date - datetime.timedelta(days=365)
    return comp_from, comp_to


# ── Main view ─────────────────────────────────────────────────────────────────

@login_required
def profit_loss_statement(request):
    admin = _get_admin(request)
    today = timezone.now().date()
    shop  = getattr(admin, "shop_admin", None)

    preset = request.GET.get("preset", "this_year")

    if preset == "this_month":
        from_date = today.replace(day=1)
        to_date   = today
    elif preset == "last_month":
        first_this    = today.replace(day=1)
        last_day_prev = first_this - datetime.timedelta(days=1)
        from_date     = last_day_prev.replace(day=1)
        to_date       = last_day_prev
    elif preset == "last_year":
        from_date = today.replace(year=today.year - 1, month=1,  day=1)
        to_date   = today.replace(year=today.year - 1, month=12, day=31)
    elif preset == "custom":
        try:
            from_date = datetime.date.fromisoformat(request.GET.get("from_date", ""))
        except (ValueError, TypeError):
            from_date = today.replace(month=1, day=1)
        try:
            to_date = datetime.date.fromisoformat(request.GET.get("to_date", ""))
        except (ValueError, TypeError):
            to_date = today
    else:
        preset    = "this_year"
        from_date = today.replace(month=1, day=1)
        to_date   = today

    if from_date > to_date:
        from_date, to_date = to_date, from_date

    # ── Current period ────────────────────────────────────────────────────────
    data = _build_ifrs_pnl(admin, from_date, to_date)

    # ── Comparative period ────────────────────────────────────────────────────
    comp_from, comp_to = _comparative_dates(from_date, to_date)
    comp = _build_ifrs_pnl(admin, comp_from, comp_to)

    # ── Build context ─────────────────────────────────────────────────────────
    ctx = {
        "from_date":  from_date.isoformat(),
        "to_date":    to_date.isoformat(),
        "comp_from":  comp_from.isoformat(),
        "comp_to":    comp_to.isoformat(),
        "preset":     preset,
        "today":      today.isoformat(),
        "shop_name":  shop.name if shop else (admin.username if admin else ""),
        "shop":       shop,
        "comp":       comp,
        **data,
    }
    return render(request, "accounts/profit_loss.html", ctx)