from collections import defaultdict
from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils.translation import gettext as _
from .models import User
from accounts.decorators import role_required
from . import models
from django.shortcuts import render, get_object_or_404
from django.db.models import Sum, ExpressionWrapper, F, DecimalField, Min, Max, Q, Value, OuterRef, Subquery, Count
from datetime import timedelta
from django.utils import timezone
from django.http import Http404, JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseBadRequest
from django.contrib import messages
from django.db import transaction, IntegrityError
from django.template.loader import render_to_string
from django.core.files.base import ContentFile
from django.urls import reverse
import io
import json
from .decorators import shop_admin_required
from decimal import Decimal, InvalidOperation
from urllib.parse import quote as urlquote
from django.core.mail import EmailMessage, get_connection
from django.contrib import messages
from django.db.models.functions import TruncMonth, TruncDay
from django.core.exceptions import ValidationError
from django.core.cache import cache
import uuid
from accounts.customer_views import (
          customer_create,
          customer_edit,
          customer_soft_delete as customer_delete,
          customer_hard_delete,
      )
# Error Handlers
def error_500(request):
    ctx = {'request_id': str(uuid.uuid4()).split('-')[0].upper()}
    return render(request, 'Errors/500.html', ctx, status=500)
def error_404(request, exception=None):
    ctx = {'request_id': str(uuid.uuid4()).split('-')[0].upper()}
    return render(request, 'Errors/404.html', ctx, status=404)
def error_400(request, exception=None):
    ctx = {'request_id': str(uuid.uuid4()).split('-')[0].upper()}
    return render(request, 'Errors/400.html', ctx, status=400)

def website(request):
    context = {
        'shop': models.Shop.objects.filter(admin=request.user).first()
    }
    return render(request, 'website.html', context)

def public_shop_page(request, slug):
    shop = get_object_or_404(models.Shop, slug=slug)
 
    # Reject if shop has not enabled their public page
    if not shop.website_enabled:
        raise Http404("This shop does not have a public page.")
 
    # ── WhatsApp number ─────────────────────────────────────────────────────
    # Prefer the shop admin's personal WhatsApp; fall back to shop phone.
    admin_wa = getattr(shop.admin, 'whatsapp_number', None)
    whatsapp_raw = admin_wa or shop.phone_number or ''
    # Strip non-digits for the wa.me link
    whatsapp_digits = ''.join(filter(str.isdigit, whatsapp_raw))
 
    # ── Hero content ────────────────────────────────────────────────────────
    # These can be extended to their own model fields later;
    # for now they fall back to generic copy so every shop looks presentable.
    hero_badge       = None   # e.g. "Same-day delivery now available"
    hero_title_line1 = None   # e.g. "Drink Water"
    hero_title_accent = None  # italic coloured line
    hero_title_line3 = None   # will fall back to shop.name in template
    hero_trust_text  = f"Trusted by customers in {shop.city}" if shop.city else "Trusted by our customers"
 
    # ── Marquee strip ───────────────────────────────────────────────────────
    # Build from what the shop actually has configured
    marquee_items = []
    if shop.city:
        marquee_items.append(f"📍 Serving {shop.city}")
    if shop.formatted_hours:
        marquee_items.append(f"🕐 Open {shop.formatted_hours}")
    if shop.working_days_display:
        marquee_items.append(f"📅 {shop.working_days_display}")
    if shop.phone_number:
        marquee_items.append(f"📞 {shop.phone_number}")
    if shop.email:
        marquee_items.append(f"✉️ {shop.email}")
    # Pad to at least 5 items so the marquee looks full
    defaults = ["⭐ Quality Service", "🚚 Fast Delivery", "🔒 Trusted & Reliable",
                "💯 Customer First", "🏆 Proven Excellence"]
    while len(marquee_items) < 5:
        marquee_items.append(defaults[len(marquee_items) % len(defaults)])
    # Duplicate for seamless CSS loop (JS also does this as a safety net)
    marquee_items = marquee_items + marquee_items
 
    # ── Steps ────────────────────────────────────────────────────────────────
    # Generic 4-step fallback every shop can use.
    # To customise: extend Shop model or create a ShopStep model.
    steps = [
        {"icon": "📱", "title": "Place Order",    "description": "Order by phone, WhatsApp, or walk in."},
        {"icon": "✅", "title": "We Prepare",      "description": "Your order is prepared with care and quality-checked."},
        {"icon": "🚚", "title": "Fast Delivery",   "description": "Delivered to your door quickly and safely."},
        {"icon": "😊", "title": "Enjoy & Repeat",  "description": "Sit back and enjoy. Reorder anytime with ease."},
    ]
 
    # ── Services ─────────────────────────────────────────────────────────────
    # Falls back to empty list — template hides the section if empty.
    # Extend this by adding a ShopService model later.
    services = []   # populate from DB when you have service records
 
    # ── Why Us ───────────────────────────────────────────────────────────────
    why_points = [
        {"icon": "🏆", "title": "Quality Guaranteed",    "description": "We stand behind every product and service we offer."},
        {"icon": "🚀", "title": "Reliable & On Time",     "description": "Punctual delivery every time, no excuses."},
        {"icon": "💬", "title": "Responsive Support",     "description": "Reach us by phone, WhatsApp, or email — we reply fast."},
        {"icon": "❤️", "title": "Customer-First Culture", "description": "Your satisfaction drives everything we do."},
    ]
    quality_bars = []   # leave empty; template hides right-side card if empty
    quality_cert = None
 
    # ── Testimonials ─────────────────────────────────────────────────────────
    # Populate from a Testimonial model when you build one.
    testimonials     = []
    show_testimonials = bool(testimonials)
    avg_rating       = None
    review_count     = None
 
    # ── Contact & delivery areas ─────────────────────────────────────────────
    delivery_area_list = []   # e.g. ["DHA", "Clifton", "Gulshan"]
    delivery_areas     = ", ".join(delivery_area_list) if delivery_area_list else shop.city
    contact_subtitle   = f"We serve {shop.city}. Get in touch — we're always available." if shop.city else "Get in touch — we're always available."
 
    # ── CTA ──────────────────────────────────────────────────────────────────
    cta_title    = f"Ready to Order from {shop.name}?"
    cta_subtitle = "Contact us today — fast response guaranteed."
 
    context = {
        "shop": shop,
 
        # Hero
        "hero_badge":        hero_badge,
        "hero_title_line1":  hero_title_line1,
        "hero_title_accent": hero_title_accent,
        "hero_title_line3":  hero_title_line3,
        "hero_trust_text":   hero_trust_text,
 
        # Marquee
        "marquee_items": marquee_items,
 
        # Stats (empty = section hidden)
        "stat_items": [],
 
        # Process steps
        "steps":        steps,
        "how_title":    "How It Works",
        "how_subtitle": "Getting started is simple — four easy steps.",
 
        # Services (empty = section hidden)
        "services":          services,
        "services_title":    "Our Services",
        "services_subtitle": "",
 
        # Why us
        "why_points":            why_points,
        "why_title":             f"Why Choose {shop.name}",
        "why_subtitle":          "Here's what makes us different.",
        "quality_bars":          quality_bars,
        "quality_card_title":    "Performance",
        "quality_card_subtitle": "Our latest metrics",
        "quality_cert":          quality_cert,
 
        # Testimonials
        "testimonials":     testimonials,
        "show_testimonials": show_testimonials,
        "avg_rating":       avg_rating,
        "review_count":     review_count,
 
        # Contact
        "whatsapp_number":         whatsapp_digits,
        "whatsapp_number_display": whatsapp_raw,
        "delivery_area_list":      delivery_area_list,
        "delivery_areas":          delivery_areas,
        "contact_subtitle":        contact_subtitle,
 
        # CTA
        "cta_title":    cta_title,
        "cta_subtitle": cta_subtitle,
    }
 
    return render(request, "public_shop_page.html", context)

# Delivery Assignment
import math

def haversine_km(lat1, lng1, lat2, lng2):
    """Straight-line distance in km between two GPS coords."""
    R = 6371
    d_lat = math.radians(lat2 - lat1)
    d_lng = math.radians(lng2 - lng1)
    a = math.sin(d_lat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(d_lng/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

from .models import DeliveryAssignment

# ── Admin: create assignment ──────────────────────────────────────────────────

@shop_admin_required
def assignment_create(request):
    user      = request.user
    customers = models.Customer.objects.filter(shop__admin=user, is_active=True)
    staff_qs  = models.Staff.objects.filter(admin=user, is_blocked=False)
    can_types = models.CanType.objects.filter(admin=user, enabled=True)

    if request.method == 'POST':
        # Add this at the top of the POST block temporarily
        customer_id    = request.POST.get('customer_id')
        rider_id       = request.POST.get('rider_id')
        print(rider_id)
        can_type_id    = request.POST.get('can_type_id')
        quantity_raw   = request.POST.get('quantity', '1')
        delivery_date  = request.POST.get('delivery_date') or str(timezone.now().date())
        notes          = request.POST.get('notes', '')
        import logging
        log = logging.getLogger(__name__)
        log.warning(f"POST data: customer={customer_id} rider={rider_id} can_type={can_type_id}")

        is_ajax = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

        def err(msg):
            if is_ajax:
                return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg)
            return redirect('assignment_create')

        if not all([customer_id, rider_id, can_type_id]):
            return err('Customer, rider and can type are required.')

        # In assignment_create view, replace the try block:

        try:
            customer = models.Customer.objects.get(id=customer_id, shop__admin=user)
        except models.Customer.DoesNotExist:
            return err('Invalid customer selected.')

        try:
            rider = models.Staff.objects.get(id=rider_id, admin=user)
        except models.Staff.DoesNotExist:
            return err(f'Invalid rider selected. rider_id={rider_id}')

        try:
            can_type = models.CanType.objects.get(id=can_type_id, admin=user)
        except models.CanType.DoesNotExist:
            return err('Invalid can type selected.')

        try:
            qty = int(quantity_raw)
            if qty < 1:
                raise ValueError
        except (TypeError, ValueError):
            return err('Quantity must be a positive number.')

        # resolve rate
        try:
            cct = models.CustomerCanType.objects.get(customer=customer, can_type=can_type)
            rate = cct.price
        except models.CustomerCanType.DoesNotExist:
            rate = can_type.price

        try:
            date_obj = timezone.datetime.fromisoformat(delivery_date).date()
        except Exception:
            date_obj = timezone.now().date()
        print(rider)
        assignment = models.DeliveryAssignment.objects.create(
            admin=user,
            shop=getattr(user, 'shop', None),
            staff=rider,                    # ← was rider=rider
            customer=customer,
            can_type=can_type,
            quantity_to_deliver=qty,        # ← was quantity=qty
            rate_given=rate,
            delivery_date=date_obj,
            notes=notes,
        )

        if is_ajax:
            return JsonResponse({'ok': True, 'message': f'Assignment created for {customer.display_name}'})
        messages.success(request, f'Assignment #{assignment.id} created for {customer.display_name}.')
        return redirect('assignments_list')

    # Build customer→can map same as delivery form
    customer_can_map = {}
    for c in customers:
        entries = [
            {'id': e.can_type.id, 'name': str(e.can_type), 'price': str(e.price)}
            for e in models.CustomerCanType.objects.filter(customer=c, can_type__enabled=True)
        ]
        customer_can_map[c.id] = entries

    return render(request, 'accounts/assignment_form.html', {
        'customers': customers,
        'staff_list': staff_qs,
        'can_types': can_types,
        'customer_can_map': customer_can_map,
        'today': timezone.now().date(),
    })


@shop_admin_required
def assignments_list(request):
    user = request.user
    date_filter = request.GET.get('date') or str(timezone.now().date())
    rider_filter = request.GET.get('rider') or ''
    status_filter = request.GET.get('status') or ''

    qs = models.DeliveryAssignment.objects.filter(admin=user).select_related('customer', 'staff', 'can_type')
    # and the filter:
    if rider_filter:
        qs = qs.filter(staff_id=rider_filter)   # ← was rider_id

    if date_filter:
        try:
            qs = qs.filter(delivery_date=date_filter)
        except Exception:
            pass
        
    if status_filter:
        qs = qs.filter(status=status_filter)

    staff_qs = models.Staff.objects.filter(admin=user)
    return render(request, 'accounts/assignments_list.html', {
        'assignments': qs,
        'staff_list': staff_qs,
        'date_filter': date_filter,
        'rider_filter': rider_filter,
        'status_filter': status_filter,
        'total': qs.count(),
        'done': qs.filter(status='done').count(),       # ← was 'completed'
        'pending': qs.filter(status='pending').count(),
    })


@shop_admin_required
@require_POST
def assignment_delete(request, assignment_id):
    a = get_object_or_404(models.DeliveryAssignment, id=assignment_id, admin=request.user)
    if a.status == 'completed':
        messages.error(request, 'Cannot delete a completed assignment.')
        return redirect('assignments_list')
    a.delete()
    messages.success(request, 'Assignment deleted.')
    return redirect('assignments_list')


# ── Rider: dashboard with today's assignments ─────────────────────────────────

@role_required(allowed_roles=['staff'])
def rider_dashboard(request):
    me = models.Staff.objects.filter(user=request.user).select_related('admin').first()
    if not me:
        return HttpResponse('Staff record not found.')
    if me.is_blocked:
        return HttpResponse('Your account is blocked. Contact admin.')

    today = timezone.now().date()
    assignments = models.DeliveryAssignment.objects.filter(
        staff=me, delivery_date=today
    ).select_related('customer', 'can_type').order_by('sort_order', 'status', 'id')

    pending   = [a for a in assignments if a.status in ('pending', 'in_progress')]
    done_list = [a for a in assignments if a.status == 'done']
    failed    = [a for a in assignments if a.status == 'failed']

    # Nearest-next GPS logic
    nearest = None
    try:
        from tracking.store import rider_store
        loc = rider_store.get(me.id)
        if loc and pending:
            import math
            def dist(a):
                lat = float(a.customer.latitude or 0)
                lng = float(a.customer.longitude or 0)
                if not lat and not lng:
                    return 9999
                R = 6371
                d_lat = math.radians(lat - loc.lat)
                d_lng = math.radians(lng - loc.lng)
                x = math.sin(d_lat/2)**2 + math.cos(math.radians(loc.lat)) * math.cos(math.radians(lat)) * math.sin(d_lng/2)**2
                return R * 2 * math.atan2(math.sqrt(x), math.sqrt(1 - x))
            nearest = min(pending, key=dist)
    except Exception:
        nearest = pending[0] if pending else None

    # Today's walk-in deliveries (recorded directly, no assignment)
    walkins = models.DailyDelivery.objects.filter(
        staff=me, delivery_date=today, assigned_delivery_source__isnull=True
    ).select_related('customer', 'can_type').order_by('-id')[:5]

    return render(request, 'accounts/rider_dashboard.html', {
        'assignments': assignments,
        'pending': pending,
        'done_list': done_list,
        'failed': failed,
        'nearest': nearest,
        'today': today,
        'me': me,
        'walkins': walkins,
        'total': assignments.count(),
        'done_count': len(done_list),
        'pending_count': len(pending),
    })


@role_required(allowed_roles=['staff'])
@require_POST
def rider_mark_done(request, assignment_id):
    me = models.Staff.objects.filter(user=request.user).first()
    if not me:
        return JsonResponse({'ok': False, 'message': 'Staff not found'}, status=400)

    assignment = get_object_or_404(models.DeliveryAssignment, id=assignment_id, staff=me)  # ← was rider=me
    is_ajax = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

    if assignment.status == 'completed':
        msg = 'Already marked as done.'
        if is_ajax:
            return JsonResponse({'ok': False, 'message': msg})
        messages.info(request, msg)
        return redirect('rider_dashboard')

    try:
        assignment.mark_done()
        # also fire tracking mark_delivered so map updates
        try:
            from tracking.store import rider_store
            rider_store.mark_delivered(me.id, assignment.customer_id)
            return JsonResponse({'ok': True, 'message': f'Delivery to {assignment.customer.display_name} marked done!'})
        except Exception:
            pass
    except Exception as e:
        if is_ajax:
            return JsonResponse({'ok': False, 'message': str(e)}, status=400)
        messages.error(request, str(e))
        return redirect('rider_dashboard')

    if is_ajax:
        return JsonResponse({'ok': True, 'message': f'Delivery to {assignment.customer.display_name} marked done!'})
    messages.success(request, f'Delivery to {assignment.customer.display_name} marked done!')
    return redirect('rider_dashboard')

@role_required(allowed_roles=['staff'])
@require_POST
def rider_mark_failed(request, assignment_id):
    me = models.Staff.objects.filter(user=request.user).first()
    if not me:
        return JsonResponse({'ok': False, 'message': 'Staff not found'}, status=400)
    assignment = get_object_or_404(models.DeliveryAssignment, id=assignment_id, staff=me)
    reason = request.POST.get('reason', '').strip() or 'Not delivered'
    assignment.mark_failed(reason)
    return JsonResponse({'ok': True, 'message': 'Marked as failed'})

# End




# optional PDF/third-party libs
try:
    from xhtml2pdf import pisa
except Exception:
    pisa = None

import requests

@login_required
def terms(request):
    return render(request, 'accounts/terms.html')

def get_total_receivable(admin_user=None, shop=None, active_only=False):
    """
    Canonical total-receivable calculation using ReceivableLedger.
 
    Uses a single efficient subquery (no Python loop) so it works correctly
    in both the dashboard and the P&L view without any discrepancy.
 
    Parameters
    ----------
    admin_user  : User  – the shop admin
    shop        : Shop  – unused, kept for API compatibility
    active_only : bool  – when True, restrict to is_active=True customers
                          (use False for the full-shop total)
 
    Returns
    -------
    Decimal – sum of latest ReceivableLedger.balance_after per customer
    """
    from django.db.models import OuterRef, Subquery, Sum
    from decimal import Decimal
 
    if not admin_user:
        return Decimal('0.00')
 
    # Latest ledger balance per customer (single DB round-trip)
    latest_ledger_sq = (
        models.ReceivableLedger.objects
        .filter(customer=OuterRef('pk'), admin=admin_user)
        .order_by('-date', '-id')
        .values('balance_after')[:1]
    )
 
    customer_qs = models.Customer.objects.filter(shop__admin=admin_user)
    if active_only:
        customer_qs = customer_qs.filter(is_active=True)
 
    result = (
        customer_qs
        .annotate(latest_balance=Subquery(latest_ledger_sq))
        .aggregate(total=Sum('latest_balance'))['total']
    )
    return result or Decimal('0.00')

@login_required
@require_POST
def add_adjusting_entry(request, customer_id):
    """Create an adjusting CanTransaction (does not create Delivery records).

    Expects POST with `full_cans` (int, default 0), `empty_cans` (int, default 0), and optional `comment`.
    Saves a CanTransaction with `transaction_type='ADJUSTMENT'` and returns JSON for AJAX or redirects.
    """
    admin_user = _resolve_admin_user_for_request(request)
    customer = get_object_or_404(models.Customer, id=customer_id, shop__admin=admin_user)

    # parse integers safely
    try:
        full = int(request.POST.get('full_cans') or 0)
    except Exception:
        return JsonResponse({'ok': False, 'message': 'Invalid full cans value'}, status=400)
    try:
        empty = int(request.POST.get('empty_cans') or 0)
    except Exception:
        return JsonResponse({'ok': False, 'message': 'Invalid empty cans value'}, status=400)

    comment = (request.POST.get('comment') or '').strip()
    apply_opening = bool(request.POST.get('apply_opening'))

    if full == 0 and empty == 0:
        msg = 'Please enter at least one non-zero cans value for adjustment.'
        if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'ok': False, 'message': msg}, status=400)
        messages.error(request, msg)
        return redirect('can_statement', customer_id=customer_id)

    shop = getattr(admin_user, 'shop_admin', getattr(admin_user, 'shop', None))

    # If this adjustment is intended to modify the opening balance, update the opening row itself
    if apply_opening:
        if not comment:
            msg = 'Comment is required when applying an adjustment to the opening balance.'
            if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg)
            return redirect('can_statement', customer_id=customer_id)

        opening_tx = models.CanTransaction.objects.filter(customer=customer, admin=admin_user, transaction_type='OPENING').order_by('date', 'id').first()
        if not opening_tx:
            msg = 'Cannot apply to opening: no opening balance exists for this customer.'
            if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg)
            return redirect('can_statement', customer_id=customer_id)

        # Ensure opening is still the first ledger entry; model enforces opening must be first
        earlier_exists = models.CanTransaction.objects.filter(
            customer=customer, admin=admin_user
        ).exclude(id=opening_tx.id).filter(
            Q(date__lt=opening_tx.date) | Q(date=opening_tx.date, id__lt=opening_tx.id)
        ).exists()
        if earlier_exists:
            delta = int(full or 0) - int(empty or 0)
            new_full = int(opening_tx.full_cans_delivered or 0) + delta
            if new_full < 0:
                msg = 'Resulting opening cans would be negative. Adjust amounts.'
                if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'ok': False, 'message': msg}, status=400)
                messages.error(request, msg)
                return redirect('can_statement', customer_id=customer_id)

            # Re-run simulation defensively
            simulated = new_full
            later_qs = models.CanTransaction.objects.filter(customer=customer, admin=admin_user).exclude(id=opening_tx.id).filter(
                Q(date__gt=opening_tx.date) | Q(date=opening_tx.date, id__gt=opening_tx.id)
            ).order_by('date', 'id')
            for t in later_qs:
                t_full = int(t.full_cans_delivered or 0)
                t_empty = int(t.empty_cans_received or 0)
                allowed_empty = simulated + t_full
                if t_empty > allowed_empty:
                    msg = f"Cannot apply opening change: later transaction #{t.id} would return more empties ({t_empty}) than allowed ({allowed_empty})."
                    if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'ok': False, 'message': msg}, status=400)
                    messages.error(request, msg)
                    return redirect('can_statement', customer_id=customer_id)
                simulated = simulated + t_full - t_empty
                if simulated < 0:
                    msg = f"Cannot apply opening change: running balance becomes negative after transaction #{t.id}."
                    if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'ok': False, 'message': msg}, status=400)
                    messages.error(request, msg)
                    return redirect('can_statement', customer_id=customer_id)

            # Persist the opening change and propagate balances
            stamp = timezone.now().strftime('%Y-%m-%d %H:%M')
            author = getattr(request.user, 'username', 'system')
            appended = f"[{stamp} @{author}] {comment}"
            try:
                with transaction.atomic():
                    models.CanTransaction.objects.filter(id=opening_tx.id).update(
                        full_cans_delivered=new_full,
                        comments=(opening_tx.comments or '') + ('\n' if opening_tx.comments else '') + appended
                    )

                    prev = models.CanTransaction.objects.filter(
                        customer=customer, admin=admin_user
                    ).exclude(id=opening_tx.id).filter(
                        Q(date__lt=opening_tx.date) | Q(date=opening_tx.date, id__lt=opening_tx.id)
                    ).order_by('-date', '-id').first()
                    prev_balance = prev.balance_after_transaction if prev else 0
                    opening_balance = prev_balance + new_full - 0
                    models.CanTransaction.objects.filter(id=opening_tx.id).update(balance_after_transaction=opening_balance)

                    cur = opening_balance
                    for t in later_qs:
                        cur = cur + (t.full_cans_delivered or 0) - (t.empty_cans_received or 0)
                        if t.balance_after_transaction != cur:
                            models.CanTransaction.objects.filter(id=t.id).update(balance_after_transaction=cur)
            except Exception as e:
                msg = 'Failed to persist opening update: %s' % (e,)
                if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'ok': False, 'message': msg}, status=500)
                messages.error(request, msg)
                return redirect('can_statement', customer_id=customer_id)

            if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'ok': True, 'message': 'Opening updated successfully'})
            messages.success(request, 'Opening updated successfully')
            return redirect('can_statement', customer_id=customer_id)

        # Calculate delta: full increases opening, empty decreases it
        delta = int(full or 0) - int(empty or 0)
        new_full = int(opening_tx.full_cans_delivered or 0) + delta
        if new_full < 0:
            msg = 'Resulting opening cans would be negative. Adjust amounts.'
            if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg)
            return redirect('can_statement', customer_id=customer_id)

        # Simulate forward balances to ensure later transactions remain valid
        simulated = new_full
        later_qs = models.CanTransaction.objects.filter(customer=customer, admin=admin_user).exclude(id=opening_tx.id).filter(
            Q(date__gt=opening_tx.date) | Q(date=opening_tx.date, id__gt=opening_tx.id)
        ).order_by('date', 'id')
        for t in later_qs:
            t_full = int(t.full_cans_delivered or 0)
            t_empty = int(t.empty_cans_received or 0)
            allowed_empty = simulated + t_full
            if t_empty > allowed_empty:
                msg = f"Cannot apply opening change: later transaction #{t.id} would return more empties ({t_empty}) than allowed ({allowed_empty})."
                if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'ok': False, 'message': msg}, status=400)
                messages.error(request, msg)
                return redirect('can_statement', customer_id=customer_id)
            simulated = simulated + t_full - t_empty
            if simulated < 0:
                msg = f"Cannot apply opening change: running balance becomes negative after transaction #{t.id}."
                if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'ok': False, 'message': msg}, status=400)
                messages.error(request, msg)
                return redirect('can_statement', customer_id=customer_id)

        # Append audit comment and save opening
        stamp = timezone.now().strftime('%Y-%m-%d %H:%M')
        author = getattr(request.user, 'username', 'system')
        appended = f"[{stamp} @{author}] {comment}"
        opening_tx.full_cans_delivered = new_full
        opening_tx.comments = (opening_tx.comments or '') + ('\n' if opening_tx.comments else '') + appended
        try:
            opening_tx.save()
        except ValidationError as e:
            msg = str(e)
            if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'ok': False, 'message': msg}, status=400)
            messages.error(request, msg)
            return redirect('can_statement', customer_id=customer_id)
        except Exception as e:
            msg = 'Failed to update opening: %s' % (e,)
            if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
                return JsonResponse({'ok': False, 'message': msg}, status=500)
            messages.error(request, msg)
            return redirect('can_statement', customer_id=customer_id)

        if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'ok': True, 'message': 'Opening balance updated'})
        messages.success(request, 'Opening balance updated')
        return redirect('can_statement', customer_id=customer_id)

    # Otherwise create a normal ADJUSTMENT transaction
    try:
        ct = models.CanTransaction(
            admin=admin_user,
            shop=shop,
            customer=customer,
            date=timezone.now().date(),
            full_cans_delivered=full,
            empty_cans_received=empty,
            transaction_type='ADJUSTMENT',
            comments=comment,
        )
        ct.save()
    except ValidationError as e:
        msg = str(e)
        if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'ok': False, 'message': msg}, status=400)
        messages.error(request, msg)
        return redirect('can_statement', customer_id=customer_id)
    except Exception as e:
        msg = 'Failed to save adjusting entry: %s' % (e,)
        if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'ok': False, 'message': msg}, status=500)
        messages.error(request, msg)
        return redirect('can_statement', customer_id=customer_id)

    # Success
    if hasattr(request, 'headers') and request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'ok': True, 'message': 'Adjusting entry saved'})
    messages.success(request, 'Adjusting entry saved')
    return redirect('can_statement', customer_id=customer_id)


def get_customer_can_balance(customer, admin):
    """
    Get the current can balance for a customer.
    """
    latest_transaction = models.CanTransaction.objects.filter(
        customer=customer,
        admin=admin
    ).order_by('-date', '-id').first()

    if latest_transaction:
        return latest_transaction.balance_after_transaction
    else:
        return 0


@role_required(allowed_roles=["staff"])
def record_delivery(request):
    me = models.Staff.objects.filter(user=request.user).first()
    if me is None:
        return HttpResponse("Error! STAFF RECORD NOT FOUND!")

    if me.is_blocked:
        return HttpResponse("Error! STAFF ACOUNT IS BLOCKED!, PLEASE CONTACT SHOP OWNER OR ADMINISTRATOR!")
    else:
        if request.method == "POST":
            if hasattr(request, 'headers'):
                is_ajax = request.headers.get('x-requested-with') == 'XMLHttpRequest'
            else:
                is_ajax = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

            customer_id = request.POST.get("customer_id")
            qty_raw = request.POST.get("quantity_cans")
            empty_raw = request.POST.get("empty_cans_received")
            can_type_id = request.POST.get("can_type")

            if not can_type_id:
                msg = _('Please select a can type')
                if is_ajax:
                    return JsonResponse({'ok': False, 'message': msg}, status=400)
                messages.error(request, msg)
                return redirect("/record-delivery/")
            try:
                selected_can_type = models.CanType.objects.get(
                    id=can_type_id, admin=me.admin, enabled=True)
            except models.CanType.DoesNotExist:
                msg = _('Invalid can type selected')
                if is_ajax:
                    return JsonResponse({'ok': False, 'message': msg}, status=400)
                messages.error(request, msg)
                return redirect("/record-delivery/")

            try:
                qty = int(qty_raw)
                if qty < 1:
                    msg = _('Quantity must be a whole number greater than 0')
                    if is_ajax:
                        return JsonResponse({'ok': False, 'message': msg}, status=400)
                    messages.error(request, msg)
                    return redirect("/record-delivery/")
            except (TypeError, ValueError):
                msg = _('Invalid quantity - enter a whole number')
                if is_ajax:
                    return JsonResponse({'ok': False, 'message': msg}, status=400)
                messages.error(request, msg)
                return redirect("/record-delivery/")

            try:
                empty_cans = int(empty_raw) if empty_raw not in (None, '') else 0
                if empty_cans < 0:
                    msg = _('Empty cans must be 0 or greater')
                    if is_ajax:
                        return JsonResponse({'ok': False, 'message': msg}, status=400)
                    messages.error(request, msg)
                    return redirect('/record-delivery/')
            except (TypeError, ValueError):
                msg = _('Invalid empty cans - enter a whole number')
                if is_ajax:
                    return JsonResponse({'ok': False, 'message': msg}, status=400)
                messages.error(request, msg)
                return redirect('/record-delivery/')

            if customer_id and qty:
                customer = models.Customer.objects.filter(
                    id=customer_id).first()
                if not customer:
                    msg = _('Invalid customer selected')
                    if is_ajax:
                        return JsonResponse({'ok': False, 'message': msg}, status=400)
                    messages.error(request, msg)
                    return redirect('/record-delivery/')
                if not getattr(customer, 'is_active', False):
                    msg = _('Selected customer is not active')
                    if is_ajax:
                        return JsonResponse({'ok': False, 'message': msg}, status=400)
                    messages.error(request, msg)
                    return redirect('/record-delivery/')
                try:
                    cust_ct = models.CustomerCanType.objects.get(
                        customer=customer, can_type=selected_can_type)
                    rate = cust_ct.price
                except Exception:
                    rate = selected_can_type.price

                customer_assignments = models.CustomerCanType.objects.filter(
                    customer=customer, can_type__enabled=True)
                if customer_assignments.exists() and not customer_assignments.filter(can_type=selected_can_type).exists():
                    msg = _('Selected can type is not assigned to this customer')
                    if is_ajax:
                        return JsonResponse({'ok': False, 'message': msg}, status=400)
                    messages.error(request, msg)
                    return redirect('/record-delivery/')

                current_balance = get_customer_can_balance(customer, me.admin)
                opening_tx = models.CanTransaction.objects.filter(customer=customer, admin=me.admin, transaction_type='OPENING').order_by('date', 'id').first()
                opening_tx = opening_tx.balance_after_transaction if opening_tx else 0
                if opening_tx == 0:
                    current_balance = int(empty_cans + int(current_balance))
                    if empty_cans > current_balance:
                        msg = _('Empty cans cannot exceed current can balance')
                        if is_ajax:
                            return JsonResponse({'ok': False, 'message': msg}, status=400)
                        messages.error(request, msg)
                        return redirect('/record-delivery/')
                else:
                    if empty_cans > current_balance:
                        msg = _('Empty cans cannot exceed current can balance')
                        if is_ajax:
                            return JsonResponse({'ok': False, 'message': msg}, status=400)
                        messages.error(request, msg)
                        return redirect('/record-delivery/')

                try:
                    entry = models.DailyDelivery(
                        staff=me,
                        admin=me.admin,
                        customer=customer,
                        quantity_delivered=qty,
                        empty_cans_received=empty_cans,
                        can_type=selected_can_type,
                        rate_given=rate,
                    )
                    entry.save()
                except Exception as e:
                    msg = f'Error saving delivery entry: {e}'
                    if is_ajax:
                        return JsonResponse({'ok': False, 'message': msg}, status=400)
                    messages.error(request, msg)
                    return redirect('/record-delivery/')
                # After entry.save() — auto-match and close any open assignment
                try:
                    from django.utils import timezone
                    open_assignment = models.DeliveryAssignment.objects.filter(
                        staff=me,
                        customer=customer,
                        can_type=selected_can_type,
                        delivery_date=timezone.now().date(),
                        status='pending',
                    ).first()
                    if not open_assignment:
                        # also check in_progress
                        open_assignment = models.DeliveryAssignment.objects.filter(
                            staff=me,
                            customer=customer,
                            delivery_date=timezone.now().date(),
                            status__in=['pending', 'in_progress'],
                        ).first()
                    if open_assignment:
                        open_assignment.status = 'done'
                        open_assignment.completed_at = timezone.now()
                        open_assignment.resulting_delivery = entry
                        open_assignment.save(update_fields=['status', 'completed_at', 'resulting_delivery', 'updated_at'])
                except Exception:
                    pass  # never block delivery recording if assignment lookup fails

                if is_ajax:
                    return JsonResponse({'ok': True, 'message': 'Entry recorded successfully'})
                messages.success(request, "✔ Entry Added Successfully!")
            return redirect("/record-delivery/")

    customers = me.customers.filter(is_active=True)
    can_types = models.CanType.objects.filter(admin=me.admin, enabled=True)

    customer_can_map = {}
    for c in customers:
        entries = []
        for ce in models.CustomerCanType.objects.filter(customer=c, can_type__enabled=True):
            entries.append({'id': ce.can_type.id, 'name': str(
                ce.can_type), 'price': str(ce.price)})
        customer_can_map[c.id] = entries

    from django.utils import timezone
    today = timezone.now().date()
    assignments = models.DeliveryAssignment.objects.filter(
        staff=me, delivery_date=today
    )
    pending_count = assignments.filter(status__in=['pending', 'in_progress']).count()
    done_count = assignments.filter(status='done').count()
    total = assignments.count()

    return render(request, "record_delivery.html", {
        "customers": customers,
        "can_types": can_types,
        'customer_can_map': customer_can_map,
        'me': me,
        'today': today,
        'pending_count': pending_count,
        'done_count': done_count,
        'total': total,
    })



from accounts.decorators import shop_admin_required


@login_required
def user_logout(request):
    logout(request)
    messages.success(request, _('Logged out successfully'))
    return redirect('login')


from accounts import models  # adjust import path as needed
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils.translation import gettext as _
import json


# Re-export constants so template can receive them via context
CURRENCY_CHOICES = [
    ('PKR', 'PKR - Pakistani Rupee'),
    ('INR', 'INR - Indian Rupee'),
    ('BDT', 'BDT - Bangladeshi Taka'),
    ('AED', 'AED - UAE Dirham'),
    ('SAR', 'SAR - Saudi Riyal'),
    ('QAR', 'QAR - Qatari Riyal'),
    ('KWD', 'KWD - Kuwaiti Dinar'),
    ('BHD', 'BHD - Bahraini Dinar'),
    ('OMR', 'OMR - Omani Rial'),
    ('USD', 'USD - US Dollar'),
]

COUNTRY_CHOICES = [
    ('PK', 'Pakistan'), ('IN', 'India'), ('BD', 'Bangladesh'),
    ('AE', 'UAE'), ('SA', 'Saudi Arabia'), ('QA', 'Qatar'),
    ('KW', 'Kuwait'), ('BH', 'Bahrain'), ('OM', 'Oman'),
]

DAYS_OF_WEEK = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

@login_required
def profile(request):
    """Show and edit profile and shop settings."""
    user = request.user
    shop = getattr(user, 'shop', None)

    if request.method == 'POST':
        # ── Personal / Account fields ──────────────────────────────────────
        user.first_name = request.POST.get('first_name') or user.first_name
        user.last_name  = request.POST.get('last_name')  or user.last_name
        user.email      = request.POST.get('email')      or user.email
        user.whatsapp_number = request.POST.get('whatsapp_number') or user.whatsapp_number

        # ── API Keys (JSON) ────────────────────────────────────────────────
        api_keys_raw = request.POST.get('api_keys', '').strip()
        if api_keys_raw:
            try:
                user.api_keys = json.loads(api_keys_raw)
            except (ValueError, TypeError):
                messages.error(request, _('API Keys field contains invalid JSON. Please fix it and try again.'))
                return redirect('profile')
        else:
            # Clear keys if field was emptied
            user.api_keys = None

        # ── WhatsApp API credentials ────────────────────────────────────────
        wa_phone_id = request.POST.get('meta_whatsapp_phone_number_id', '').strip()
        if wa_phone_id:
            user.meta_whatsapp_phone_number_id = wa_phone_id

        wa_token = request.POST.get('meta_whatsapp_access_token', '').strip()
        if wa_token:
            user.meta_whatsapp_access_token = wa_token

        # ── SMTP fields ────────────────────────────────────────────────────
        user.smtp_host       = request.POST.get('smtp_host', '').strip() or user.smtp_host
        user.smtp_from_email = request.POST.get('smtp_from_email', '').strip() or user.smtp_from_email
        user.smtp_username   = request.POST.get('smtp_username', '').strip() or user.smtp_username
        user.smtp_use_tls    = bool(request.POST.get('smtp_use_tls'))
        user.smtp_use_ssl    = bool(request.POST.get('smtp_use_ssl'))

        smtp_port_raw = request.POST.get('smtp_port', '').strip()
        if smtp_port_raw:
            try:
                user.smtp_port = int(smtp_port_raw)
            except ValueError:
                messages.error(request, _('Invalid SMTP port — must be a number.'))
                return redirect('profile')

        smtp_password = request.POST.get('smtp_password', '').strip()
        if smtp_password:
            user.smtp_password = smtp_password

        user.save()

        # ── Shop fields ────────────────────────────────────────────────────
        shop_name = request.POST.get('shop_name', '').strip()
        if shop_name:
            if not shop:
                shop = models.Shop.objects.create(name=shop_name, admin=user)
            else:
                shop.name = shop_name

        if shop:
            shop.phone_number       = request.POST.get('shop_phone', '').strip() or shop.phone_number
            shop.email              = request.POST.get('shop_email', '').strip() or None
            shop.description        = request.POST.get('description', '').strip() or ''
            shop.registration_number= request.POST.get('registration_number', '').strip() or ''
            shop.currency           = request.POST.get('currency') or shop.currency or 'PKR'
            shop.country            = request.POST.get('country')  or shop.country  or 'PK'
            shop.address            = request.POST.get('shop_address', '').strip() or ''
            shop.city               = request.POST.get('city', '').strip() or 'Karachi'
            shop.is_active          = bool(request.POST.get('is_active'))
            shop.opening_time       = request.POST.get('opening_time') or None
            shop.closing_time       = request.POST.get('closing_time') or None

            # GPS coordinates
            lat_raw = request.POST.get('latitude', '').strip()
            lng_raw = request.POST.get('longitude', '').strip()
            if lat_raw and lng_raw:
                try:
                    shop.latitude  = float(lat_raw)
                    shop.longitude = float(lng_raw)
                except ValueError:
                    messages.error(request, _('Invalid GPS coordinates.'))
                    return redirect('profile')

            # Working days — multiple checkbox values
            working_days = request.POST.getlist('working_days')
            shop.working_days = working_days if working_days else []

            # Logo upload
            if request.FILES.get('logo'):
                # Delete old logo to save storage
                if shop.logo:
                    try:
                        shop.logo.delete(save=False)
                    except Exception:
                        pass
                shop.logo = request.FILES['logo']

            shop.save()

        messages.success(request, _('Profile and shop settings updated successfully.'))
        return redirect('profile')

    # ── GET — build context ────────────────────────────────────────────────
    working_days_list = shop.working_days if (shop and shop.working_days) else []
    # Normalise to list in case it's stored as something else
    if not isinstance(working_days_list, list):
        working_days_list = list(working_days_list)

    context = {
        'user': user,
        'shop': shop,
        'currency_choices': CURRENCY_CHOICES,
        'country_choices':  COUNTRY_CHOICES,
        'days_of_week':     DAYS_OF_WEEK,
        'working_days_list': working_days_list,
    }
    return render(request, 'accounts/profile.html', context)


@login_required
def add_opening_balance(request, customer_id):
    """Create a single opening CanTransaction for a customer."""
    admin_user = _resolve_admin_user_for_request(request)
    customer = get_object_or_404(models.Customer, id=customer_id, shop__admin=admin_user)
    if request.method != 'POST':
        return redirect('can_statement', customer_id=customer_id)

    try:
        opening_cans = int(request.POST.get('opening_cans', 0))
    except Exception:
        messages.error(request, 'Invalid opening cans value')
        return redirect('can_statement', customer_id=customer_id)

    exists = models.CanTransaction.objects.filter(customer=customer, admin=admin_user, transaction_type='OPENING').exclude(id=None)
    if exists.exists():
        messages.error(request, 'Opening balance already exists for this customer.')
        return redirect('can_statement', customer_id=customer_id)

    shop = getattr(admin_user, 'shop_admin', getattr(admin_user, 'shop', None))
    try:
        ct = models.CanTransaction(
            admin=admin_user,
            shop=shop,
            customer=customer,
            date=timezone.now().date(),
            full_cans_delivered=opening_cans,
            empty_cans_received=0,
            transaction_type='OPENING'
        )
        ct.save()
    except Exception as e:
        messages.error(request, f'Failed to add opening balance - {e}')
        return redirect('can_statement', customer_id=customer_id)

    messages.success(request, 'Opening balance added')
    return redirect('can_statement', customer_id=customer_id)


def _resolve_admin_user_for_request(request):
    """Return the shop admin (User) associated with the current request."""
    try:
        if getattr(request.user, 'role', None) == 'staff':
            st = models.Staff.objects.filter(user=request.user).select_related('admin').first()
            if st:
                return st.admin
    except Exception:
        pass
    return request.user


def can_statement(request, customer_id):
    admin_user = _resolve_admin_user_for_request(request)
    customer = get_object_or_404(models.Customer, id=customer_id, shop__admin=admin_user)
    qs = models.CanTransaction.objects.filter(customer=customer, admin=admin_user).order_by('date', 'id')

    # Filtering
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    min_bal = request.GET.get('min_balance')
    max_bal = request.GET.get('max_balance')
    search = request.GET.get('search')
    if date_from:
        try:
            qs = qs.filter(date__gte=date_from)
        except Exception:
            pass
    if date_to:
        try:
            qs = qs.filter(date__lte=date_to)
        except Exception:
            pass
    if min_bal:
        try:
            qs = qs.filter(balance_after_transaction__gte=int(min_bal))
        except Exception:
            pass
    if max_bal:
        try:
            qs = qs.filter(balance_after_transaction__lte=int(max_bal))
        except Exception:
            pass
    if search:
        try:
            qnum = int(search)
        except Exception:
            qnum = None
        qs = qs.filter(Q(date__icontains=search) | Q(full_cans_delivered__icontains=search) | Q(empty_cans_received__icontains=search) | Q(balance_after_transaction__icontains=search))

    transactions = qs.order_by('date', 'id')

    latest = qs.order_by('-date', '-id').first()
    pending = qs.aggregate(
        delivered=Sum('full_cans_delivered'),
        returned=Sum('empty_cans_received')
    )
    total_delivered = pending.get('delivered') or 0
    total_returned = pending.get('returned') or 0
    empty_pending = total_delivered - total_returned
    current_cans = empty_pending if (total_delivered or total_returned) else (latest.balance_after_transaction if latest else 0)
    transactions = qs.order_by('date', 'id')

    opening_exists = qs.filter(transaction_type='OPENING').exists()
    opening_amount = qs.filter(transaction_type='OPENING').aggregate(opening=Sum('full_cans_delivered'))['opening'] or 0
    extra_given = current_cans - opening_amount if current_cans - opening_amount > 0 else 0

    return render(request, 'accounts/can_statement.html', {
        'customer': customer,
        'transactions': transactions,
        'current_cans': current_cans,
        'empty_pending': empty_pending,
        'pending': pending,
        'opening_exists': opening_exists,
        'opening_amount': opening_amount,
        'extra_given': extra_given,
        'filters': {'date_from': date_from, 'date_to': date_to, 'min_balance': min_bal, 'max_balance': max_bal, 'search': search}
    })


@login_required
@require_POST
def test_smtp(request):
    """AJAX endpoint to test SMTP connection using current user's SMTP settings."""
    user = request.user
    host = getattr(user, 'smtp_host', None)
    port = getattr(user, 'smtp_port', None)
    username = getattr(user, 'smtp_username', None)
    password = getattr(user, 'smtp_password', None)
    use_tls = bool(getattr(user, 'smtp_use_tls', False))
    use_ssl = bool(getattr(user, 'smtp_use_ssl', False))

    if not host or not port:
        return JsonResponse({'ok': False, 'message': 'SMTP host and port are not configured on your profile.'}, status=400)

    try:
        import smtplib, ssl
        if use_ssl:
            context = ssl.create_default_context()
            server = smtplib.SMTP_SSL(host, port, timeout=10, context=context)
        else:
            server = smtplib.SMTP(host, port, timeout=10)
            server.ehlo()
            if use_tls:
                server.starttls(context=ssl.create_default_context())
        if username and password:
            server.login(username, password)
        server.quit()
        return JsonResponse({'ok': True, 'message': 'SMTP connection successful.'})
    except Exception as e:
        return JsonResponse({'ok': False, 'message': str(e)}, status=500)


from django.contrib.auth import authenticate, login
from django.conf import settings
from django.utils.translation import gettext as _


def loginUser(request):
    if request.method == 'POST':
        site_key = getattr(settings, 'RECAPTCHA_SITE_KEY', None)
        secret_key = getattr(settings, 'RECAPTCHA_SECRET_KEY', None)
        if secret_key:
            token = request.POST.get('g-recaptcha-response')
            if not token:
                messages.error(request, _('Please complete the reCAPTCHA'))
                return render(request, 'accounts/login.html', {'recaptcha_site_key': site_key})
            try:
                resp = requests.post('https://www.google.com/recaptcha/api/siteverify', data={
                    'secret': secret_key,
                    'response': token,
                    'remoteip': request.META.get('REMOTE_ADDR')
                }, timeout=5)
                result = resp.json()
            except Exception:
                messages.error(request, _('reCAPTCHA verification failed (network error)'))
                return render(request, 'accounts/login.html', {'recaptcha_site_key': site_key})
            if not result.get('success'):
                messages.error(request, _('reCAPTCHA verification failed'))
                return render(request, 'accounts/login.html', {'recaptcha_site_key': site_key})
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, _('Logged in successfully'))
            try:
                if user.role == 'shop_admin' and getattr(user, 'shop', None) is None:
                    shop = models.Shop.objects.create(name=f"{user.username}'s Shop", admin=user)
                    user.shop = shop
                    user.save()
            except Exception:
                pass
            print('Going to Role Redirect')
            return redirect('role_redirect')
        else:
            messages.error(request, _('Invalid username or password'))
            return render(request, 'accounts/login.html', {'recaptcha_site_key': getattr(settings, 'RECAPTCHA_SITE_KEY', None)})
    return render(request, 'accounts/login.html', {'recaptcha_site_key': getattr(settings, 'RECAPTCHA_SITE_KEY', None)})


def customer_dashboard(request):
    customer = models.Customer.objects.filter(user=request.user).first()
    if not customer:
        messages.error(request, "Customer account not found.")
        return redirect('login')
    if not customer.is_active:
        messages.error(request, "Your account is deactivated. Please contact the shop admin.")
        return redirect('login')
 
    invoices       = models.Invoice.objects.filter(customer=customer)
    total_invoices  = invoices.count()
    total_deliveries = models.DailyDelivery.objects.filter(customer=customer).count()
    shop_name       = customer.shop.name if customer.shop else "Water Supply Shop"
 
    context = {
        'customer':        customer,
        'invoices':        invoices,
        'total_invoices':  total_invoices,
        'total_deliveries': total_deliveries,
        'shop_name':       shop_name,
        'active_portal':   'overview',
    }
    return render(request, 'accounts/customer_portal_dashboard.html', context)


def customer_portal_invoices(request):
    customer = models.Customer.objects.filter(user=request.user).first()
    if not customer:
        return redirect('login')
    if not customer.is_active:
        messages.error(request, "Your account is deactivated. Please contact the shop admin.")
        return redirect('login')
 
    invoices        = models.Invoice.objects.filter(customer=customer)
    total_invoices  = invoices.count()
    paid_invoices   = invoices.filter(status='paid').count()
    partial_invoices = invoices.filter(status='partial').count()
    draft_invoices  = invoices.filter(status='draft').count()
 
    # Use get_effective_total so tax/discount are included correctly
    total_amount = sum(inv.get_effective_total() for inv in invoices)
 
    # Remaining = effective total - paid
    total_remaining = sum((inv.remaining or 0) for inv in invoices)
 
    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = (
        request.GET.get('mobile') == '1' or
        any(k in ua for k in ('mobile', 'android', 'iphone', 'phone', 'ios'))
    )
 
    context = {
        'customer':       customer,
        'invoices':       invoices,
        'total_invoices': total_invoices,
        'paid_invoices':  paid_invoices,
        'partial_invoices': partial_invoices,
        'draft_invoices': draft_invoices,
        'total_amount':   total_amount,
        'total_remaining': total_remaining,
        'active_portal':  'invoices',
    }
 
    template = 'accounts/customer_portal_invoices_mobile.html' if is_mobile else 'accounts/customer_portal_invoices.html'
    return render(request, template, context)
 


def customer_portal_payments(request):
    customer = models.Customer.objects.filter(user=request.user).first()
    if not customer:
        return redirect('login')
    if not customer.is_active:
        messages.error(request, "Your account is deactivated. Please contact the shop admin.")
        return redirect('login')
 
    payments            = models.Payment.objects.filter(payer_customer=customer).order_by('-paid_at')
    total_payments      = payments.count()
    completed_payments  = payments.filter(status='completed').count()
    pending_payments    = payments.filter(status='pending').count()
    total_amount        = payments.aggregate(total=Sum('amount'))['total'] or Decimal('0.00')
 
    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = (
        request.GET.get('mobile') == '1' or
        any(k in ua for k in ('mobile', 'android', 'iphone', 'phone', 'ios'))
    )
 
    context = {
        'customer':           customer,
        'payments':           payments,
        'total_payments':     total_payments,
        'completed_payments': completed_payments,
        'pending_payments':   pending_payments,
        'total_amount':       total_amount,
        'active_portal':      'payments',
    }
 
    template = 'accounts/customer_portal_payments_mobile.html' if is_mobile else 'accounts/customer_portal_payments.html'
    return render(request, template, context)



from django.db.models.functions import Coalesce, Concat

@login_required
def outstanding_can_balance_customer(request, customer_id):
    admin_user = _resolve_admin_user_for_request(request)
    customer = get_object_or_404(models.Customer, id=customer_id, shop__admin=admin_user)
    qs = models.CanTransaction.objects.filter(customer=customer, admin=admin_user).order_by('date', 'id')
    transactions = qs.order_by('date', 'id')
    final_balance = transactions.last().balance_after_transaction if transactions.exists() else 0
    return final_balance

from django.views.decorators.cache import never_cache

@shop_admin_required
@never_cache
def admin_dashboard(request):
    if not request.user.is_authenticated:
        return HttpResponse('Please Login to continue or contact administrator!')

    user  = request.user
    today = timezone.now().date()

    import calendar
    import json as _json
    from datetime import date

    customers_qs = models.Customer.objects.filter(shop__admin=user)

    deliveries_qs = (
        models.DailyDelivery.objects
        .filter(admin=user)
        .select_related('customer', 'staff')
    )

    payments_qs = (
        models.Payment.objects
        .filter(admin=user)
        .select_related('delivery')
    )

    invoices_qs = (
        models.Invoice.objects
        .filter(admin=user)
        .select_related('customer')
    )

    role = getattr(user, 'role', None)
    if role == 'staff':
        deliveries_qs = deliveries_qs.filter(staff__user=user)

    accrued_expr = ExpressionWrapper(
        F('quantity_delivered') * F('rate_given'),
        output_field=DecimalField(max_digits=14, decimal_places=2)
    )

    total_sale_expression = ExpressionWrapper(
        F('rate_given') * F('quantity_delivered'),
        output_field=DecimalField(max_digits=12, decimal_places=2)
    )

    total_customers   = customers_qs.count()
    todays_deliveries = deliveries_qs.filter(delivery_date=today).count()
    customers_goal    = models.Shop.objects.filter(admin=user).first().customer_limit if models.Shop.objects.filter(admin=user).exists() else 0
    percent_customers = min(100, int((total_customers / customers_goal) * 100)) if customers_goal > 0 else 0

    month_filter = {
        'delivery_date__year':  today.year,
        'delivery_date__month': today.month,
    }

    monthly_accrued = (
        deliveries_qs
        .filter(**month_filter)
        .aggregate(total=Sum(accrued_expr))['total']
        or Decimal('0.00')
    )

    monthly_cash_received = (
        payments_qs
        .filter(
            paid_at__year=today.year,
            paid_at__month=today.month,
            status='completed',
            is_subscription_payment=False,
            delivery__delivery_date__year=today.year or 0,
            delivery__delivery_date__month=today.month or 0,
            invoice__created_at__year=today.year or 0,
            invoice__created_at__month=today.month or 0
        )
        .aggregate(total=Sum('amount'))['total']
        or Decimal('0.00')
    )

    try:
        received_total = (
            payments_qs
            .filter(status='completed', is_subscription_payment=False)
            .aggregate(total=Sum('amount'))['total']
            or Decimal('0.00')
        )
    except Exception:
        received_total = (
            payments_qs
            .filter(status='completed')
            .aggregate(total=Sum('amount'))['total']
            or Decimal('0.00')
        )

    latest_can = (
        models.CanTransaction.objects
        .filter(admin=user, customer=OuterRef('customer'))
        .order_by('-date', '-id')
    )

    outstanding_cans = (
        models.CanTransaction.objects
        .filter(id=Subquery(latest_can.values('id')[:1]))
        .aggregate(total=models.Sum('balance_after_transaction'))['total']
        or 0
    )

    total_cans = (
        deliveries_qs
        .filter(
            delivery_date__year=today.year,
            delivery_date__month=today.month
        )
        .aggregate(total=Sum('quantity_delivered'))['total']
        or 0
    )

    deliveries_qs_current_year = deliveries_qs.filter(delivery_date__year=today.year)
    total_sales_current_year = deliveries_qs_current_year.aggregate(total=Sum((F('quantity_delivered') * F('rate_given'))))['total'] or Decimal('0.00')
    total_sales = deliveries_qs.aggregate(total=Sum((F('quantity_delivered') * F('rate_given'))))['total'] or Decimal('0.00')

    total_receivable = get_total_receivable(admin_user=user, active_only=False)

    past_two = []
    for offset in (2, 1):
        y, m = today.year, today.month
        for _ in range(offset):
            m -= 1
            if m < 1:
                m = 12
                y -= 1
        past_two.append({
            'label': date(y, m, 1).strftime('%b %Y'),
            'value': f"{y}-{m:02d}",
        })

    default_month = past_two[1]['value'] if len(past_two) >= 2 else (past_two[0]['value'] if past_two else None)

    monthly_sales = (
        deliveries_qs
        .annotate(
            total_sale=total_sale_expression,
            month=TruncMonth('delivery_date')
        )
        .values('month')
        .annotate(total=Sum('total_sale'))
        .order_by('month')
    )

    months         = [r['month'].strftime('%b %Y') for r in monthly_sales]
    monthly_totals = [float(r['total']) for r in monthly_sales]

    distinct_years = sorted(set(
        deliveries_qs
        .values_list('delivery_date__year', flat=True)
        .distinct()
    ))

    all_years_monthly = {}
    for yr in distinct_years:
        yr_monthly = (
            deliveries_qs
            .filter(delivery_date__year=yr)
            .annotate(
                total_sale=total_sale_expression,
                month=TruncMonth('delivery_date')
            )
            .values('month')
            .annotate(total=Sum('total_sale'))
            .order_by('month')
        )

        yr_months  = [r['month'].strftime('%b %Y') for r in yr_monthly]
        yr_totals  = [float(r['total']) for r in yr_monthly]

        prev_by_month = {
            r['month'].month: float(r['total'])
            for r in (
                deliveries_qs
                .filter(delivery_date__year=yr - 1)
                .annotate(
                    total_sale=total_sale_expression,
                    month=TruncMonth('delivery_date')
                )
                .values('month')
                .annotate(total=Sum('total_sale'))
                .order_by('month')
            )
        }

        prev_totals = [prev_by_month.get(r['month'].month, None) for r in yr_monthly]

        all_years_monthly[str(yr)] = {
            'label':       str(yr),
            'months':      yr_months,
            'totals':      yr_totals,
            'prev_totals': prev_totals,
        }

    daily_sales = (
        deliveries_qs
        .annotate(
            total_sale=total_sale_expression,
            day=TruncDay('delivery_date')
        )
        .values('day')
        .annotate(total=Sum('total_sale'))
        .order_by('day')
    )

    days         = [r['day'].strftime('%d %b') for r in daily_sales]
    daily_totals = [float(r['total']) for r in daily_sales]

    staff_sales = (
        deliveries_qs
        .annotate(total_sale=total_sale_expression)
        .values('staff__last_name')
        .annotate(total=Sum('total_sale'))
        .order_by('-total')
    )

    staff_names  = [r['staff__last_name'] or 'Admin' for r in staff_sales]
    staff_totals = [float(r['total']) for r in staff_sales]

    monthly_data = (
        deliveries_qs
        .annotate(
            total_sale=total_sale_expression,
            month=TruncMonth('delivery_date')
        )
        .values('month')
        .annotate(
            revenue=Sum(total_sale_expression),
            total_delivered=Sum('quantity_delivered'),
            total_empty=Sum('empty_cans_received'),
        )
        .order_by('month')
    )

    months         = [r['month'].strftime('%b %Y') for r in monthly_data]
    revenue_data   = [float(r['revenue']       or 0) for r in monthly_data]
    delivered_data = [int(r['total_delivered'] or 0) for r in monthly_data]
    empty_data     = [int(r['total_empty']     or 0) for r in monthly_data]

    delivery_revenue = (
        deliveries_qs
        .annotate(
            customer_name=Concat('customer__first_name', Value(' '), 'customer__last_name')
        )
        .values('customer_id', 'customer_name')
        .annotate(revenue=Coalesce(Sum(total_sale_expression), Decimal('0')))
    )

    invoice_revenue = (
        invoices_qs
        .annotate(
            customer_name=Concat('customer__first_name', Value(' '), 'customer__last_name')
        )
        .values('customer_id', 'customer_name')
        .annotate(revenue=Coalesce(Sum('total_amount'), Decimal('0')))
    )

    revenue_dict = defaultdict(lambda: 0)
    for row in delivery_revenue:
        revenue_dict[row['customer_name']] += row['revenue']
    for row in invoice_revenue:
        revenue_dict[row['customer_name']] += row['revenue']

    sorted_customers = sorted(revenue_dict.items(), key=lambda x: x[1], reverse=True)[:10]

    customer_labels = [r[0]        for r in sorted_customers]
    customer_totals = [float(r[1]) for r in sorted_customers]
    top_customers   = [{'label': r[0], 'total': float(r[1])} for r in sorted_customers[:3]]

    available_months = []
    for i in range(12):
        y, m = today.year, today.month - i
        while m < 1:
            m += 12
            y -= 1
        available_months.append({
            'label': date(y, m, 1).strftime('%b %Y'),
            'value': f"{y}-{m:02d}",
            'year':  y,
            'month': m,
        })

    all_months_daily = {}
    for mo in available_months:
        _y, _m         = mo['year'], mo['month']
        _days_in_month = calendar.monthrange(_y, _m)[1]

        _qs = (
            deliveries_qs
            .filter(delivery_date__year=_y, delivery_date__month=_m)
            .annotate(
                total_sale=total_sale_expression,
                day=TruncDay('delivery_date')
            )
            .values('day')
            .annotate(total=Sum('total_sale'))
            .order_by('day')
        )

        _dict = {row['day'].day: float(row['total']) for row in _qs}

        _days_range = (
            range(1, today.day + 1)
            if (_y == today.year and _m == today.month)
            else range(1, _days_in_month + 1)
        )

        all_months_daily[f"{_y}-{_m:02d}"] = {
            'days':   [str(d)          for d in _days_range],
            'totals': [_dict.get(d, 0) for d in _days_range],
            'label':  mo['label'],
        }

    prev_month_date   = today.replace(day=1) - timedelta(days=1)
    current_month_key = f"{today.year}-{today.month:02d}"
    prev_month_key    = f"{prev_month_date.year}-{prev_month_date.month:02d}"

    active_customers = (
        customers_qs
        .filter(deliveries__delivery_date__gte=today - timedelta(days=30))
        .distinct()
        .count()
    )

    week_start = today - timedelta(days=today.weekday())

    weekly_deliveries = (
        deliveries_qs
        .filter(delivery_date__gte=week_start, delivery_date__lte=today)
        .aggregate(total=Sum('quantity_delivered'))['total']
        or 0
    )

    recent_deliveries = deliveries_qs.order_by('-delivery_date')[:10]
    recent_invoices   = invoices_qs.order_by('-created_at')[:10]
    recent_payments   = payments_qs.order_by('-created_at')[:10]

    try:
        can_types = models.CanType.objects.filter(admin=user, enabled=True)
    except Exception:
        can_types = []

    ua_string  = request.META.get('HTTP_USER_AGENT', 'Unknown')
    ip_address = request.META.get('HTTP_X_FORWARDED_FOR', request.META.get('REMOTE_ADDR', 'Unknown'))
    if ',' in ip_address:
        ip_address = ip_address.split(',')[0].strip()

    ua_lower = ua_string.lower()

    if 'iphone' in ua_lower or 'ipod' in ua_lower:
        device_type, device_icon, device_color = 'iPhone',         'fas fa-mobile',          'text-success'
    elif 'ipad' in ua_lower:
        device_type, device_icon, device_color = 'iPad',           'fas fa-tablet',          'text-info'
    elif 'android' in ua_lower:
        device_type, device_icon, device_color = 'Android Device', 'fas fa-mobile',          'text-warning'
    elif 'windows' in ua_lower:
        device_type, device_icon, device_color = 'Windows PC',     'fas fa-desktop',         'text-primary'
    elif 'macintosh' in ua_lower or 'mac os' in ua_lower:
        device_type, device_icon, device_color = 'Mac',            'fas fa-apple',           'text-dark'
    elif 'linux' in ua_lower:
        device_type, device_icon, device_color = 'Linux',          'fas fa-linux',           'text-secondary'
    else:
        device_type, device_icon, device_color = 'Unknown Device', 'fas fa-question-circle', 'text-muted'

    if 'edge' in ua_lower or 'edg/' in ua_lower:
        browser_type, browser_icon = 'Microsoft Edge',    'fab fa-edge'
    elif 'firefox' in ua_lower:
        browser_type, browser_icon = 'Firefox',           'fab fa-firefox'
    elif 'safari' in ua_lower and 'chrome' not in ua_lower:
        browser_type, browser_icon = 'Safari',            'fab fa-safari'
    elif 'chrome' in ua_lower:
        browser_type, browser_icon = 'Google Chrome',     'fab fa-chrome'
    elif 'opera' in ua_lower or 'opr/' in ua_lower:
        browser_type, browser_icon = 'Opera',             'fab fa-opera'
    elif 'trident' in ua_lower or 'msie' in ua_lower:
        browser_type, browser_icon = 'Internet Explorer', 'fab fa-internet-explorer'
    else:
        browser_type, browser_icon = 'Unknown Browser',   'fas fa-globe'

    # ── New P&L + summary metrics ─────────────────────────────

    # Salary: monthly proportion (annual / 12) so it's comparable to monthly revenue
    total_salary_expense = (
        models.Staff.objects.filter(admin=user)
        .aggregate(total=Sum('salary'))['total'] or Decimal('0')
    )
    # Salary is typically a monthly figure already — but if yours is stored as
    # a monthly amount, use it directly. If annual, divide by 12:
    # total_salary_expense = total_salary_expense / 12

    # Overdue: unpaid invoices older than 30 days (amount still outstanding)
    overdue_cutoff = today - timedelta(days=30)
    overdue_receivables = (
        invoices_qs
        .exclude(status='paid')
        .filter(created_at__date__lte=overdue_cutoff)
        .aggregate(total=Sum('total_amount'))['total'] or Decimal('0')
    )

    # Inventory value
    try:
        from inventory.models import InventoryItem
        from django.db.models import F as _F, ExpressionWrapper as _EW, DecimalField as _DC
        inventory_value = (
            InventoryItem.objects.filter(admin=user, is_active=True)
            .annotate(val=_EW(_F('current_stock') * _F('avg_unit_cost'), output_field=_DC()))
            .aggregate(total=Sum('val'))['total'] or Decimal('0')
        )
    except Exception:
        inventory_value = Decimal('0')

    # Collection rate: THIS MONTH payments vs THIS MONTH accrued (apples-to-apples)
    collection_rate = (
        round(float(monthly_cash_received) / float(monthly_accrued) * 100, 1)
        if monthly_accrued > 0 else 0
    )
    # Cap at 100% (advance payments can push it over)
    collection_rate = min(collection_rate, 100.0)

    # Avg revenue per active customer this month
    active_count = customers_qs.filter(is_active=True).count()
    avg_revenue_per_customer = (
        round(float(monthly_accrued) / active_count, 0)
        if active_count > 0 else 0
    )

    # Gross profit = this month revenue - this month salary expense
    # (salary is already a monthly figure in your Staff model)
    total_expenses = total_salary_expense
    gross_profit = monthly_accrued - total_expenses
    # Clamp to 0 if negative (means salaries exceed revenue — show 0, not negative)
    gross_profit_display = max(gross_profit, Decimal('0'))
    net_profit = gross_profit  # expand later when you add overhead/purchases
    net_profit_display = max(net_profit, Decimal('0'))

    profit_margin = (
        round(float(net_profit) / float(monthly_accrued) * 100, 1)
        if monthly_accrued > 0 and net_profit > 0 else 0
    )

    # Delivery success rate today
    todays_assignments = models.DeliveryAssignment.objects.filter(admin=user, delivery_date=today)
    ta_total = todays_assignments.count()
    delivery_success_rate = (
        round(todays_assignments.filter(status='done').count() / ta_total * 100, 1)
        if ta_total > 0 else 0
    )

    context = {
        'customers_limit':          customers_goal,
        'total_customers':          total_customers,
        'todays_deliveries':        todays_deliveries,
        'percent_customers':        percent_customers,
        'total_cans':               total_cans,
        'outstanding_cans':         outstanding_cans,
        'active_customers':         active_customers,
        'weekly_deliveries':        weekly_deliveries,
        'total_active_customers':   customers_qs.filter(is_active=True).count(),
        'total_inactive_customers': customers_qs.filter(is_active=False).count(),
        'monthly_accrued_revenue':    monthly_accrued,
        'monthly_cash_revenue':       monthly_cash_received,
        'remaining_monthly_payments': monthly_accrued - monthly_cash_received,
        'received_total':             received_total,
        'total_sales':                float(total_sales),
        'total_sales_current_year':   float(total_sales_current_year),
        'total_receivable':           total_receivable,
        'unpaid_amount': (
            invoices_qs
            .exclude(status='paid')
            .aggregate(total=Sum('total_amount'))['total']
            or Decimal('0')
        ),
        'past_two_months': past_two,
        'default_month':   default_month,
        'recent_deliveries': recent_deliveries,
        'recent_invoices':   recent_invoices,
        'recent_payments':   recent_payments,
        'months':         months,
        'revenue_data':   revenue_data,
        'delivered_data': delivered_data,
        'empty_data':     empty_data,
        'monthly_totals': monthly_totals,
        'all_years_monthly': _json.dumps(all_years_monthly),
        'days':         days,
        'daily_totals': daily_totals,
        'staff_names':  _json.dumps(staff_names),
        'staff_totals': _json.dumps(staff_totals),
        'customer_labels': _json.dumps(customer_labels),
        'customer_totals': _json.dumps(customer_totals),
        'top_customers':   top_customers,
        'all_months_daily':  _json.dumps(all_months_daily),
        'available_months':  available_months,
        'current_month_key': current_month_key,
        'prev_month_key':    prev_month_key,
        'staff_list': models.Staff.objects.filter(admin=user),
        'customers':  models.Customer.objects.filter(shop__admin=user),
        'can_types':  can_types,
        'now':        timezone.now(),
        'user_session': {
            'user_name':    f"{user.first_name} {user.last_name}".strip() or user.username,
            'ip_address':   ip_address,
            'device_type':  device_type,
            'device_icon':  device_icon,
            'device_color': device_color,
            'browser_type': browser_type,
            'browser_icon': browser_icon,
            'user_agent':   ua_string,
            'login_time':   timezone.now(),
        },
        'shop': models.Shop.objects.filter(admin=user).first(),
    }
    context.update({
        'total_salary_expense':     total_salary_expense,
        'overdue_receivables':      overdue_receivables,
        'inventory_value':          inventory_value,
        'collection_rate':          collection_rate,
        'avg_revenue_per_customer': avg_revenue_per_customer,
        'gross_profit':             gross_profit_display,
        'net_profit':               net_profit_display,
        'profit_margin':            profit_margin,
        'total_expenses':           total_expenses,
        'delivery_success_rate':    delivery_success_rate,
    })

    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = (
        request.GET.get('mobile') == '1' or
        any(k in ua for k in ('mobile', 'android', 'iphone', 'ipad', 'phone', 'ios'))
    )

    template  = 'accounts/admin_dashboard_mobile.html' if is_mobile else 'accounts/admin_dashboard.html'
    cache_key = f"dashboard_{user.id}"

    cached = cache.get(cache_key)
    if cached:
        cached['todays_deliveries'] = models.DailyDelivery.objects.filter(
            admin=user, delivery_date=today
        ).count()
        cached['monthly_cash_revenue'] = (
            payments_qs
            .filter(
                paid_at__year=today.year,
                paid_at__month=today.month,
                status='completed',
                is_subscription_payment=False,
            )
            .aggregate(total=Sum('amount'))['total']
            or Decimal('0.00')
        )
        cached['shop'] = models.Shop.objects.filter(admin=user).first()
        return render(request, template, cached)

    cache.set(cache_key, context, 60 * 5)
    return render(request, template, context)


# ─────────────────────────────────────────────────────────────────────────────
# Invoicing helpers
# ─────────────────────────────────────────────────────────────────────────────
from decimal import Decimal
from django.db import transaction, IntegrityError
from django.contrib import messages
from django.utils.translation import gettext as _
from django.utils import timezone
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from django.db.models import Sum, Q
from accounts import models


def _build_invoice_context(invoice):
    """
    Build the template context for invoice_detail, invoice_pdf, and send_invoice.
 
    Key fix — discount double-counting:
      The original code added flat_discount to total_discount AND subtracted it
      from calc_total, then used invoice.total_amount (which _recompute_summary
      had ALREADY deducted flat_discount from) as display_total.  This caused
      the flat discount to appear twice in the breakdown.
 
    Correct approach:
      - Use Invoice's cached summary columns (subtotal, total_discount,
        total_tax, total_amount) as the authoritative source.  These are kept
        in sync by Invoice.save() → _recompute_summary().
      - Per-item gross/discount/tax are recalculated for display only (they
        don't touch the invoice total).
      - paid_total and remaining are computed fresh from Payment records.
    """
    from accounts import models
    from django.apps import apps
 
    items = invoice.items.all().select_related('delivery', 'delivery__can_type')
    customer = invoice.customer
 
    # ── Per-item display values ───────────────────────────────────────────
    items_with_paid = []
    for it in items:
        # Recalculate line totals from current pricing rules (display only;
        # save() persists them so repeated calls are idempotent)
        try:
            totals = models.compute_line_totals(it.quantity, it.unit_price, customer)
            needs_save = (
                it.gross_amount    != totals['gross']    or
                it.discount_amount != totals['discount'] or
                it.tax_amount      != totals['tax']      or
                it.line_total      != totals['net']
            )
            if needs_save:
                models.InvoiceItem.objects.filter(pk=it.pk).update(
                    gross_amount    = totals['gross'],
                    discount_amount = totals['discount'],
                    tax_amount      = totals['tax'],
                    line_total      = totals['net'],
                )
                it.gross_amount    = totals['gross']
                it.discount_amount = totals['discount']
                it.tax_amount      = totals['tax']
                it.line_total      = totals['net']
            it.net_before_tax = totals['after_disc']
        except Exception:
            it.net_before_tax = (
                (it.gross_amount or Decimal('0')) -
                (it.discount_amount or Decimal('0'))
            )
 
        # Per-line payment status
        paid_for_item = Decimal('0')
        try:
            if it.delivery_id:
                paid_for_item = (
                    models.Payment.objects
                    .filter(status='completed', delivery_id=it.delivery_id)
                    .aggregate(total=Sum('amount'))['total'] or Decimal('0')
                )
        except Exception:
            pass
 
        line_total = it.line_total or Decimal('0')
        if line_total > 0 and paid_for_item >= line_total:
            row_status = 'paid'
        elif paid_for_item > 0:
            row_status = 'partial'
        else:
            row_status = 'unpaid'
 
        items_with_paid.append({
            'item':   it,
            'paid':   paid_for_item,
            'status': row_status,
        })
 
    # ── Invoice-level totals (from cached summary — single source of truth) ─
    # Prefer invoice cached columns; fall back to summing items if not yet set.
    cached_subtotal  = invoice.subtotal       or Decimal('0')
    cached_discount  = invoice.total_discount or Decimal('0')
    cached_tax       = invoice.total_tax      or Decimal('0')
    cached_total     = invoice.total_amount   or Decimal('0')
 
    items_gross   = sum(i['item'].gross_amount    or Decimal('0') for i in items_with_paid)
    items_disc    = sum(i['item'].discount_amount or Decimal('0') for i in items_with_paid)
    items_tax     = sum(i['item'].tax_amount      or Decimal('0') for i in items_with_paid)
    items_net     = sum(i['item'].line_total      or Decimal('0') for i in items_with_paid)
 
    # Flat discount applied at invoice level (customer-level discount, not per-line)
    flat_discount = Decimal('0')
    if customer:
        try:
            flat_discount = Decimal(str(getattr(customer, 'discount_flat', Decimal('0')) or 0))
        except Exception:
            flat_discount = Decimal('0')
 
    # Use cached columns when available; recompute when invoice hasn't been
    # through _recompute_summary yet (e.g. very old records).
    if items_gross > Decimal('0'):
        subtotal       = items_gross
        total_discount = items_disc + flat_discount  # per-line + flat
        total_tax      = items_tax
        # Net = sum of line nets − flat discount (flat isn't in line_total)
        display_total  = max(items_net - flat_discount, Decimal('0'))
    elif cached_total > Decimal('0'):
        # Old invoice with no items — use stored values
        subtotal       = cached_subtotal
        total_discount = cached_discount
        total_tax      = cached_tax
        display_total  = cached_total
    else:
        subtotal       = Decimal('0')
        total_discount = Decimal('0')
        total_tax      = Decimal('0')
        display_total  = Decimal('0')
 
    # ── Payments ──────────────────────────────────────────────────────────
    delivery_ids = invoice.get_delivery_ids()
    payments = (
        models.Payment.objects
        .filter(Q(invoice=invoice) | Q(delivery_id__in=delivery_ids))
        .distinct()
        .order_by('-created_at')
    )
    paid_total = (
        payments.filter(status='completed')
        .aggregate(total=Sum('amount'))['total'] or Decimal('0')
    )
    remaining = max(display_total - paid_total, Decimal('0'))
 
    # ── Status ────────────────────────────────────────────────────────────
    if display_total == Decimal('0'):
        computed_status = 'paid' if (paid_total > 0 or invoice.status == 'paid') else 'unpaid'
    elif paid_total >= display_total:
        computed_status = 'paid'
    elif paid_total > Decimal('0'):
        computed_status = 'partial'
    else:
        computed_status = 'unpaid'
 
    try:
        status_map              = dict(models.Invoice.STATUS_CHOICES)
        computed_status_display = status_map.get(computed_status, computed_status.title())
    except Exception:
        computed_status_display = computed_status.title()
 
    # ── Customer discount / tax flags (for template conditionals) ─────────
    has_discount = bool(
        (getattr(customer, 'discount_percent', Decimal('0')) or Decimal('0')) > 0
        or flat_discount > 0
    ) if customer else False
 
    has_tax = bool(
        not getattr(customer, 'is_tax_exempt', True)
        and (getattr(customer, 'tax_rate', Decimal('0')) or Decimal('0')) > 0
    ) if customer else False
 
    return {
        'invoice':                invoice,
        'items':                  items,
        'items_with_paid':        items_with_paid,
        'payments':               payments,
 
        # ── Totals (non-overlapping, consistent breakdown) ─────────────────
        'subtotal':               subtotal,        # gross before any deductions
        'total_discount':         total_discount,  # per-line disc + flat disc
        'total_tax':              total_tax,        # tax after discount
        'display_total':          display_total,    # what the customer owes
        'gross_payable':          display_total,    # alias used in some templates
        'paid_amount':            paid_total,
        'net_payable':            remaining,
        'remaining':              remaining,
 
        # Row counts
        'total_qty': sum(
            float(i['item'].quantity or 0) for i in items_with_paid
        ),
 
        # ── Status ────────────────────────────────────────────────────────
        'computed_status':        computed_status,
        'computed_status_display':computed_status_display,
 
        # ── Customer pricing flags ─────────────────────────────────────────
        'has_discount':           has_discount,
        'has_tax':                has_tax,
        'customer_discount_pct':  getattr(customer, 'discount_percent',  Decimal('0')),
        'customer_discount_flat': flat_discount,
        'customer_tax_rate':      getattr(customer, 'tax_rate',          Decimal('0')),
        'customer_tax_exempt':    getattr(customer, 'is_tax_exempt',     True),
    }

# ─────────────────────────────────────────────────────────────────────────────
# HELPER — create InvoiceItems for a queryset of deliveries
# ─────────────────────────────────────────────────────────────────────────────

def _attach_deliveries_to_invoice(invoice, deliveries):
    """
    Create InvoiceItem rows for each delivery attached to *invoice*.
    Uses compute_line_totals so discount + tax from the customer settings
    are applied per line automatically (InvoiceItem.save() calls it too,
    but we set them explicitly here for clarity).

    Returns: Decimal — net total of all lines.
    """
    total = Decimal('0')
    customer = invoice.customer

    for d in deliveries:
        try:
            cust_ct = models.CustomerCanType.objects.get(customer=customer, can_type=d.can_type)
            unit_price = Decimal(str(cust_ct.price))
        except Exception:
            unit_price = Decimal(str(
                getattr(d, 'rate_given', None)
                or getattr(d.can_type, 'price', 0)
                or 0
            ))

        qty = Decimal(str(d.quantity_delivered or 0))

        item = models.InvoiceItem(
            invoice=invoice,
            delivery=d,
            description=f"Delivery #{d.id} on {d.delivery_date}",
            quantity=qty,
            unit_price=unit_price,
        )
        item.save()
        total += item.line_total

    return total


@login_required
def recent_activities(request):
    """Return a small JSON array of recent admin/staff activities for the topbar dropdown."""
    try:
        admin_user = _resolve_admin_user_for_request(request)
        deliveries = models.DailyDelivery.objects.filter(admin=admin_user).select_related('customer', 'staff').order_by('-created_at')[:8]
        payments = models.Payment.objects.filter(admin=admin_user).select_related('payer_customer').order_by('-created_at')[:8]
        invoices = models.Invoice.objects.filter(admin=admin_user).order_by('-created_at')[:8]

        items = []
        for d in deliveries:
            actor = (d.staff.first_name + ' ' + d.staff.last_name) if getattr(d, 'staff', None) else (getattr(d.admin, 'first_name', '') or d.admin.username)
            cust = d.customer.display_name if getattr(d, 'customer', None) else 'Customer'
            txt = f"{actor}: Delivered {int(d.quantity_delivered or 0)} cans to {cust}"
            meta = f"{(timezone.now() - d.created_at).days}d ago" if getattr(d, 'created_at', None) else ''
            items.append({'text': txt, 'meta': meta, 'ts': d.created_at or timezone.now()})

        for p in payments:
            payer = p.payer_customer.display_name if getattr(p, 'payer_customer', None) else (p.transaction_id or 'Payment')
            txt = f"Payment: {p.amount} — {payer}"
            meta = f"{(timezone.now() - p.created_at).days}d ago" if getattr(p, 'created_at', None) else ''
            items.append({'text': txt, 'meta': meta, 'ts': p.created_at or timezone.now()})

        for inv in invoices:
            cust_name = inv.customer.display_name if getattr(inv, 'customer', None) else 'Customer'
            txt = f"Invoice {inv.invoice_number} — {cust_name}"
            meta = f"{(timezone.now() - inv.created_at).days}d ago" if getattr(inv, 'created_at', None) else ''
            items.append({'text': txt, 'meta': meta, 'ts': inv.created_at or timezone.now()})

        items_sorted = sorted(items, key=lambda x: x.get('ts', timezone.now()), reverse=True)[:12]
        out = [{'text': it['text'], 'meta': it['meta']} for it in items_sorted]
        return JsonResponse(out, safe=False)
    except Exception:
        return JsonResponse([], safe=False)


@shop_admin_required
def view_bill_home(request):
    user = User.objects.filter(username=request.user.username).first()
    customers = models.Customer.objects.filter(shop__admin=user)
    context = {
        "customers": customers,
    }
    return render(request, 'view_bill.html', context)


@shop_admin_required
def generate_bill(request, customer_id):
    """Generates an Invoice for a customer for a custom date range using _attach_deliveries_to_invoice."""
    start_date = request.POST.get("start_date")
    end_date = request.POST.get("end_date")
    customer = get_object_or_404(models.Customer, id=customer_id)

    try:
        start = timezone.datetime.fromisoformat(start_date).date()
        end = timezone.datetime.fromisoformat(end_date).date()
    except Exception:
        messages.error(request, _('Invalid dates provided'))
        return redirect('view_bill')

    deliveries = models.DailyDelivery.objects.filter(
        customer=customer,
        delivery_date__gte=start,
        delivery_date__lte=end
    ).order_by('created_at')

    invoice_number = f"INV-CUSTOM-{timezone.now().strftime('%Y%m%d%H%M%S')}-{customer.id}"
    try:
        invoice = models.Invoice.objects.create(
            invoice_number=invoice_number,
            admin=request.user,
            shop=getattr(request.user, 'shop', None),
            customer=customer,
            total_amount=0,
            status='unpaid',
            invoice_year=start.year,
            invoice_month=start.month,
        )
    except IntegrityError:
        messages.error(request, _('Invoice for this customer and month already exists'))
        return redirect('view_bill')

    # FIX: use _attach_deliveries_to_invoice so discount + tax are applied
    net_total = _attach_deliveries_to_invoice(invoice, deliveries)
    invoice.total_amount = net_total
    invoice.save()

    messages.success(request, _('Custom date invoice created.'))
    return redirect('invoice_detail', invoice_id=invoice.id)


@login_required
def role_redirect(request):
    role = getattr(request.user, 'role', None)
    
    # Check if user has a customer record - if so, they're a customer regardless of role
    try:
        customer = models.Customer.objects.filter(user=request.user).first()
        if customer:
            return redirect("customer_portal")
    except Exception:
        pass
    
    if role == "staff":
        return redirect("record_delivery")          # riders go here
    elif role == "shop_admin":
        return redirect("admin_dashboard")
    elif role == "super_admin":
        return redirect("/administration-panel/")
    elif role == "customer":
        return redirect("customer_portal")          # ← was falling through to login
    return redirect("login")


@shop_admin_required
def invoices_list(request):
    user = request.user
    qs = models.Invoice.objects.filter(admin=user).annotate(date_from=Min('items__delivery__delivery_date'), date_to=Max('items__delivery__delivery_date')).order_by('-created_at')
    invoices_with_meta = []
    from datetime import date as _date
    for inv in qs:
        if getattr(inv, 'invoice_year', None) and getattr(inv, 'invoice_month', None):
            try:
                month_label = _date(inv.invoice_year, inv.invoice_month, 1).strftime('%b %Y')
            except Exception:
                month_label = ''
        else:
            if getattr(inv, 'date_from', None) and getattr(inv, 'date_to', None):
                if inv.date_from == inv.date_to:
                    month_label = inv.date_from.strftime('%d %b %Y')
                else:
                    month_label = f"{inv.date_from.strftime('%d %b %Y')} - {inv.date_to.strftime('%d %b %Y')}"
            else:
                month_label = ''

        date_range = ''
        if getattr(inv, 'invoice_year', None) and getattr(inv, 'invoice_month', None):
            try:
                import calendar
                start = _date(inv.invoice_year, inv.invoice_month, 1)
                last_day = calendar.monthrange(inv.invoice_year, inv.invoice_month)[1]
                end = _date(inv.invoice_year, inv.invoice_month, last_day)
                date_range = f"{start.strftime('%d %b %Y')} - {end.strftime('%d %b %Y')}"
            except Exception:
                date_range = ''
        elif getattr(inv, 'date_from', None) and getattr(inv, 'date_to', None):
            date_range = f"{inv.date_from.strftime('%d %b %Y')} - {inv.date_to.strftime('%d %b %Y')}"

        try:
            paid_total = inv.get_paid_total()
        except Exception:
            paid_total = inv.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')

        try:
            items_total = sum((it.line_total or Decimal('0')) for it in inv.items.all())
            stored_total = inv.total_amount or Decimal('0')
            if stored_total == Decimal('0') and items_total > Decimal('0'):
                display_total = items_total
            else:
                display_total = stored_total
        except Exception:
            display_total = inv.total_amount or Decimal('0')

        if display_total == Decimal('0'):
            if paid_total > Decimal('0'):
                computed_status = 'paid'
            elif inv.status == 'paid':
                computed_status = 'paid'
            else:
                computed_status = 'unpaid'
        else:
            if paid_total >= display_total:
                computed_status = 'paid'
            elif paid_total > Decimal('0'):
                computed_status = 'partial'
            else:
                computed_status = 'unpaid'

        try:
            inv.status = computed_status
            remaining = (display_total or Decimal('0')) - (paid_total or Decimal('0'))
            if remaining < Decimal('0'):
                remaining = Decimal('0')
            inv.display_total = remaining
            inv.gross_payable = display_total
            inv.paid_amount = paid_total
            inv.net_payable = remaining
        except Exception:
            pass

        invoices_with_meta.append({'invoice': inv, 'month_label': month_label, 'date_from': getattr(inv, 'date_from', None), 'date_to': getattr(inv, 'date_to', None), 'date_range': date_range})

    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = request.GET.get('mobile') == '1' or any(k in ua for k in ('mobile', 'android', 'iphone', 'ipad', 'phone', 'ios'))
    if is_mobile:
        return render(request, 'accounts/invoices_mobile.html', {'invoices_with_meta': invoices_with_meta})
    return render(request, 'accounts/invoices.html', {'invoices_with_meta': invoices_with_meta})


@shop_admin_required
@require_POST
def delete_invoice(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    items = invoice.items.all()
    delivery_ids = [d for d in items.values_list('delivery', flat=True) if d]
    related_payments = models.Payment.objects.filter(Q(invoice=invoice) | Q(delivery_id__in=delivery_ids)).distinct()
    if related_payments.exists():
        messages.error(request, _('Cannot delete invoice %(invoice_number)s because payments exist. Delete related payments first.') % {'invoice_number': invoice.invoice_number})
        return redirect('invoice_detail', invoice_id=invoice.id)
    actual_payments_exist = models.Payment.objects.filter(
        Q(delivery_id__in=delivery_ids), status='completed'
    ).exists()
    if actual_payments_exist:
        messages.error(request, _('Cannot delete invoice %(invoice_number)s because one or more linked deliveries have completed payments. Delete related payments first.') % {'invoice_number': invoice.invoice_number})
        return redirect('invoice_detail', invoice_id=invoice.id)
    if invoice.pdf_file:
        try:
            invoice.pdf_file.delete(save=False)
        except Exception:
            pass
    invoice_number = invoice.invoice_number
    invoice.delete()
    messages.success(request, _('Invoice %(invoice_number)s deleted.') % {'invoice_number': invoice_number})
    return redirect('invoices_list')


@shop_admin_required
@require_POST
def delete_all_invoices(request):
    user = request.user
    invoices = models.Invoice.objects.filter(admin=user)
    invoice_count = invoices.count()
    deleted_count = 0
    skipped_count = 0
    for inv in invoices:
        try:
            items = inv.items.all()
            delivery_ids = [d for d in items.values_list('delivery', flat=True) if d]
            completed_payments_exist = models.Payment.objects.filter(
                Q(invoice=inv) | Q(delivery_id__in=delivery_ids), status='completed'
            ).exists()
            if completed_payments_exist:
                skipped_count += 1
                continue
            if inv.pdf_file:
                try:
                    inv.pdf_file.delete(save=False)
                except Exception:
                    pass
            inv.delete()
            deleted_count += 1
        except Exception:
            skipped_count += 1

    if deleted_count > 0:
        messages.success(request, _('Deleted %(count)s invoice(s).') % {'count': deleted_count})
    if skipped_count > 0:
        messages.error(request, _('Cannot delete invoices because one or more invoices have related payments. Delete related payments first.'))
    return redirect('invoices_list')


@shop_admin_required
def invoice_detail(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    items = invoice.items.all()
    delivery_ids = [d for d in items.values_list('delivery', flat=True) if d]
    payments = models.Payment.objects.filter(Q(invoice=invoice) | Q(delivery_id__in=delivery_ids)).distinct().order_by('-created_at')

    items_total = Decimal('0')
    try:
        for it in items:
            items_total += (it.line_total or Decimal('0'))
    except Exception:
        items_total = Decimal('0')

    stored_total = invoice.total_amount or Decimal('0')
    if stored_total == Decimal('0') and items_total > Decimal('0'):
        display_total = items_total
    else:
        display_total = stored_total

    paid_total = payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
    remaining = display_total - paid_total

    if display_total == Decimal('0'):
        if paid_total > Decimal('0'):
            computed_status = 'paid'
        elif invoice.status == 'paid':
            computed_status = 'paid'
        else:
            computed_status = 'unpaid'
    elif paid_total >= display_total:
        computed_status = 'paid'
    elif paid_total > Decimal('0'):
        computed_status = 'partial'
    else:
        computed_status = 'unpaid'

    try:
        if invoice.status != computed_status:
            invoice.status = computed_status
            invoice.save(update_fields=['status'])
    except Exception:
        pass

    try:
        status_map = dict(models.Invoice.STATUS_CHOICES)
        computed_status_display = status_map.get(computed_status, computed_status.title())
    except Exception:
        computed_status_display = computed_status.title()

    # Build full context including discount/tax fields via helper
    ctx = _build_invoice_context(invoice)
    ctx.update({
        'payments':               payments,
        'remaining':              remaining,
        'display_total':          display_total,
        'computed_status':        computed_status,
        'computed_status_display':computed_status_display,
    })
    return render(request, 'accounts/invoice_detail.html', ctx)


@shop_admin_required
@require_POST
def send_all_invoices(request):
    """Send all invoices to their customer emails using per-user SMTP when available."""
    user = request.user
    invoices = models.Invoice.objects.filter(admin=user).order_by('-created_at')
    sent = 0
    failed = []

    def generate_pdf(invoice):
        ctx = _build_invoice_context(invoice)
        html = render_to_string('accounts/invoice_pdf.html', ctx)
        if not pisa:
            return None, None
        buf = io.BytesIO()
        pdf_status = pisa.CreatePDF(src=html, dest=buf)
        if pdf_status.err:
            return None, None
        return buf.getvalue(), f"{invoice.invoice_number}.pdf"

    connection = None
    try:
        if user and user.smtp_host:
            port = int(user.smtp_port) if user.smtp_port else (465 if user.smtp_use_ssl else 587)
            connection = get_connection(
                'django.core.mail.backends.smtp.EmailBackend',
                host=user.smtp_host,
                port=port,
                username=user.smtp_username or None,
                password=user.smtp_password or None,
                use_tls=bool(user.smtp_use_tls),
                use_ssl=bool(user.smtp_use_ssl),
                timeout=10,
            )
    except Exception as e:
        messages.warning(request, _('Could not use your SMTP settings for bulk send: %(error)s; falling back to site settings.') % {'error': str(e)})
        connection = None

    for inv in invoices:
        to_email = inv.customer.display_email if getattr(inv, 'customer', None) else None
        if not to_email:
            failed.append((inv.invoice_number, 'No customer email'))
            continue
        pdf_bytes, filename = generate_pdf(inv)
        if not pdf_bytes:
            failed.append((inv.invoice_number, 'PDF generation failed'))
            continue
        subj = f"Invoice {inv.invoice_number} from {getattr(user.shop,'name','')}"
        body = f"Dear {inv.customer.display_first_name},\n\nPlease find attached your invoice {inv.invoice_number}.\n\nThank you."
        from django.conf import settings as djsettings
        from_email = user.smtp_from_email or getattr(djsettings, 'DEFAULT_FROM_EMAIL', None) or getattr(djsettings, 'EMAIL_HOST_USER', None)
        try:
            if from_email:
                email = EmailMessage(subj, body, from_email, [to_email], connection=connection)
            else:
                email = EmailMessage(subj, body, to=[to_email], connection=connection)
            email.attach(filename, pdf_bytes, 'application/pdf')
            email.send()
            sent += 1
        except Exception as e:
            failed.append((inv.invoice_number, str(e)))

    if sent:
        messages.success(request, _('Sent %(sent)s invoice(s) by email.') % {'sent': sent})
    if failed:
        messages.error(request, _('Failed to send %(count)s invoice(s). Example: %(examples)s') % {'count': len(failed), 'examples': str(failed[:3])})

    return redirect('invoices_list')


@shop_admin_required
def download_all_invoices(request):
    """Generate one combined PDF containing all invoices."""
    user = request.user
    invoices = list(models.Invoice.objects.filter(admin=user).order_by('created_at'))
    if not invoices:
        messages.info(request, _('No invoices to download.'))
        return redirect('invoices_list')

    rendered_htmls = []
    pages = []
    for inv in invoices:
        ctx = _build_invoice_context(inv)
        rendered = render_to_string('accounts/invoice_pdf.html', ctx)
        rendered_htmls.append(rendered)
        start = rendered.find('<body>')
        end = rendered.find('</body>')
        body = rendered[start+6:end] if start != -1 and end != -1 else rendered
        pages.append(body)

    head_html = ''
    page_wrapper_css = '''<style>
            .page { width:100%; box-sizing:border-box; padding:6px; break-inside: avoid; -webkit-column-break-inside: avoid; page-break-inside: avoid; }
            .page-break { display:block; page-break-after: always; }
        </style>'''
    if rendered_htmls:
        first = rendered_htmls[0]
        hs = first.find('<head>')
        he = first.find('</head>')
        if hs != -1 and he != -1:
            head_html = first[hs+6:he]

    if not head_html:
        head_html = '''<style>@page { size: A4 portrait; margin: 8mm; } body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 14px; color: #222; line-height: 1.25; } .page { width:100%; box-sizing:border-box; padding:6px; } .page-break { page-break-after:always; } .page { break-inside: avoid; -webkit-column-break-inside: avoid; page-break-inside: avoid; } table { width: 100%; border-collapse: collapse; margin-top:8px; table-layout: fixed; } th, td { border: 1px solid #333; padding: 4px 6px; font-size: 13px; vertical-align: middle; } </style>'''

    combined_html = '<html><head>' + head_html + page_wrapper_css + '</head><body>'
    for idx, body in enumerate(pages):
        combined_html += '<div class="page">'
        combined_html += body
        combined_html += '</div>'
        if idx != len(pages) - 1:
            combined_html += '<div class="page-break"></div>'
    combined_html += '</body></html>'

    if not pisa:
        messages.error(request, _('PDF generation requires `xhtml2pdf`. Install with pip install xhtml2pdf'))
        return redirect('invoices_list')

    result = io.BytesIO()
    pdf_status = pisa.CreatePDF(src=combined_html, dest=result)
    if pdf_status.err:
        messages.error(request, _('Failed to generate combined PDF'))
        return redirect('invoices_list')

    filename = f"ALL_INVOICES_{timezone.now().strftime('%Y%m%d%H%M%S')}.pdf"
    response = HttpResponse(result.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


@shop_admin_required
def generate_invoice_pdf(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)

    # FIX: use _build_invoice_context instead of manual gross/paid/net computation
    ctx = _build_invoice_context(invoice)
    html = render_to_string('accounts/invoice_pdf.html', ctx)

    if not pisa:
        messages.error(request, _('PDF generation requires `xhtml2pdf`. Install with pip install xhtml2pdf'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    result = io.BytesIO()
    pdf_status = pisa.CreatePDF(src=html, dest=result)
    if pdf_status.err:
        messages.error(request, _('Failed to generate PDF'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    filename = f"{invoice.invoice_number}.pdf"
    # Removed PDF saving to server as per user request
    # invoice.pdf_file.save(filename, ContentFile(result.getvalue()))
    # invoice.save()
    messages.success(request, _('Invoice PDF generated successfully. Use download button to get the PDF.'))
    return redirect('invoice_detail', invoice_id=invoice.id)


@shop_admin_required
def download_invoice_pdf(request, invoice_id):
    """Generate PDF for an invoice and return it as a downloadable response."""
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)

    if invoice.pdf_file:
        try:
            file_bytes = invoice.pdf_file.read()
            filename = invoice.pdf_file.name.split('/')[-1] if invoice.pdf_file.name else f"{invoice.invoice_number}.pdf"
            response = HttpResponse(file_bytes, content_type='application/pdf')
            response['Content-Disposition'] = f'attachment; filename="{filename}"'
            try:
                invoice.pdf_file.delete(save=False)
                invoice.pdf_file = None
                invoice.save(update_fields=['pdf_file'])
            except Exception:
                pass
            return response
        except Exception:
            pass

    # FIX: use _build_invoice_context instead of manual gross/paid/net computation
    ctx = _build_invoice_context(invoice)
    html = render_to_string('accounts/invoice_pdf.html', ctx)

    if not pisa:
        messages.error(request, _('PDF generation requires `xhtml2pdf`. Install with pip install xhtml2pdf'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    result = io.BytesIO()
    pdf_status = pisa.CreatePDF(src=html, dest=result)
    if pdf_status.err:
        messages.error(request, _('Failed to generate PDF'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    filename = f"{invoice.invoice_number}.pdf"
    # Removed PDF saving to server as per user request
    # try:
    #     invoice.pdf_file.save(filename, ContentFile(result.getvalue()))
    #     invoice.save()
    #     try:
    #         invoice.pdf_file.delete(save=False)
    #         invoice.pdf_file = None
    #         invoice.save(update_fields=['pdf_file'])
    #     except Exception:
    #         pass
    # except Exception:
    #     pass

    response = HttpResponse(result.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


def customer_portal_download_invoice(request, customer_id, invoice_id):
    """Download invoice PDF for customer portal."""
    customer = models.Customer.objects.filter(user=request.user, id=customer_id).first()
    if not customer:
        messages.error(request, _('You do not have access to this invoice.'))
        return redirect('customer_portal_invoices')

    invoice = get_object_or_404(models.Invoice, id=invoice_id, customer=customer)

    # FIX: use _build_invoice_context instead of manual gross/paid/net computation
    ctx = _build_invoice_context(invoice)
    html = render_to_string('accounts/invoice_pdf.html', ctx)

    if not pisa:
        messages.error(request, _('PDF generation requires `xhtml2pdf`. Ask the shop owner to enable PDF generation.'))
        return redirect('customer_portal_invoices')

    result = io.BytesIO()
    pdf_status = pisa.CreatePDF(src=html, dest=result)
    if pdf_status.err:
        messages.error(request, _('Failed to generate PDF'))
        return redirect('customer_portal_invoices')

    filename = f"{invoice.invoice_number}.pdf"
    response = HttpResponse(result.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


@shop_admin_required
@require_POST
def send_invoice(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    method = request.POST.get('method')
    dest = request.POST.get('dest')
    message = request.POST.get('message') or ''

    def _generate_pdf_bytes():
        # FIX: use _build_invoice_context instead of manual gross/paid/net computation
        ctx = _build_invoice_context(invoice)
        html = render_to_string('accounts/invoice_pdf.html', ctx)
        if not pisa:
            return None, None
        result = io.BytesIO()
        pdf_status = pisa.CreatePDF(src=html, dest=result)
        if pdf_status.err:
            return None, None
        return result.getvalue(), f"{invoice.invoice_number}.pdf"

    if method == 'email':
        to_email = dest or (invoice.customer.display_email if getattr(invoice, 'customer', None) else None)
        if not to_email:
            messages.error(request, _('No email address provided'))
            return redirect('invoice_detail', invoice_id=invoice.id)

        user_shop_name = ''
        user = getattr(request, 'user', None)
        if user and hasattr(user, 'shop') and getattr(user, 'shop'):
            user_shop_name = getattr(user.shop, 'name', '')
        subject = f"Invoice {invoice.invoice_number} from {user_shop_name}"
        body = f"Dear {invoice.customer.display_first_name},\n\n{message or 'Please find attached your invoice.'}\n\nThank you."

        from django.conf import settings as djsettings
        connection = None
        used_user_smtp = False
        try:
            if user and user.smtp_host:
                port = int(user.smtp_port) if user.smtp_port else (465 if user.smtp_use_ssl else 587)
                connection = get_connection(
                    'django.core.mail.backends.smtp.EmailBackend',
                    host=user.smtp_host,
                    port=port,
                    username=user.smtp_username or None,
                    password=user.smtp_password or None,
                    use_tls=bool(user.smtp_use_tls),
                    use_ssl=bool(user.smtp_use_ssl),
                    timeout=10,
                )
                used_user_smtp = True
        except Exception as e:
            connection = None
            messages.warning(request, _('Could not use your SMTP settings: %(error)s; falling back to site email settings.') % {'error': str(e)})

        from_email = (user.smtp_from_email if user and user.smtp_from_email else
                      getattr(djsettings, 'DEFAULT_FROM_EMAIL', None) or getattr(djsettings, 'EMAIL_HOST_USER', None))
        if from_email:
            email = EmailMessage(subject, body, from_email, [to_email], connection=connection)
        else:
            email = EmailMessage(subject, body, to=[to_email], connection=connection)
        if used_user_smtp:
            messages.info(request, _('Sending email using your SMTP settings.'))

        pdf_bytes, filename = _generate_pdf_bytes()
        if pdf_bytes:
            try:
                email.attach(filename, pdf_bytes, 'application/pdf')
            except Exception:
                pass
        try:
            email.send()
            messages.success(request, _('Invoice emailed to %(email)s') % {'email': to_email})
        except Exception as e:
            messages.error(request, _('Failed to send email: %(error)s') % {'error': str(e)})
        return redirect('invoice_detail', invoice_id=invoice.id)

    if method == 'whatsapp_web':
        phone = dest or invoice.customer.whatsapp_number or invoice.customer.phone_number or getattr(request.user, 'whatsapp_number', None)
        if not phone:
            messages.error(request, _('No phone number provided'))
            return redirect('invoice_detail', invoice_id=invoice.id)
        try:
            ctx = _build_invoice_context(invoice)
            items = ctx['items_with_paid']
            total_qty = int(ctx['total_qty'])
            gross = ctx['gross_payable']
            paid = ctx['paid_amount']
            net = ctx['net_payable']
        except Exception:
            total_qty = 0
            gross = None
            paid = None
            net = None

        currency = (
            getattr(invoice.shop, 'currency', None)
            or getattr(invoice.customer.shop, 'currency', None)
            or 'PKR'
        )

        lines = []
        lines.append(f"Bill From: *{invoice.shop.name}*")
        lines.append(f"Bill For: *{invoice.customer.display_name}*")
        lines.append(f"Address: *{invoice.customer.get_full_address()}*")
        lines.append(f"Invoice# : *{invoice.invoice_number}*")
        lines.append('')
        lines.append('*| Date | Qty | Rate | Total |*')
        for it in invoice.items.all():
            delivery_date = ''
            try:
                if getattr(it, 'delivery', None) and getattr(it.delivery, 'delivery_date', None):
                    delivery_date = it.delivery.delivery_date.strftime('%d %b %Y')
            except Exception:
                delivery_date = ''
            qty = getattr(it, 'quantity', 0) or 0
            rate = getattr(it, 'unit_price', '')
            line_total = getattr(it, 'line_total', '')
            lines.append(f"{delivery_date} | {qty} X {currency} {rate} =  {line_total}")
        subtotal = ctx.get('subtotal') or Decimal('0')
        total_discount = ctx.get('total_discount') or Decimal('0')
        total_tax = ctx.get('total_tax') or Decimal('0')
        display_total = ctx.get('display_total') or Decimal('0')
        paid_amount = ctx.get('paid_amount') or Decimal('0')
        remaining_amount = ctx.get('remaining') or Decimal('0')
        has_discount = ctx.get('has_discount', False)
        has_tax = ctx.get('has_tax', False)

        lines.append('------------------------------------------------------')
        lines.append(f"Total Cans: *{total_qty}*")
        lines.append(f"Subtotal: {currency} *{subtotal}*")
        if has_discount:
            lines.append(f"Discount: -{currency} *{total_discount}*")
        if has_tax:
            lines.append(f"Tax: +{currency} *{total_tax}*")
        lines.append(f"Invoice Total: {currency} *{display_total}*")
        lines.append(f"Already Paid: {currency} *{paid_amount}*")
        lines.append(f"Remaining: {currency} *{remaining_amount}*")
        msg = message or "\n".join(lines)
        text = msg
        try:
            raw = phone or ''
            digits = ''.join([c for c in raw if c.isdigit()])
            if not digits:
                raise ValueError('no digits')
            if digits.startswith('0'):
                digits = '92' + digits[1:]
            elif digits.startswith('92'):
                pass
            elif len(digits) == 10 and digits.startswith('3'):
                digits = '92' + digits
            phone_formatted = '+' + digits
        except Exception:
            phone_formatted = phone
        app_link = f"whatsapp://send?phone={phone_formatted}&text={urlquote(text)}"
        web_link = f"https://web.whatsapp.com/send?phone={phone_formatted}&text={urlquote(text)}"
        mobile_link = f"https://api.whatsapp.com/send?phone={phone_formatted}&text={urlquote(text)}"
        invoice_url = request.build_absolute_uri(reverse('invoice_detail', args=[invoice.id]))
        js_app_link = json.dumps(app_link)
        js_web_link = json.dumps(web_link)
        js_mobile_link = json.dumps(mobile_link)
        js_invoice = json.dumps(invoice_url)
        html = f"""<!doctype html>
<html><head><meta charset=\"utf-8\"><title>Open WhatsApp</title></head>
<body>
<script>
  var appLink = {js_app_link};
  var fallbackLink = /Mobi|Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
    ? {js_mobile_link}
    : {js_web_link};

  function openWhatsApp() {{
    window.location = appLink;
    setTimeout(function() {{
      window.location = fallbackLink;
    }}, 1200);
  }}

  openWhatsApp();
</script>
<p>If WhatsApp does not open automatically, <a href={js_app_link}>open WhatsApp app</a>, <a href={js_web_link} target=\"_blank\" rel=\"noopener\">open WhatsApp Web</a>, or <a href={js_mobile_link} target=\"_blank\" rel=\"noopener\">open WhatsApp Mobile</a>.</p>
<p><a href={js_invoice}>Return to invoice</a></p>
</body></html>"""
        return HttpResponse(html)

    if method == 'whatsapp_mobile':
        phone = dest or invoice.customer.phone_number or invoice.customer.whatsapp_number or getattr(request.user, 'whatsapp_number', None)
        if not phone:
            messages.error(request, _('No phone number provided'))
            return redirect('invoice_detail', invoice_id=invoice.id)

        try:
            ctx = _build_invoice_context(invoice)
            total_qty = int(ctx['total_qty'])
            gross = ctx['gross_payable']
            paid = ctx['paid_amount']
            net = ctx['net_payable']
        except Exception:
            total_qty = 0
            gross = None
            paid = None
            net = None

        currency = (
            getattr(invoice.shop, 'currency', None)
            or getattr(invoice.customer.shop, 'currency', None)
            or 'PKR'
        )

        lines = []
        lines.append(f"Bill From: *{invoice.shop.name}*")
        lines.append(f"Bill For: *{invoice.customer.display_name}*")
        lines.append(f"Address: *{invoice.customer.address}*")
        lines.append(f"Invoice# : *{invoice.invoice_number}*")
        lines.append('')
        lines.append('*| Date | Qty | Rate | Total |*')
        for it in invoice.items.all():
            delivery_date = ''
            try:
                if getattr(it, 'delivery', None) and getattr(it.delivery, 'delivery_date', None):
                    delivery_date = it.delivery.delivery_date.strftime('%d %b %Y')
            except Exception:
                delivery_date = ''
            qty = getattr(it, 'quantity', 0) or 0
            rate = getattr(it, 'unit_price', '')
            line_total = getattr(it, 'line_total', '')
            lines.append(f"{delivery_date} | {qty} X {currency} {rate} =  {line_total}")
        subtotal = ctx.get('subtotal') or Decimal('0')
        total_discount = ctx.get('total_discount') or Decimal('0')
        total_tax = ctx.get('total_tax') or Decimal('0')
        display_total = ctx.get('display_total') or Decimal('0')
        paid_amount = ctx.get('paid_amount') or Decimal('0')
        remaining_amount = ctx.get('remaining') or Decimal('0')
        has_discount = ctx.get('has_discount', False)
        has_tax = ctx.get('has_tax', False)

        lines.append('------------------------------------------------------')
        lines.append(f"Total Cans: *{total_qty}*")
        lines.append(f"Subtotal: {currency} *{subtotal}*")
        if has_discount:
            lines.append(f"Discount: -{currency} *{total_discount}*")
        if has_tax:
            lines.append(f"Tax: +{currency} *{total_tax}*")
        lines.append(f"Invoice Total: {currency} *{display_total}*")
        lines.append(f"Already Paid: {currency} *{paid_amount}*")
        lines.append(f"Remaining: {currency} *{remaining_amount}*")
        msg = message or "\n".join(lines)
        text = msg

        try:
            raw = phone or ''
            digits = ''.join([c for c in raw if c.isdigit()])
            if not digits:
                raise ValueError('no digits')
            if digits.startswith('0'):
                digits = '92' + digits[1:]
            elif digits.startswith('92'):
                pass
            elif len(digits) == 10 and digits.startswith('3'):
                digits = '92' + digits
        except Exception:
            digits = phone

        link = f"whatsapp://send?phone={digits}&text={urlquote(text)}"
        return_url = request.META.get('HTTP_REFERER') or request.build_absolute_uri(reverse('invoice_detail', args=[invoice.id]))
        js_link = json.dumps(link)
        js_return = json.dumps(return_url)
        html = f"""<!doctype html>
<html><head><meta charset=\"utf-8\"><title>Open WhatsApp</title></head>
<body>
<p>Opening WhatsApp...</p>
<p>If WhatsApp doesn't open automatically, <a href={js_link}>open WhatsApp</a>.</p>
<p><a href={js_return}>Return to invoice</a></p>
</body></html>"""
        return HttpResponse(html)

    if method == 'whatsapp_api':
        from django.conf import settings as djsettings
        phone_number_id = getattr(djsettings, 'META_WHATSAPP_PHONE_NUMBER_ID', None)
        access_token = getattr(djsettings, 'META_WHATSAPP_ACCESS_TOKEN', None)

        user = getattr(request, 'user', None)
        if user:
            user_phone_id = getattr(user, 'meta_whatsapp_phone_number_id', None)
            user_token = getattr(user, 'meta_whatsapp_access_token', None)
            if user_phone_id and user_token:
                phone_number_id, access_token = user_phone_id, user_token

        if not all([phone_number_id, access_token]):
            messages.error(request, _('Meta WhatsApp credentials not configured in settings or your profile.'))
            return redirect('invoice_detail', invoice_id=invoice.id)

        to_number = dest or invoice.customer.phone_number or invoice.customer.whatsapp_number or (request.user.whatsapp_number if request.user else None)
        if not to_number:
            messages.error(request, _('No destination phone number available'))
            return redirect('invoice_detail', invoice_id=invoice.id)

        to_number_normalized = ''.join([c for c in to_number if c.isdigit()])

        currency = (
            getattr(invoice.shop, 'currency', None)
            or getattr(invoice.customer.shop, 'currency', None)
            or 'PKR'
        )
        msg = message or f"Invoice {invoice.invoice_number} - Total {currency} {invoice.total_amount}."
        try:
            url = f"https://graph.facebook.com/v16.0/{phone_number_id}/messages"
            headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}
            payload = {
                'messaging_product': 'whatsapp',
                'to': to_number_normalized,
                'type': 'text',
                'text': {'body': msg},
            }
            resp = requests.post(url, headers=headers, json=payload, timeout=15)
            resp.raise_for_status()
            messages.success(request, _('Invoice sent via WhatsApp API to %(number)s') % {'number': to_number})
        except Exception as e:
            messages.error(request, _('Failed to send WhatsApp API message: %(error)s') % {'error': str(e)})
        return redirect('invoice_detail', invoice_id=invoice.id)

    messages.error(request, _('Unknown method'))
    return redirect('invoice_detail', invoice_id=invoice.id)


@shop_admin_required
@require_POST
def record_payment(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    amount = request.POST.get('amount')
    method = request.POST.get('method')
    transaction_id = request.POST.get('transaction_id')

    try:
        amount_decimal = Decimal(amount)
    except Exception:
        amount_decimal = Decimal('0')

    try:
        paid_total = invoice.get_paid_total()
    except Exception:
        paid_total = invoice.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
    remaining = (invoice.total_amount or Decimal('0')) - paid_total
    if amount_decimal > remaining:
        messages.error(request, _('Payment exceeds remaining invoice amount (remaining %(remaining)s) — ادائیگی انوائس کے باقی رقم سے زیادہ ہے: %(remaining)s') % {'remaining': remaining})
        return redirect('invoice_detail', invoice_id=invoice.id)
    if remaining <= Decimal('0'):
        messages.error(request, _('Invoice is already fully paid — یہ انوائس پہلے ہی مکمل طور پر ادا ہو چکی ہے۔'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    try:
        payment = models.Payment.objects.create(
            invoice=invoice,
            admin=request.user,
            shop=request.user.shop,
            payer_customer=invoice.customer,
            amount=amount_decimal,
            method=method or 'cash',
            transaction_id=transaction_id or '',
            status='completed',
            paid_at=timezone.now(),
        )
    except Exception as e:
        messages.error(request, _('Failed to record payment: %(error)s') % {'error': str(e)})
        return redirect('invoice_detail', invoice_id=invoice.id)

    try:
        paid_total = invoice.get_paid_total()
    except Exception:
        paid_total = invoice.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
    if paid_total >= invoice.total_amount:
        invoice.status = 'paid'
    elif paid_total > Decimal('0') and paid_total < invoice.total_amount:
        invoice.status = 'partial'
    else:
        invoice.status = 'unpaid'
    invoice.save()

    return redirect('invoice_detail', invoice_id=invoice.id)


@shop_admin_required
@require_POST
def mark_invoice_paid(request, invoice_id):
    """Mark a zero-total invoice as paid without creating a monetary payment."""
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    from decimal import Decimal

    total_amt = invoice.total_amount or Decimal('0')
    if total_amt != Decimal('0'):
        messages.error(request, _('Only zero-total invoices can be marked as paid using this action.'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    if invoice.status == 'paid':
        messages.info(request, _('Invoice already marked as paid'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    try:
        models.Payment.objects.create(
            invoice=invoice,
            admin=request.user,
            shop=request.user.shop,
            payer_customer=invoice.customer,
            amount=Decimal('0'),
            method='system',
            transaction_id='',
            status='completed',
            paid_at=timezone.now(),
        )
        invoice.status = 'paid'
        invoice.save()
        messages.success(request, _('Invoice marked as paid'))
    except Exception as e:
        messages.error(request, _('Failed to mark invoice as paid: %(error)s') % {'error': str(e)})

    return redirect('invoice_detail', invoice_id=invoice.id)


@shop_admin_required
def payments_search(request):
    """AJAX JSON endpoint returning payments matching `q` for current admin."""
    user = request.user
    q = (request.GET.get('q') or '').strip()
    qs = models.Payment.objects.filter(admin=user).select_related('payer_customer', 'invoice')
    if q:
        from django.db.models import Q
        qs = qs.filter(
            Q(payer_customer__first_name__icontains=q) |
            Q(payer_customer__last_name__icontains=q) |
            Q(transaction_id__icontains=q) |
            Q(method__icontains=q) |
            Q(invoice__invoice_number__icontains=q)
        )
    qs = qs.order_by('-created_at')[:200]
    results = []
    for p in qs:
        payer = None
        if p.payer_customer:
            payer = p.payer_customer.display_name
        results.append({
            'id': p.id,
            'payer': payer or '',
            'amount': str(p.amount or '0'),
            'method': p.method or '',
            'transaction_id': p.transaction_id or '',
            'status': p.status or '',
            'created_at': p.created_at.isoformat() if p.created_at else '',
        })
    return JsonResponse({'results': results})


@shop_admin_required
def invoices_search(request):
    """AJAX JSON endpoint returning unpaid invoices matching `q` for current admin."""
    user = request.user
    q = (request.GET.get('q') or '').strip()
    from django.db.models import Q, Sum
    qs = models.Invoice.objects.filter(admin=user).filter(status__in=['unpaid', 'partial']).select_related('customer')
    if q:
        qs = qs.filter(
            Q(invoice_number__icontains=q) |
            Q(customer__first_name__icontains=q) |
            Q(customer__last_name__icontains=q)
        )
    qs = qs.order_by('-created_at')[:200]
    results = []
    for inv in qs:
        try:
            delivery_ids = [d for d in inv.items.values_list('delivery', flat=True) if d]
            paid_total = models.Payment.objects.filter(status='completed').filter(
                Q(invoice=inv) | Q(delivery_id__in=delivery_ids)
            ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
        except Exception:
            paid_total = inv.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
        remaining = (inv.total_amount or Decimal('0')) - paid_total
        if remaining > Decimal('0'):
            results.append({
                'id': inv.id,
                'invoice_number': inv.invoice_number,
                'payer': inv.customer.display_name,
                'remaining': str(remaining),
                'status': inv.status,
            })
    return JsonResponse({'results': results})


@shop_admin_required
def payments_list(request):
    user = request.user
    payments = models.Payment.objects.filter(admin=user).order_by('-created_at')
    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = request.GET.get('mobile') == '1' or any(k in ua for k in ('mobile', 'android', 'iphone', 'phone', 'ios'))
    ctx = {'payments': payments}
    if is_mobile:
        return render(request, 'accounts/payments_mobile.html', ctx)
    return render(request, 'accounts/payments.html', {'payments': payments})


@shop_admin_required
def payment_detail(request, payment_id):
    payment = get_object_or_404(models.Payment, id=payment_id, admin=request.user)
    return render(request, 'accounts/payment_detail.html', {'payment': payment})


@shop_admin_required
def payment_edit(request, payment_id):
    payment = get_object_or_404(models.Payment, id=payment_id, admin=request.user)
    invoices_qs = models.Invoice.objects.filter(admin=request.user).order_by('-created_at')
    invoices = []
    for inv in invoices_qs:
        try:
            delivery_ids = [d for d in inv.items.values_list('delivery', flat=True) if d]
            paid_total = models.Payment.objects.filter(status='completed').filter(
                Q(invoice=inv) | Q(delivery_id__in=delivery_ids)
            ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
        except Exception:
            paid_total = inv.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
        remaining = (inv.total_amount or Decimal('0')) - paid_total
        invoices.append({'obj': inv, 'remaining': remaining})
    customers = models.Customer.objects.filter(shop__admin=request.user)
    deliveries_qs = models.DailyDelivery.objects.filter(admin=request.user).filter(models.Q(payment_status__in=['unpaid','partial']) | models.Q(id=payment.delivery_id)).order_by('-delivery_date')
    deliveries = []
    for d in deliveries_qs:
        try:
            delivery_amount = (Decimal(d.quantity_delivered or 0) * (Decimal(d.rate_given or 0)))
        except Exception:
            delivery_amount = Decimal('0')
        try:
            paid_total = models.Payment.objects.filter(status='completed', delivery=d).aggregate(total=Sum('amount'))['total'] or Decimal('0')
        except Exception:
            paid_total = Decimal('0')
        remaining = delivery_amount - paid_total
        if remaining < Decimal('0'):
            remaining = Decimal('0')
        deliveries.append({'obj': d, 'remaining': remaining, 'amount': delivery_amount})
    if request.method == 'POST':
        amount = request.POST.get('amount')
        method = request.POST.get('method') or payment.method
        transaction_id = request.POST.get('transaction_id') or ''
        status = request.POST.get('status') or payment.status
        invoice_id = request.POST.get('invoice_id') or None
        delivery_id = request.POST.get('delivery_id') or None
        customer_id = request.POST.get('customer_id') or None
        try:
            amount_decimal = Decimal(amount)
        except Exception:
            amount_decimal = payment.amount

        if invoice_id and delivery_id:
            messages.error(request, _('Please select either an invoice or a delivery, not both'))
            return redirect('payment_edit', payment_id=payment.id)
        if not invoice_id and not delivery_id:
            messages.error(request, _('Please attach this payment to an invoice or a delivery'))
            return redirect('payment_edit', payment_id=payment.id)

        if delivery_id:
            try:
                d = models.DailyDelivery.objects.get(id=delivery_id, admin=request.user)
            except models.DailyDelivery.DoesNotExist:
                messages.error(request, _('Invalid delivery selected'))
                return redirect('payment_edit', payment_id=payment.id)
            if d.payment_status == 'paid':
                messages.error(request, _('Selected delivery is already marked paid'))
                return redirect('payment_edit', payment_id=payment.id)
            try:
                delivery_amount = (Decimal(d.quantity_delivered or 0) * (Decimal(d.rate_given or 0)))
            except Exception:
                delivery_amount = Decimal('0')
            try:
                paid_total = models.Payment.objects.filter(status='completed', delivery=d).aggregate(total=Sum('amount'))['total'] or Decimal('0')
            except Exception:
                paid_total = Decimal('0')
            delivery_remaining = delivery_amount - paid_total
            if delivery_remaining < Decimal('0'):
                delivery_remaining = Decimal('0')
            if amount_decimal > delivery_remaining:
                messages.error(request, _('Payment exceeds remaining delivery amount (remaining %(remaining)s)') % {'remaining': delivery_remaining})
                return redirect('payment_edit', payment_id=payment.id)

        if invoice_id:
            try:
                inv = models.Invoice.objects.get(id=invoice_id, admin=request.user)
                paid_total = inv.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
                remaining = (inv.total_amount or Decimal('0')) - paid_total
                if amount_decimal > remaining:
                    messages.error(request, _('Payment exceeds remaining invoice amount (remaining %(remaining)s)') % {'remaining': remaining})
                    return redirect('payment_edit', payment_id=payment.id)
            except models.Invoice.DoesNotExist:
                messages.error(request, _('Invalid invoice selected'))
                return redirect('payment_edit', payment_id=payment.id)

        old_invoice = payment.invoice

        payment.amount = amount_decimal
        payment.method = method
        payment.transaction_id = transaction_id
        payment.payer_customer_id = customer_id if customer_id else None
        payment.invoice_id = invoice_id if invoice_id else None
        payment.delivery_id = delivery_id if delivery_id else None

        if status == 'completed' and not payment.paid_at:
            payment.paid_at = timezone.now()
        if status != 'completed':
            payment.paid_at = None
        payment.status = status
        payment.save()

        def _recalc_invoice(inv):
            if not inv:
                return
            try:
                paid_total = inv.get_paid_total()
            except Exception:
                paid_total = inv.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
            if paid_total >= inv.total_amount:
                inv.status = 'paid'
            elif paid_total > Decimal('0'):
                inv.status = 'partial'
            else:
                inv.status = 'unpaid'
            inv.save()

        if old_invoice and (not payment.invoice or old_invoice.id != payment.invoice.id):
            _recalc_invoice(old_invoice)
        if payment.invoice:
            _recalc_invoice(payment.invoice)

        messages.success(request, _('Payment updated.'))
        return redirect('payment_detail', payment_id=payment.id)

    return render(request, 'accounts/payment_form.html', {'payment': payment, 'invoices': invoices, 'customers': customers, 'deliveries': deliveries})


@shop_admin_required
@require_POST
def auto_generate_invoices(request):
    """
    Generate one invoice per active customer for a completed month.
 
    Changes from original:
    - Each customer is wrapped in its own try/except + atomic savepoint so one
      IntegrityError (duplicate) doesn't abort the entire batch.
    - Uses update_or_create / direct existence check BEFORE entering atomic
      block to avoid unnecessary constraint violations.
    - Clears the django.db.models IntegrityError correctly so later iterations
      continue.
    - Falls back to date-range generation when no month is selected (unchanged).
    """
    from accounts import models  # local import to match your project structure
 
    user        = request.user
    month_value = request.POST.get('month')
 
    if month_value:
        try:
            y_str, m_str = month_value.split('-')
            y = int(y_str)
            m = int(m_str)
            import calendar
            from datetime import date
            start    = date(y, m, 1)
            last_day = calendar.monthrange(y, m)[1]
            end      = date(y, m, last_day)
        except Exception:
            messages.error(request, _('Invalid month selected'))
            return redirect('admin_dashboard')
 
        today = timezone.now().date()
        if y == today.year and m == today.month:
            messages.error(request, _('Cannot generate invoices for the current running month'))
            return redirect('admin_dashboard')
 
        customers = models.Customer.objects.filter(shop__admin=user, is_active=True)
 
        if not customers.exists():
            messages.info(request, _('No active customers found.'))
            return redirect('admin_dashboard')
 
        created_count  = 0
        skipped_count  = 0
        no_delivery_count = 0
 
        for cust in customers:
            # ── Fast existence check BEFORE hitting the DB constraint ──────
            if models.Invoice.objects.filter(
                customer=cust, invoice_year=y, invoice_month=m
            ).exists():
                skipped_count += 1
                continue
 
            # ── Only create if there are uninvoiced deliveries ─────────────
            cust_deliveries = models.DailyDelivery.objects.filter(
                admin=user,
                customer=cust,
                delivery_date__gte=start,
                delivery_date__lte=end,
                invoice_items__isnull=True,   # not yet on any invoice
            )
            if not cust_deliveries.exists():
                no_delivery_count += 1
                continue
 
            # ── Create the invoice in its own savepoint ───────────────────
            try:
                with transaction.atomic():
                    # Double-check inside the atomic block (race condition guard)
                    if models.Invoice.objects.filter(
                        customer=cust, invoice_year=y, invoice_month=m
                    ).exists():
                        skipped_count += 1
                        continue
 
                    invoice_number = (
                        f"INV-{y}{m:02d}-"
                        f"{timezone.now().strftime('%H%M%S%f')[:10]}-"
                        f"{cust.id}"
                    )
                    invoice = models.Invoice.objects.create(
                        invoice_number=invoice_number,
                        admin=user,
                        shop=user.shop,
                        customer=cust,
                        total_amount=Decimal('0'),
                        status='unpaid',
                        invoice_year=y,
                        invoice_month=m,
                        notes=cust.invoice_notes or '',
                    )
 
                    net_total = _attach_deliveries_to_invoice(invoice, cust_deliveries)
                    invoice.total_amount = net_total
                    invoice.save()
                    created_count += 1
 
            except IntegrityError:
                # Race condition: another request created this invoice between
                # our check and our create. Safe to skip.
                skipped_count += 1
                continue
            except Exception as exc:
                messages.error(
                    request,
                    _('Failed to create invoice for %(name)s: %(error)s') % {
                        'name': cust.display_name,
                        'error': str(exc),
                    }
                )
                continue
 
        # ── Summary messages ──────────────────────────────────────────────
        if created_count:
            messages.success(
                request,
                _('Created %(count)s invoice(s) for %(month)s.') % {
                    'count': created_count,
                    'month': start.strftime('%b %Y'),
                }
            )
        if skipped_count:
            messages.info(
                request,
                _('Skipped %(count)s customer(s) — invoices already exist for %(month)s.') % {
                    'count': skipped_count,
                    'month': start.strftime('%b %Y'),
                }
            )
        if no_delivery_count:
            messages.info(
                request,
                _('Skipped %(count)s customer(s) with no deliveries in %(month)s.') % {
                    'count': no_delivery_count,
                    'month': start.strftime('%b %Y'),
                }
            )
        if not created_count and not skipped_count and not no_delivery_count:
            messages.info(request, _('No invoices were created.'))
 
        return redirect('admin_dashboard')
 
    # ── Fallback: date-range generation (unchanged logic, same fix applied) ──
    start_date = request.POST.get('start_date')
    end_date   = request.POST.get('end_date')
    try:
        start = (
            timezone.datetime.fromisoformat(start_date).date()
            if start_date
            else timezone.now().date().replace(day=1)
        )
        end = (
            timezone.datetime.fromisoformat(end_date).date()
            if end_date
            else timezone.now().date()
        )
    except Exception:
        messages.error(request, _('Invalid dates provided'))
        return redirect('admin_dashboard')
 
    from accounts import models  # ensure available in fallback path
 
    deliveries = models.DailyDelivery.objects.filter(
        admin=user,
        delivery_date__gte=start,
        delivery_date__lte=end,
        invoice_items__isnull=True,
        customer__is_active=True,
    )
    if not deliveries.exists():
        messages.info(request, _('No un-invoiced deliveries found for the selected range.'))
        return redirect('admin_dashboard')
 
    created_count = 0
    customer_ids  = deliveries.values_list('customer', flat=True).distinct()
 
    for cid in customer_ids:
        cust_deliveries = deliveries.filter(customer_id=cid)
        if not cust_deliveries.exists():
            continue
        try:
            with transaction.atomic():
                first          = cust_deliveries.first()
                invoice_number = (
                    f"INV-{timezone.now().strftime('%Y%m%d%H%M%S%f')[:18]}-{cid}"
                )
                invoice = models.Invoice.objects.create(
                    invoice_number=invoice_number,
                    admin=user,
                    shop=user.shop,
                    customer_id=cid,
                    total_amount=Decimal('0'),
                    status='unpaid',
                    notes=first.customer.invoice_notes if first.customer else '',
                )
                net_total = _attach_deliveries_to_invoice(invoice, cust_deliveries)
                invoice.total_amount = net_total
                invoice.save()
                created_count += 1
        except IntegrityError:
            continue
        except Exception as exc:
            messages.error(
                request,
                _('Error creating invoice for customer %(id)s: %(error)s') % {
                    'id': cid,
                    'error': str(exc),
                }
            )
            continue
 
    messages.success(
        request,
        _('Created %(count)s invoice(s) for %(start)s – %(end)s.') % {
            'count': created_count,
            'start': start,
            'end':   end,
        }
    )
    return redirect('admin_dashboard')
 

@shop_admin_required
def customers_search(request):
    """AJAX JSON endpoint returning customers matching `q` for current admin."""
    user = request.user
    q = (request.GET.get('q') or '').strip()
    qs = models.Customer.objects.filter(shop__admin=user)
    if q:
        from django.db.models import Q
        qs = qs.filter(
            Q(first_name__icontains=q) |
            Q(last_name__icontains=q) |
            Q(phone_number__icontains=q) |
            Q(whatsapp_number__icontains=q) |
            Q(address_line_1__icontains=q) |
            Q(address_line_2__icontains=q) |
            Q(area__icontains=q) |
            Q(city__icontains=q)
        )
    qs = qs.order_by('-id')[:200]
    results = []
    for c in qs:
        results.append({
            'id': c.id,
            'display_name': c.display_name,
            'phone_number': c.phone_number or '',
            'whatsapp_number': c.whatsapp_number or '',
            'address': c.address or '',
            'current_receivable': str(c.get_current_receivable or '0'),
            'is_active': c.is_active,
        })
    return JsonResponse({'results': results})


@shop_admin_required
def customers_list(request):
    user = request.user
    customers = models.Customer.objects.filter(shop__admin=user).order_by('-id')
    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = request.GET.get('mobile') == '1' or any(k in ua for k in ('mobile', 'android', 'iphone', 'phone', 'ios'))
    ctx = {'customers': customers}
    if is_mobile:
        return render(request, 'accounts/customers_mobile.html', ctx)
    return render(request, 'accounts/customers.html', ctx)


# ------------------ ADMIN DELIVERY (shop admin) ------------------
@shop_admin_required
def admin_delivery_create(request):
    user = request.user
    customers = models.Customer.objects.filter(shop__admin=user, is_active=True)
    staff_qs = models.Staff.objects.filter(admin=user)
    can_types = models.CanType.objects.filter(admin=user, enabled=True)

    if request.method == 'POST':
        customer_id = request.POST.get('customer_id')
        staff_id = request.POST.get('staff_id')
        can_type_id = request.POST.get('can_type')
        quantity = request.POST.get('quantity')
        empty_cans = request.POST.get('empty_cans')
        delivery_date_raw = request.POST.get('delivery_date') or None
        rate_raw = request.POST.get('rate_given')

        delivery_date = None
        entry_date = timezone.now().date()
        if delivery_date_raw:
            try:
                delivery_date = timezone.datetime.fromisoformat(delivery_date_raw).date()
            except Exception:
                delivery_date = None

        is_ajax = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

        def ajax_error(msg, redirect_name='admin_delivery_create', *args):
            if is_ajax:
                return JsonResponse({'ok': False, 'message': str(msg)})
            else:
                messages.error(request, str(msg))
                return redirect(redirect_name, *args)

        def ajax_success(msg, redirect_name='admin_delivery_create', *args):
            if is_ajax:
                return JsonResponse({'ok': True, 'message': str(msg)})
            else:
                messages.success(request, str(msg))
                return redirect(redirect_name, *args)

        if not (customer_id and can_type_id and quantity):
            return ajax_error(_('Please provide all required fields'))
        try:
            customer = models.Customer.objects.get(id=customer_id, shop__admin=user)
            can_type = models.CanType.objects.get(id=can_type_id, admin=user)
        except models.Customer.DoesNotExist:
            return ajax_error(_('Invalid customer selected'))
        except models.CanType.DoesNotExist:
            return ajax_error(_('Invalid can type selected'))

        customer_assignments = models.CustomerCanType.objects.filter(customer=customer)
        if customer_assignments.exists():
            if not customer_assignments.filter(can_type=can_type).exists():
                return ajax_error(_('Selected can type is not assigned to the chosen customer'))

        from decimal import Decimal, InvalidOperation
        rate_given = None
        if rate_raw:
            try:
                rate_given = Decimal(rate_raw)
            except InvalidOperation:
                rate_given = None
        if rate_given is None:
            try:
                cust_ct = customer_assignments.get(can_type=can_type)
                rate_given = cust_ct.price
            except Exception:
                rate_given = can_type.price

        staff = None
        if staff_id and staff_id != 'admin':
            try:
                staff = models.Staff.objects.get(id=staff_id, admin=user)
            except models.Staff.DoesNotExist:
                return ajax_error(_('Invalid staff selected'))

        try:
            qty = int(quantity)
            if qty < 1:
                raise ValueError()
        except Exception:
            return ajax_error(_('Quantity must be a whole number greater than 0'))

        try:
            empty_val = int(empty_cans) if empty_cans not in (None, '') else 0
            if empty_val < 0:
                raise ValueError()
        except Exception:
            return ajax_error(_('Empty cans must be a whole number 0 or greater'))

        try:
            entry = models.DailyDelivery.objects.create(
                admin=user,
                staff=staff,
                customer=customer,
                can_type=can_type,
                quantity_delivered=qty,
                empty_cans_received=empty_val,
                delivery_date=delivery_date or None,
                entry_date=entry_date,
                rate_given=rate_given,
            )
            return ajax_success(_('Delivery recorded for %(name)s') % {'name': customer.display_name})
        except Exception as e:
            return ajax_error(_('Failed to record delivery - %(error)s') % {'error': str(e)})

    customer_can_map = {}
    for c in customers:
        entries = []
        for entry in models.CustomerCanType.objects.filter(customer=c):
            entries.append({'id': entry.can_type.id, 'name': str(entry.can_type), 'price': str(entry.price)})
        customer_can_map[c.id] = entries

    return render(request, 'accounts/delivery_form.html', {'customers': customers, 'staff_list': staff_qs, 'can_types': can_types, 'today': timezone.now().date(), 'customer_can_map': customer_can_map})


@shop_admin_required
def deliveries_list(request):
    """List all deliveries for the current shop admin."""
    user = request.user
    deliveries = models.DailyDelivery.objects.filter(admin=user).order_by('-created_at')
    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = request.GET.get('mobile') == '1' or any(k in ua for k in ('mobile', 'android', 'iphone', 'phone', 'ios'))
    if is_mobile:
        return render(request, 'accounts/deliveries_mobile.html', {'deliveries': deliveries})
    return render(request, 'accounts/deliveries_list.html', {'deliveries': deliveries})

from django.db import transaction
from decimal import Decimal
from django.core.exceptions import ValidationError

def rebalance_customer_ledger(customer, admin_user):
    """
    Completely rebuilds the ReceivableLedger for a customer from scratch.
    """
    if not customer or not admin_user:
        return False

    try:
        with transaction.atomic():
            customer = models.Customer.objects.select_for_update().get(id=customer.id)

            models.ReceivableLedger.objects.filter(
                customer=customer,
                admin=admin_user
            ).delete()

            deliveries = models.DailyDelivery.objects.filter(
                customer=customer,
                admin=admin_user
            ).order_by('delivery_date', 'id')

            payments = models.Payment.objects.filter(
                payer_customer=customer,
                admin=admin_user,
                status='completed'
            ).order_by('paid_at', 'id')

            all_entries = []

            for delivery in deliveries:
                amount = Decimal(delivery.quantity_delivered or 0) * Decimal(delivery.rate_given or 0)
                all_entries.append({
                    'type': 'delivery',
                    'date': delivery.delivery_date,
                    'debit': amount,
                    'credit': Decimal('0'),
                    'delivery': delivery,
                    'description': f"Delivery #{delivery.id} - {delivery.quantity_delivered} cans"
                })

            for payment in payments:
                all_entries.append({
                    'type': 'payment',
                    'date': payment.paid_at.date() if payment.paid_at else payment.created_at.date(),
                    'debit': Decimal('0'),
                    'credit': payment.amount,
                    'payment': payment,
                    'description': f"Payment #{payment.id} - {payment.get_method_display()}"
                })

            all_entries.sort(key=lambda x: (x['date'], 0 if x['type'] == 'delivery' else 1))

            current_balance = Decimal('0.00')

            for entry in all_entries:
                current_balance += (entry['debit'] - entry['credit'])

                models.ReceivableLedger.objects.create(
                    admin=admin_user,
                    shop=getattr(admin_user, 'shop', None) or getattr(admin_user, 'shop_admin', None),
                    customer=customer,
                    date=entry['date'],
                    transaction_type=entry['type'],
                    debit=entry['debit'],
                    credit=entry['credit'],
                    delivery=entry.get('delivery'),
                    payment=entry.get('payment'),
                    description=entry['description'],
                    balance_after=current_balance,
                )

            customer.outstanding_balance = current_balance
            customer.save(update_fields=['outstanding_balance'])

            return True

    except Exception as e:
        print(f"[Rebalance Error] Customer {customer.id}: {e}")
        return False


@shop_admin_required
def admin_delivery_edit(request, delivery_id):
    user = request.user
    entry = get_object_or_404(models.DailyDelivery, id=delivery_id, admin=user)
    customers = models.Customer.objects.filter(shop__admin=user)
    staff_qs = models.Staff.objects.filter(admin=user)
    can_types = models.CanType.objects.filter(admin=user, enabled=True)

    if request.method == 'POST':
        customer_id = request.POST.get('customer_id')
        staff_id = request.POST.get('staff_id')
        can_type_id = request.POST.get('can_type')
        quantity = request.POST.get('quantity')
        empty_cans = request.POST.get('empty_cans')

        is_ajax = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

        def ajax_error(msg, redirect_name='admin_delivery_edit', *args):
            if is_ajax:
                return JsonResponse({'ok': False, 'message': str(msg)})
            else:
                messages.error(request, str(msg))
                return redirect(redirect_name, *args)

        def ajax_success(msg, redirect_name='deliveries_list', *args):
            if is_ajax:
                return JsonResponse({'ok': True, 'message': str(msg)})
            else:
                messages.success(request, str(msg))
                return redirect(redirect_name, *args)

        if not (customer_id and can_type_id and quantity):
            return ajax_error(_('Please provide all required fields'), 'admin_delivery_edit', entry.id)
        try:
            customer = models.Customer.objects.get(id=customer_id, shop__admin=user)
            can_type = models.CanType.objects.get(id=can_type_id, admin=user)
        except models.Customer.DoesNotExist:
            return ajax_error(_('Invalid customer selected'), 'admin_delivery_edit', entry.id)
        except models.CanType.DoesNotExist:
            return ajax_error(_('Invalid can type selected'), 'admin_delivery_edit', entry.id)

        try:
            if int(can_type_id) != int(entry.can_type_id):
                try:
                    current_ct = models.CanType.objects.get(id=entry.can_type_id)
                    if not getattr(current_ct, 'enabled', True):
                        return ajax_error(_('Cannot change can type for this delivery because its current can type has been disabled.'), 'admin_delivery_edit', entry.id)
                except Exception:
                    pass
        except Exception:
            pass

        staff = None
        if staff_id and staff_id != 'admin':
            try:
                staff = models.Staff.objects.get(id=staff_id, admin=user)
            except models.Staff.DoesNotExist:
                return ajax_error(_('Invalid staff selected'), 'admin_delivery_edit', entry.id)

        try:
            qty = int(quantity)
            if qty < 1:
                raise ValueError()
        except Exception:
            return ajax_error(_('Quantity must be a whole number greater than 0'), 'admin_delivery_edit', entry.id)

        try:
            empty_val = int(empty_cans) if empty_cans not in (None, '') else 0
            if empty_val < 0:
                raise ValueError()
        except Exception:
            return ajax_error(_('Empty cans must be a whole number 0 or greater'), 'admin_delivery_edit', entry.id)

        rate_given = None
        rate_raw = request.POST.get('rate_given')
        if rate_raw not in (None, ''):
            try:
                rate_given = Decimal(rate_raw)
            except (InvalidOperation, ValueError):
                return ajax_error(_('Invalid rate entered'), 'admin_delivery_edit', entry.id)
        if rate_given is None:
            rate_given = can_type.price

        entry.customer = customer
        entry.staff = staff
        entry.can_type = can_type
        entry.quantity_delivered = qty
        entry.empty_cans_received = empty_val
        entry.rate_given = rate_given
        entry.save()
        return ajax_success(_('Delivery updated for %(name)s') % {'name': customer.display_name}, 'deliveries_list')

    customer_can_map = {}
    for c in customers:
        entries = []
        for ce in models.CustomerCanType.objects.filter(customer=c):
            entries.append({'id': ce.can_type.id, 'name': str(ce.can_type), 'price': str(ce.price)})
        customer_can_map[c.id] = entries
    return render(request, 'accounts/delivery_form.html', {'customers': customers, 'staff_list': staff_qs, 'can_types': can_types, 'delivery': entry, 'today': timezone.now().date(), 'customer_can_map': customer_can_map})


@shop_admin_required
@require_POST
def admin_delivery_delete(request, delivery_id):
    """Safely delete a delivery and fully rebalance the ledger."""
    user = request.user
    delivery = get_object_or_404(models.DailyDelivery, id=delivery_id, admin=user)

    if delivery.payment_status == 'paid' and models.Payment.objects.filter(delivery=delivery, status='completed').exists():
        messages.error(request, _('Cannot delete delivery: It has completed payments. Delete payments first.'))
        return redirect('deliveries_list')

    customer = delivery.customer
    admin_user = user

    try:
        with transaction.atomic():
            models.CanTransaction.objects.filter(
                related_delivery=delivery,
                admin=admin_user
            ).delete()

            models.ReceivableLedger.objects.filter(
                delivery=delivery,
                admin=admin_user
            ).delete()

            models.Payment.objects.filter(
                delivery=delivery,
                admin=admin_user
            ).delete()

            delivery.delete()

            success = rebalance_customer_ledger(customer, admin_user)

            if not success:
                raise Exception("Ledger rebalancing failed")

    except Exception as e:
        messages.error(request, _('Failed to delete delivery: {}').format(str(e)))
        return redirect('deliveries_list')

    messages.success(request, _('Delivery deleted successfully and ledger rebalanced.'))
    return redirect('deliveries_list')


@shop_admin_required
@require_POST
def delete_payment(request, payment_id):
    """Delete payment and properly rebalance ReceivableLedger."""
    payment = get_object_or_404(models.Payment, id=payment_id, admin=request.user)

    customer = payment.payer_customer
    invoice = payment.invoice
    delivery = payment.delivery

    try:
        with transaction.atomic():
            models.ReceivableLedger.objects.filter(
                payment=payment,
                admin=request.user
            ).delete()

            if delivery:
                models.ReceivableLedger.objects.filter(
                    delivery=delivery,
                    admin=request.user
                ).delete()

                models.ReceivableLedger.objects.create(
                    admin=request.user,
                    shop=getattr(request.user, 'shop', None),
                    customer=delivery.customer,
                    date=delivery.delivery_date,
                    transaction_type='delivery',
                    debit=Decimal(delivery.quantity_delivered or 0) * Decimal(delivery.rate_given or 0),
                    credit=Decimal('0'),
                    delivery=delivery,
                    description=f"Delivery #{delivery.id} - {delivery.quantity_delivered} cans",
                )

            if customer:
                rebalance_customer_ledger(customer, request.user)

            if invoice:
                try:
                    invoice.save()
                except Exception:
                    pass

            if delivery:
                try:
                    paid_total = models.Payment.objects.filter(
                        status='completed',
                        delivery=delivery
                    ).aggregate(total=Sum('amount'))['total'] or Decimal('0')

                    delivery_amount = Decimal(delivery.quantity_delivered or 0) * Decimal(delivery.rate_given or 0)

                    if paid_total >= delivery_amount and delivery_amount > 0:
                        delivery.payment_status = 'paid'
                    elif paid_total > 0:
                        delivery.payment_status = 'partial'
                    else:
                        delivery.payment_status = 'unpaid'
                    delivery.save()
                except Exception:
                    pass

            payment.delete()

    except Exception as e:
        messages.error(request, f'Failed to delete payment: {str(e)}')
        return redirect('payment_detail', payment_id=payment_id)

    messages.success(request, 'Payment deleted successfully and ledger rebalanced.')
    return redirect('payments_list')


@shop_admin_required
@require_POST
def delete_all_payments(request):
    """Delete all payments for the current admin with username confirmation."""
    confirm_username = request.POST.get('confirm_username', '').strip()

    if confirm_username != request.user.username:
        messages.error(request, _('Username confirmation failed. All payments were NOT deleted.'))
        return redirect('payments_list')

    payments_to_delete = models.Payment.objects.filter(admin=request.user)

    if not payments_to_delete.exists():
        messages.warning(request, _('No payments found to delete.'))
        return redirect('payments_list')

    affected_customers = set()
    affected_invoices = set()

    for payment in payments_to_delete:
        if payment.payer_customer:
            affected_customers.add(payment.payer_customer)
        if payment.invoice:
            affected_invoices.add(payment.invoice)

    count = payments_to_delete.count()

    models.ReceivableLedger.objects.filter(
        payment__in=payments_to_delete,
        admin=request.user
    ).delete()

    payments_to_delete.delete()

    # After payments_to_delete.delete(), reset delivery payment_status for affected deliveries
    affected_delivery_ids = list(
        models.Payment.objects.none().values_list('delivery_id', flat=True)  # already deleted
    )
    # Reset all deliveries that now have zero completed payments
    models.DailyDelivery.objects.filter(
        admin=request.user,
        payment_status='paid'
    ).exclude(
        id__in=models.Payment.objects.filter(
            status='completed', admin=request.user
        ).values_list('delivery_id', flat=True)
    ).update(payment_status='unpaid')

    for customer in affected_customers:
        rebalance_customer_ledger(customer, request.user)

    for invoice in affected_invoices:
        try:
            paid_total = invoice.get_paid_total()
        except Exception:
            paid_total = invoice.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')

        if paid_total >= (invoice.total_amount or Decimal('0')):
            invoice.status = 'paid'
        elif paid_total > Decimal('0'):
            invoice.status = 'partial'
        else:
            invoice.status = 'unpaid'
        invoice.save()

    messages.success(request, _('Successfully deleted %(count)d payment(s). All ledgers rebalanced and invoices updated.') % {'count': count})
    return redirect('payments_list')


# ------------------ STAFF (employee) CRUD for shop admin ------------------
@shop_admin_required
def staff_list(request):
    user = request.user
    staff_qs = models.Staff.objects.filter(admin=user).order_by('-id')
    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = request.GET.get('mobile') == '1' or any(k in ua for k in ('mobile', 'android', 'iphone', 'phone', 'ios'))
    if is_mobile:
        return render(request, 'accounts/staff_mobile.html', {'staff_list': staff_qs})
    return render(request, 'accounts/staff_list.html', {'staff_list': staff_qs})


# ------------------ CAN TYPES (shop admin) ------------------
@shop_admin_required
def can_types_list(request):
    user = request.user
    can_types_qs = models.CanType.objects.filter(admin=user, enabled=True).order_by('-id')
    shop = models.Shop.objects.filter(admin=user).first()
    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = request.GET.get('mobile') == '1' or any(k in ua for k in ('mobile', 'android', 'iphone', 'phone', 'ios'))
    if is_mobile:
        return render(request, 'accounts/can_types_mobile.html', {'can_types': can_types_qs, 'shop': shop})
    return render(request, 'accounts/can_types_list.html', {'can_types': can_types_qs, 'shop': shop})


@shop_admin_required
def can_type_create(request):
    user = request.user
    if request.method == 'POST':
        name = request.POST.get('can_type') or ''
        price = request.POST.get('price') or '0'
        try:
            price_val = Decimal(price)
        except Exception:
            messages.error(request, _('Invalid price'))
            return redirect('can_type_create')
        if models.CanType.objects.filter(admin=user, can_type__iexact=name).exists():
            messages.error(request, _('A can type with this name already exists'))
            return redirect('can_type_create')
        try:
            ct = models.CanType.objects.create(admin=user, can_type=name, price=price_val)
        except Exception as e:
            messages.error(request, _('Failed to create can type: %(err)s') % {'err': str(e)})
            return redirect('can_type_create')
        try:
            customers = models.Customer.objects.filter(shop__admin=user)
            entries = []
            for c in customers:
                try:
                    if not models.CustomerCanType.objects.filter(admin=user, customer=c, can_type=ct).exists():
                        entries.append(models.CustomerCanType(admin=user, customer=c, can_type=ct, price=ct.price))
                except Exception:
                    continue
            if entries:
                models.CustomerCanType.objects.bulk_create(entries)
        except Exception:
            messages.warning(request, _('Could not auto-assign can type to all customers.'))

        messages.success(request, _('Can type %(name)s created') % {'name': ct.can_type})
        return redirect('can_types_list')
    shop = models.Shop.objects.filter(admin=user).first()
    return render(request, 'accounts/can_type_form.html', {'shop': shop})


@shop_admin_required
def can_type_edit(request, can_type_id):
    user = request.user
    ct = get_object_or_404(models.CanType, id=can_type_id, admin=user)
    if request.method == 'POST':
        new_name = request.POST.get('can_type') or ct.can_type
        price = request.POST.get('price') or ct.price
        try:
            ct.price = Decimal(price)
        except Exception:
            messages.error(request, _('Invalid price'))
            return redirect('can_type_edit', can_type_id=ct.id)
        if new_name.lower() != ct.can_type.lower() and models.CanType.objects.filter(admin=user, can_type__iexact=new_name).exclude(id=ct.id).exists():
            messages.error(request, _('A can type with this name already exists'))
            return redirect('can_type_edit', can_type_id=ct.id)
        ct.can_type = new_name
        try:
            ct.save()
        except Exception as e:
            messages.error(request, _('Failed to update can type: %(err)s') % {'err': str(e)})
            return redirect('can_type_edit', can_type_id=ct.id)
        messages.success(request, _('Can type updated'))
        return redirect('can_types_list')
    shop = models.Shop.objects.filter(admin=user).first()
    return render(request, 'accounts/can_type_form.html', {'can_type': ct, 'shop': shop})


@shop_admin_required
@require_POST
def can_type_delete(request, can_type_id):
    user = request.user
    ct = get_object_or_404(models.CanType, id=can_type_id, admin=user)
    deliveries_exist = models.DailyDelivery.objects.filter(can_type=ct).exists()
    if deliveries_exist:
        ct.enabled = False
        try:
            ct.save()
        except Exception:
            pass
        messages.success(request, _('Can type has been deleted!'))
        return redirect('can_types_list')
    ct.delete()
    messages.success(request, _('Can type deleted'))
    return redirect('can_types_list')


@shop_admin_required
def staff_deliveries(request, staff_id):
    user = request.user
    staff = get_object_or_404(models.Staff, id=staff_id, admin=user)
    deliveries = models.DailyDelivery.objects.filter(admin=user, staff=staff).order_by('-delivery_date')
    return render(request, 'accounts/staff_deliveries.html', {'staff': staff, 'deliveries': deliveries})


def _parse_decimal_input(val, default=Decimal('0')):
    """Parse user-provided numeric input into a Decimal."""
    if val is None:
        return default
    if isinstance(val, Decimal):
        return val
    try:
        s = str(val).strip()
        if s == '':
            return default
        import re
        cleaned = re.sub(r"[^0-9\.\-]", "", s)
        if cleaned in ("", ".", "-", "-."):
            return default
        return Decimal(cleaned)
    except (InvalidOperation, Exception):
        return default


@shop_admin_required
def staff_create(request):
    user = request.user
    customers = models.Customer.objects.filter(shop__admin=user)
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        phone = request.POST.get('phone_number')
        cnic = request.POST.get('cnic')
        address = request.POST.get('address')
        salary_raw = request.POST.get('salary')
        salary = _parse_decimal_input(salary_raw, Decimal('0'))
        shift_start = request.POST.get('shift_start') or None
        shift_end = request.POST.get('shift_end') or None

        if not username or not password:
            messages.error(request, _('Username and password are required'))
            return redirect('staff_create')
        if models.User.objects.filter(username=username).exists():
            messages.error(request, _('Username already exists'))
            return redirect('staff_create')

        if phone:
            if models.Staff.objects.filter(phone_number=phone).exists():
                messages.error(request, _('Phone number already used by another employee'))
                return redirect('staff_create')

        new_user = models.User.objects.create_user(username=username, password=password, role='staff', shop_type=user.shop_type, address=address)
        new_user.shop = user.shop
        new_user.save()

        staff = models.Staff.objects.create(
            admin=user,
            user=new_user,
            first_name=first_name,
            last_name=last_name,
            phone_number=phone,
            cnic=cnic,
            address=address,
            salary=salary,
            shift_start=shift_start or None,
            shift_end=shift_end or None,
        )
        assigned_ids = request.POST.getlist('assigned_customers')
        if assigned_ids:
            try:
                staff.customers.set([int(cid) for cid in assigned_ids])
            except Exception:
                pass

        messages.success(request, _('Employee %(name)s created') % {'name': f"{first_name} {last_name}"})
        return redirect('staff_list')

    return render(request, 'accounts/staff_form.html', {'customers': customers})


@shop_admin_required
def staff_edit(request, staff_id):
    user = request.user
    staff = get_object_or_404(models.Staff, id=staff_id, admin=user)
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username and staff.user and username != staff.user.username:
            if models.User.objects.filter(username=username).exists():
                messages.error(request, _('Username already exists'))
                return redirect('staff_edit', staff_id=staff.id)
            staff.user.username = username
            staff.user.save()
            messages.success(request, _('Username updated'))
        password_changed = False
        if password and staff.user:
            staff.user.set_password(password)
            staff.user.save()
            try:
                request.session[f'staff_new_password_{staff.id}'] = password
                request.session.modified = True
            except Exception:
                pass
            password_changed = True
            messages.success(request, _('Password updated'))

        staff.first_name = request.POST.get('first_name') or staff.first_name
        staff.last_name = request.POST.get('last_name') or staff.last_name
        new_phone = request.POST.get('phone_number') or staff.phone_number
        if new_phone and new_phone != (staff.phone_number or ''):
            if models.Staff.objects.filter(phone_number=new_phone).exclude(id=staff.id).exists():
                messages.error(request, _('Phone number already used by another employee'))
                return redirect('staff_edit', staff_id=staff.id)
        staff.phone_number = new_phone or staff.phone_number
        staff.cnic = request.POST.get('cnic') or staff.cnic
        staff.address = request.POST.get('address') or staff.address
        staff.salary = request.POST.get('salary') or staff.salary
        staff.shift_start = request.POST.get('shift_start') or staff.shift_start
        staff.shift_end = request.POST.get('shift_end') or staff.shift_end
        staff.save()
        assigned_ids = request.POST.getlist('assigned_customers')
        if assigned_ids:
            try:
                staff.customers.set([int(cid) for cid in assigned_ids])
            except Exception:
                staff.customers.clear()
        else:
            staff.customers.clear()

        messages.success(request, _('Employee updated'))
        if password_changed:
            return redirect('staff_edit', staff_id=staff.id)
        return redirect('staff_list')
    customers = models.Customer.objects.filter(shop__admin=user)
    new_password = None
    try:
        new_password = request.session.pop(f'staff_new_password_{staff.id}', None)
    except Exception:
        new_password = None
    return render(request, 'accounts/staff_form.html', {'staff': staff, 'customers': customers, 'new_password': new_password})


@shop_admin_required
@require_POST
def staff_delete(request, staff_id):
    user = request.user
    staff = get_object_or_404(models.Staff, id=staff_id, admin=user)
    username = staff.user.username if staff.user else ''
    try:
        has_deliveries = models.DailyDelivery.objects.filter(staff=staff).exists()
    except Exception:
        has_deliveries = False

    if has_deliveries:
        messages.error(request, _('Cannot delete employee %(username)s: delivery entries exist. Delete or reassign entries first.') % {'username': username})
        return redirect('staff_list')

    try:
        if staff.user:
            staff.user.delete()
    except Exception:
        pass
    staff.delete()
    messages.success(request, _('Employee %(username)s deleted') % {'username': username})
    return redirect('staff_list')


from django.views.decorators.http import require_POST

@shop_admin_required
def customer_unpaid_json(request, customer_id):
    """Return unpaid/partially-paid invoices and deliveries for `customer_id` (JSON)."""
    user = request.user
    from django.db.models import Q
    try:
        cid = int(customer_id)
    except Exception:
        return JsonResponse({'ok': False, 'error': 'Invalid customer id'}, status=400)

    invoices_out = []
    inv_qs = models.Invoice.objects.filter(admin=user, customer_id=cid).exclude(status='paid').order_by('-created_at')
    for inv in inv_qs:
        try:
            delivery_ids = [d for d in inv.items.values_list('delivery', flat=True) if d]
            paid_total = models.Payment.objects.filter(status='completed').filter(
                Q(invoice=inv) | Q(delivery_id__in=delivery_ids)
            ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
        except Exception:
            paid_total = inv.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
        remaining = (inv.total_amount or Decimal('0')) - paid_total
        if remaining > Decimal('0'):
            invoices_out.append({'id': inv.id, 'invoice_number': inv.invoice_number, 'remaining': str(remaining), 'label': f"{inv.invoice_number} — {inv.customer.display_name} (remaining: {remaining})"})

    deliveries_out = []
    del_qs = models.DailyDelivery.objects.filter(admin=user, customer_id=cid, payment_status__in=['unpaid', 'partial']).order_by('-delivery_date')
    for d in del_qs:
        try:
            delivery_amount = (Decimal(d.quantity_delivered or 0) * (Decimal(d.rate_given or 0)))
        except Exception:
            delivery_amount = Decimal('0')
        try:
            paid_total = models.Payment.objects.filter(status='completed', delivery=d).aggregate(total=Sum('amount'))['total'] or Decimal('0')
        except Exception:
            paid_total = Decimal('0')
        remaining = delivery_amount - paid_total
        if remaining > Decimal('0'):
            deliveries_out.append({'id': d.id, 'label': f"Delivery #{d.id} — {d.customer.display_name} — {d.delivery_date} (remaining: {remaining})", 'remaining': str(remaining), 'amount': str(delivery_amount), 'customer_id': d.customer_id})

    return JsonResponse({'ok': True, 'invoices': invoices_out, 'deliveries': deliveries_out})


@shop_admin_required
def receive_payment(request):
    user = request.user

    invoices_qs = models.Invoice.objects.filter(admin=user).exclude(status='paid').order_by('-created_at')
    invoices = []
    for inv in invoices_qs:
        try:
            delivery_ids = [d for d in inv.items.values_list('delivery', flat=True) if d]
            paid_total = models.Payment.objects.filter(status='completed').filter(
                Q(invoice=inv) | Q(delivery_id__in=delivery_ids)
            ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
        except Exception:
            paid_total = inv.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
        remaining = (inv.total_amount or Decimal('0')) - paid_total
        invoices.append({'obj': inv, 'remaining': remaining})

    customers = models.Customer.objects.filter(shop__admin=user)

    deliveries_qs = models.DailyDelivery.objects.filter(admin=user).filter(
        payment_status__in=['unpaid', 'partial']
    ).order_by('-delivery_date')

    deliveries = []
    for d in deliveries_qs:
        try:
            delivery_amount = Decimal(d.quantity_delivered or 0) * Decimal(d.rate_given or 0)
        except Exception:
            delivery_amount = Decimal('0')
        paid_total = models.Payment.objects.filter(status='completed', delivery=d).aggregate(
            total=Sum('amount')
        )['total'] or Decimal('0')
        remaining = delivery_amount - paid_total
        if remaining > Decimal('0'):
            deliveries.append({
                'obj': d,
                'remaining': remaining,
                'amount': delivery_amount
            })

    if request.method == 'POST':
        invoice_id = request.POST.get('invoice_id') or None
        delivery_id = request.POST.get('delivery_id') or None
        amount_raw = request.POST.get('amount')
        method = request.POST.get('method') or 'cash'
        transaction_id = request.POST.get('transaction_id') or ''
        status = request.POST.get('status') or 'completed'

        try:
            amount_decimal = Decimal(amount_raw)
        except Exception:
            amount_decimal = Decimal('0')

        is_ajax = request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

        def ajax_error(msg):
            if is_ajax:
                return JsonResponse({'ok': False, 'message': str(msg)}, status=400)
            messages.error(request, str(msg))
            return redirect('receive_payment')

        def ajax_success(msg):
            if is_ajax:
                return JsonResponse({'ok': True, 'message': str(msg)})
            messages.success(request, str(msg))
            return redirect('payments_list')

        if invoice_id and delivery_id:
            return ajax_error(_('Please select either an invoice or a delivery, not both'))
        if not invoice_id and not delivery_id:
            return ajax_error(_('Please select an invoice or a delivery'))

        payer_customer = None
        if delivery_id:
            try:
                delivery_obj = models.DailyDelivery.objects.get(id=delivery_id, admin=user)
                payer_customer = delivery_obj.customer
            except models.DailyDelivery.DoesNotExist:
                return ajax_error(_('Invalid delivery selected'))
        elif invoice_id:
            try:
                invoice_obj = models.Invoice.objects.get(id=invoice_id, admin=user)
                payer_customer = invoice_obj.customer
            except models.Invoice.DoesNotExist:
                return ajax_error(_('Invalid invoice selected'))

        if not payer_customer:
            return ajax_error(_('Could not determine customer for this payment'))

        try:
            with transaction.atomic():
                payment = models.Payment.objects.create(
                    invoice_id=invoice_id,
                    delivery_id=delivery_id,
                    admin=user,
                    shop=getattr(user, 'shop', None),
                    payer_customer=payer_customer,
                    amount=amount_decimal,
                    method=method,
                    transaction_id=transaction_id,
                    status=status,
                    paid_at=timezone.now() if status == 'completed' else None,
                )

                if status == 'completed':
                    models.ReceivableLedger.objects.filter(
                        payment=payment,
                        transaction_type='payment'
                    ).delete()

                    models.ReceivableLedger.objects.create(
                        admin=user,
                        shop=getattr(user, 'shop', None),
                        customer=payer_customer,
                        date=timezone.now().date(),
                        transaction_type='payment',
                        debit=Decimal('0.00'),
                        credit=amount_decimal,
                        payment=payment,
                        description=f"Payment received - {method}",
                        notes=f"Payment #{payment.id} | {transaction_id or 'No TX ID'}"
                    )

                if payment.invoice:
                    try:
                        payment.invoice.save()
                    except Exception:
                        pass

        except Exception as e:
            return ajax_error(_('Failed to record payment: %(error)s') % {'error': str(e)})

        return ajax_success(_('Payment recorded successfully and ledger updated'))

    return render(request, 'accounts/receive_payment.html', {
        'invoices': invoices,
        'customers': customers,
        'deliveries': deliveries
    })


@shop_admin_required
@require_POST
def mark_payment_received(request, payment_id):
    payment = get_object_or_404(models.Payment, id=payment_id, admin=request.user)
    if payment.status != 'completed':
        if payment.invoice:
            try:
                paid_total = payment.invoice.get_paid_total()
            except Exception:
                paid_total = payment.invoice.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
            remaining = (payment.invoice.total_amount or Decimal('0')) - paid_total
            if payment.amount > remaining:
                messages.error(request, _('Cannot mark payment as completed: exceeds remaining invoice amount (remaining %(remaining)s)') % {'remaining': remaining})
                return redirect('payment_detail', payment_id=payment.id)
        payment.status = 'completed'
        payment.paid_at = timezone.now()
        payment.save()

        if payment.invoice:
            try:
                paid_total = payment.invoice.get_paid_total()
            except Exception:
                paid_total = payment.invoice.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
            if paid_total >= payment.invoice.total_amount:
                payment.invoice.status = 'paid'
            elif paid_total > Decimal('0'):
                payment.invoice.status = 'partial'
            payment.invoice.save()

    return redirect('payment_detail', payment_id=payment.id)


@csrf_exempt
def payment_webhook(request):
    if request.method != 'POST':
        return HttpResponseBadRequest('Invalid method')
    try:
        data = json.loads(request.body.decode('utf-8'))
    except Exception:
        return HttpResponseBadRequest('Invalid JSON')

    tx = data.get('transaction_id')
    amt = data.get('amount')
    inv_num = data.get('invoice_number')
    status = data.get('status')

    try:
        amount_decimal = Decimal(str(amt))
    except Exception:
        amount_decimal = Decimal('0')

    invoice = None
    if inv_num:
        invoice = models.Invoice.objects.filter(invoice_number=inv_num).first()

    if invoice and status == 'completed':
        try:
            paid_total = invoice.get_paid_total()
        except Exception:
            paid_total = invoice.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
        remaining = (invoice.total_amount or Decimal('0')) - paid_total
        if amount_decimal > remaining:
            return JsonResponse({'ok': False, 'error': 'Payment amount exceeds remaining invoice amount'}, status=400)

    try:
        payment = models.Payment.objects.create(
            invoice=invoice,
            admin=invoice.admin if invoice else None,
            shop=invoice.shop if invoice else None,
            payer_customer=invoice.customer if invoice else None,
            amount=amount_decimal,
            method=data.get('method') or 'gateway',
            transaction_id=tx,
            status=status or 'pending',
            paid_at=timezone.now() if (status == 'completed') else None,
        )
    except Exception as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=400)

    if payment.status == 'completed' and payment.invoice:
        try:
            paid_total = payment.invoice.get_paid_total()
        except Exception:
            paid_total = payment.invoice.payments.filter(status='completed').aggregate(total=Sum('amount'))['total'] or Decimal('0')
        if paid_total >= payment.invoice.total_amount:
            payment.invoice.status = 'paid'
        elif paid_total > Decimal('0'):
            payment.invoice.status = 'partial'
        payment.invoice.save()

    return JsonResponse({'ok': True, 'payment_id': payment.id})