from django.test import TestCase

# FBR integration tests removed — FBR feature has been removed from the project
class FbrIntegrationTests(TestCase):
    pass

