"""
views_invoicing_fixed.py
=========================
Drop-in replacements for all invoice-related functions in accounts/views.py.

BUGS FIXED
──────────
1. "Invoice already exists" after delete+regenerate
   Cause: signals.py auto-attached deliveries to invoices after every
   DailyDelivery.save(), making invoice_items__isnull=True always False.
   Fix:   That signal removed. Explicit select_for_update check in regen.

2. Discount and tax applied per-line instead of on invoice total
   Cause: compute_line_totals() was called in InvoiceItem.save() applying
   discount_percent and tax_rate to each delivery row individually.
   Fix:   Lines store raw gross only. Discount+tax applied ONCE on subtotal
   in _build_invoice_context() and Invoice._recompute_summary().

3. Flat discount double/triple counted
   Cause: Applied in InvoiceItem.save() + _recompute_summary() + _build_invoice_context().
   Fix:   Applied in exactly ONE place: _build_invoice_context() for display,
   and _recompute_summary() for storage. Not in InvoiceItem at all.

4. invoice_detail had a second independent total calculation that could disagree
   Fix:   Uses _build_invoice_context() as the only source of truth.

5. Cache not cleared on invoice delete
   Fix:   All delete paths call cache.delete().

6. Invoice number collision on rapid regeneration
   Fix:   Uses microsecond timestamp (%f) in invoice_number.

DISCOUNT / TAX DISPLAY BREAKDOWN (matches what customer sees on invoice):
   Subtotal        = Σ(qty × rate)             ← sum of all delivery lines (gross)
   − Discount      = pct_discount + flat        ← applied once on subtotal
   = After Discount
   + Tax           = after_discount × tax_rate  ← applied on after-discount amount
   = Invoice Total
   − Already Paid
   = Net Payable
"""

from decimal import Decimal
from django.contrib import messages
from django.core.cache import cache
from django.db import transaction, IntegrityError
from django.db.models import Sum, Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.template.loader import render_to_string
from django.utils import timezone
from django.utils.translation import gettext as _
from django.views.decorators.http import require_POST
import io

from accounts.decorators import shop_admin_required
from accounts import models

try:
    from xhtml2pdf import pisa
except Exception:
    pisa = None


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: resolve admin for request
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_admin_user_for_request(request):
    try:
        if getattr(request.user, 'role', None) == 'staff':
            st = models.Staff.objects.filter(user=request.user).select_related('admin').first()
            if st:
                return st.admin
    except Exception:
        pass
    return request.user


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: compute invoice-level discount and tax (on total, not per line)
# ─────────────────────────────────────────────────────────────────────────────

def _compute_invoice_totals(gross_subtotal, customer):
    """
    Apply discount and tax at invoice TOTAL level.

    Parameters
    ----------
    gross_subtotal : Decimal  — Σ(qty × unit_price) across all items
    customer       : Customer instance or None

    Returns
    -------
    dict with keys: discount_pct, discount_flat, total_discount,
                    after_discount, tax_rate, tax_amount, display_total,
                    has_discount, has_tax
    """
    discount_pct  = Decimal('0')
    discount_flat = Decimal('0')
    tax_rate      = Decimal('0')
    is_exempt     = True

    if customer:
        try:
            discount_pct = Decimal(str(customer.discount_percent or 0))
        except Exception:
            pass
        try:
            discount_flat = Decimal(str(customer.discount_flat or 0))
        except Exception:
            pass
        try:
            is_exempt = bool(customer.is_tax_exempt)
        except Exception:
            pass
        if not is_exempt:
            try:
                tax_rate = Decimal(str(customer.tax_rate or 0))
            except Exception:
                pass

    pct_discount   = gross_subtotal * discount_pct / Decimal('100')
    total_discount = pct_discount + discount_flat
    after_discount = max(gross_subtotal - total_discount, Decimal('0'))
    tax_amount     = (after_discount * tax_rate / Decimal('100')) if not is_exempt else Decimal('0')
    display_total  = after_discount + tax_amount

    return {
        'discount_pct':   discount_pct,
        'discount_flat':  discount_flat,
        'total_discount': total_discount,
        'after_discount': after_discount,
        'tax_rate':       tax_rate,
        'tax_amount':     tax_amount,
        'display_total':  display_total,
        'has_discount':   (discount_pct > 0 or discount_flat > 0),
        'has_tax':        (not is_exempt and tax_rate > 0),
    }


def _compute_invoice_totals_from_snapshot(invoice, gross_subtotal):
    """
    Apply discount and tax using frozen snapshots on the invoice.
    Customer rate changes after invoice creation do NOT affect already generated invoices.
    """
    discount_pct  = getattr(invoice, 'discount_percent_snapshot', Decimal('0')) or Decimal('0')
    discount_flat = getattr(invoice, 'discount_flat_snapshot', Decimal('0')) or Decimal('0')
    tax_rate      = getattr(invoice, 'tax_rate_snapshot', Decimal('0')) or Decimal('0')
    is_exempt     = getattr(invoice, 'is_tax_exempt_snapshot', True)

    if not getattr(invoice, 'snapshots_frozen', False):
        customer = None
        try:
            customer = invoice.customer
        except Exception:
            pass
        if customer:
            try:
                discount_pct = Decimal(str(customer.discount_percent or 0))
            except Exception:
                pass
            try:
                discount_flat = Decimal(str(customer.discount_flat or 0))
            except Exception:
                pass
            try:
                is_exempt = bool(customer.is_tax_exempt)
            except Exception:
                pass
            if not is_exempt:
                try:
                    tax_rate = Decimal(str(customer.tax_rate or 0))
                except Exception:
                    pass

    pct_discount   = gross_subtotal * discount_pct / Decimal('100')
    total_discount = pct_discount + discount_flat
    after_discount = max(gross_subtotal - total_discount, Decimal('0'))
    tax_amount     = (after_discount * tax_rate / Decimal('100')) if not is_exempt else Decimal('0')
    display_total  = after_discount + tax_amount

    return {
        'discount_pct':   discount_pct,
        'discount_flat':  discount_flat,
        'total_discount': total_discount,
        'after_discount': after_discount,
        'tax_rate':       tax_rate,
        'tax_amount':     tax_amount,
        'display_total':  display_total,
        'has_discount':   (discount_pct > 0 or discount_flat > 0),
        'has_tax':        (not is_exempt and tax_rate > 0),
    }


# ─────────────────────────────────────────────────────────────────────────────
# SINGLE SOURCE OF TRUTH: build invoice context for all views
# ─────────────────────────────────────────────────────────────────────────────

def _build_invoice_context(invoice):
    """
    Build the template context for invoice_detail, PDF, and send views.

    Totals breakdown (discount/tax on TOTAL, not per line):
        Subtotal        = Σ(qty × rate per delivery)
        − Discount      = subtotal × discount_pct% + flat_discount
        − − − − − − − − − − − − − − − − − − − −
        After Discount  = subtotal − total_discount
        + Tax           = after_discount × tax_rate%
        = Invoice Total (display_total)
        − Already Paid
        = Net Payable
    """
    items    = invoice.items.all().select_related('delivery', 'delivery__can_type')
    customer = invoice.customer

    # ── Per-item display (gross only, no per-line discount/tax) ──────────
    items_with_paid = []
    for it in items:
        # Ensure stored values are raw gross (fix any old per-line values)
        gross = (it.quantity or Decimal('0')) * (it.unit_price or Decimal('0'))
        if it.gross_amount != gross or it.line_total != gross:
            models.InvoiceItem.objects.filter(pk=it.pk).update(
                gross_amount    = gross,
                discount_amount = Decimal('0'),
                tax_amount      = Decimal('0'),
                line_total      = gross,
            )
            it.gross_amount    = gross
            it.discount_amount = Decimal('0')
            it.tax_amount      = Decimal('0')
            it.line_total      = gross

        # Per-line payment status (for row colouring in template)
        paid_for_item = Decimal('0')
        try:
            if it.delivery_id:
                paid_for_item = (
                    models.Payment.objects
                    .filter(status='completed', delivery_id=it.delivery_id)
                    .aggregate(total=Sum('amount'))['total'] or Decimal('0')
                )
        except Exception:
            pass

        row_status = (
            'paid'    if (it.line_total > 0 and paid_for_item >= it.line_total)
            else 'partial' if paid_for_item > 0
            else 'unpaid'
        )

        items_with_paid.append({
            'item':   it,
            'paid':   paid_for_item,
            'status': row_status,
        })

    # ── Invoice-level totals ──────────────────────────────────────────────
    if items_with_paid:
        gross_subtotal = sum(
            i['item'].gross_amount or Decimal('0') for i in items_with_paid
        )
    else:
        # Legacy invoice with no items — use stored subtotal
        gross_subtotal = invoice.subtotal or invoice.total_amount or Decimal('0')

    t = _compute_invoice_totals_from_snapshot(invoice, gross_subtotal)

    # ── Payments ──────────────────────────────────────────────────────────
    delivery_ids = invoice.get_delivery_ids()
    payments = (
        models.Payment.objects
        .filter(Q(invoice=invoice) | Q(delivery_id__in=delivery_ids))
        .distinct()
        .order_by('-created_at')
    )
    paid_total = (
        payments.filter(status='completed')
        .aggregate(total=Sum('amount'))['total'] or Decimal('0')
    )

    display_total = t['display_total']
    remaining     = max(display_total - paid_total, Decimal('0'))

    # ── Sync stored total if it drifted ──────────────────────────────────
    if items_with_paid and abs(invoice.total_amount - display_total) > Decimal('0.01'):
        try:
            models.Invoice.objects.filter(pk=invoice.pk).update(total_amount=display_total)
            invoice.total_amount = display_total
        except Exception:
            pass

    # ── Status ────────────────────────────────────────────────────────────
    if display_total == Decimal('0'):
        computed_status = 'paid' if (paid_total > 0 or invoice.status == 'paid') else 'unpaid'
    elif paid_total >= display_total:
        computed_status = 'paid'
    elif paid_total > Decimal('0'):
        computed_status = 'partial'
    else:
        computed_status = 'unpaid'

    try:
        status_map              = dict(models.Invoice.STATUS_CHOICES)
        computed_status_display = status_map.get(computed_status, computed_status.title())
    except Exception:
        computed_status_display = computed_status.title()

    return {
        'invoice':                invoice,
        'items':                  items,
        'items_with_paid':        items_with_paid,
        'payments':               payments,

        # ── Totals breakdown ──────────────────────────────────────────────
        'subtotal':               gross_subtotal,        # Σ(qty × rate), before discount
        'total_discount':         t['total_discount'],   # pct + flat, applied on subtotal
        'total_tax':              t['tax_amount'],        # applied on after-discount amount
        'display_total':          display_total,          # what customer owes in total
        'gross_payable':          display_total,          # alias
        'paid_amount':            paid_total,
        'net_payable':            remaining,
        'remaining':              remaining,

        'total_qty': sum(
            float(i['item'].quantity or 0) for i in items_with_paid
        ),

        # ── Status ────────────────────────────────────────────────────────
        'computed_status':        computed_status,
        'computed_status_display':computed_status_display,

        # ── Pricing flags for template conditionals ───────────────────────
        'has_discount':           t['has_discount'],
        'has_tax':                t['has_tax'],
        'customer_discount_pct':  t['discount_pct'],
        'customer_discount_flat': t['discount_flat'],
        'customer_tax_rate':      t['tax_rate'],
        'customer_tax_exempt':    (invoice.is_tax_exempt_snapshot if getattr(invoice, 'snapshots_frozen', False)
                                   else getattr(customer, 'is_tax_exempt', True)),
    }


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: attach deliveries to invoice (gross only, invoice-level discount/tax)
# ─────────────────────────────────────────────────────────────────────────────

def _attach_deliveries_to_invoice(invoice, deliveries):
    """
    Create or update InvoiceItem rows for each delivery.
 
    Uses get_or_create so that deliveries already attached by the auto-attach
    signal are updated rather than duplicated.
 
    Returns: Decimal — net invoice total (after discount+tax on total amount).
    """
    from decimal import Decimal
 
    customer    = invoice.customer
    gross_total = Decimal('0')
 
    for d in deliveries:
        # Determine unit price
        try:
            cust_ct    = models.CustomerCanType.objects.get(customer=customer, can_type=d.can_type)
            unit_price = Decimal(str(cust_ct.price))
        except Exception:
            unit_price = Decimal(str(
                getattr(d, 'rate_given', None)
                or getattr(d.can_type, 'price', 0)
                or 0
            ))
 
        qty   = Decimal(str(d.quantity_delivered or 0))
        gross = qty * unit_price
 
        # get_or_create: if auto-attach signal already created this item, update it
        item, created = models.InvoiceItem.objects.get_or_create(
            invoice  = invoice,
            delivery = d,
            defaults = {
                'description':     f"Delivery #{d.id} on {d.delivery_date}",
                'quantity':        qty,
                'unit_price':      unit_price,
                'gross_amount':    gross,
                'discount_amount': Decimal('0'),
                'tax_amount':      Decimal('0'),
                'line_total':      gross,
            }
        )
 
        if not created:
            # Update if values drifted
            if item.quantity != qty or item.unit_price != unit_price:
                models.InvoiceItem.objects.filter(pk=item.pk).update(
                    quantity        = qty,
                    unit_price      = unit_price,
                    gross_amount    = gross,
                    discount_amount = Decimal('0'),
                    tax_amount      = Decimal('0'),
                    line_total      = gross,
                    description     = f"Delivery #{d.id} on {d.delivery_date}",
                )
 
        gross_total += gross
 
    # Apply discount + tax ONCE on the subtotal
    discount_pct  = Decimal('0')
    discount_flat = Decimal('0')
    tax_rate      = Decimal('0')
    is_exempt     = True
 
    if customer:
        try:
            discount_pct = Decimal(str(customer.discount_percent or 0))
        except Exception:
            pass
        try:
            discount_flat = Decimal(str(customer.discount_flat or 0))
        except Exception:
            pass
        try:
            is_exempt = bool(customer.is_tax_exempt)
        except Exception:
            pass
        if not is_exempt:
            try:
                tax_rate = Decimal(str(customer.tax_rate or 0))
            except Exception:
                pass
 
    pct_disc       = gross_total * discount_pct / Decimal('100')
    total_discount = pct_disc + discount_flat
    after_discount = max(gross_total - total_discount, Decimal('0'))
    tax_amount     = (after_discount * tax_rate / Decimal('100')) if not is_exempt else Decimal('0')
    net_total      = after_discount + tax_amount
 
    return max(net_total, Decimal('0'))
# ─────────────────────────────────────────────────────────────────────────────
# HELPERS: invoice list filtering
# ─────────────────────────────────────────────────────────────────────────────

def _apply_invoice_filters(qs, customer_id=None, month_value=None, start_date=None, end_date=None):
    if customer_id:
        try:
            qs = qs.filter(customer_id=int(customer_id))
        except (TypeError, ValueError):
            pass

    if month_value:
        try:
            year, month = (int(x) for x in month_value.split('-'))
            qs = qs.filter(invoice_year=year, invoice_month=month)
        except Exception:
            pass

    if start_date:
        try:
            qs = qs.filter(created_at__date__gte=timezone.datetime.fromisoformat(start_date).date())
        except Exception:
            pass

    if end_date:
        try:
            qs = qs.filter(created_at__date__lte=timezone.datetime.fromisoformat(end_date).date())
        except Exception:
            pass

    return qs


# ─────────────────────────────────────────────────────────────────────────────
# INVOICE LIST
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
def invoices_list(request):
    import calendar
    from datetime import date as _date

    user = request.user
    customer_id = request.GET.get('customer_id')
    month_value = request.GET.get('month')
    start_date  = request.GET.get('start_date')
    end_date    = request.GET.get('end_date')

    qs = (
        models.Invoice.objects
        .filter(admin=user)
        .prefetch_related('items', 'payments')
        .order_by('-created_at')
    )
    qs = _apply_invoice_filters(qs, customer_id=customer_id, month_value=month_value,
                                start_date=start_date, end_date=end_date)

    customers = (
        models.Customer.objects
        .filter(shop__admin=user, invoices__admin=user)
        .distinct()
        .order_by('id')
    )

    invoices_with_meta = []
    for inv in qs:
        # Month / date range label
        month_label = date_range = ''
        if getattr(inv, 'invoice_year', None) and getattr(inv, 'invoice_month', None):
            try:
                month_label = _date(inv.invoice_year, inv.invoice_month, 1).strftime('%b %Y')
                start    = _date(inv.invoice_year, inv.invoice_month, 1)
                last_day = calendar.monthrange(inv.invoice_year, inv.invoice_month)[1]
                date_range = f"{start.strftime('%d %b %Y')} - {_date(inv.invoice_year, inv.invoice_month, last_day).strftime('%d %b %Y')}"
            except Exception:
                pass

        # Single source of truth for all totals
        ctx             = _build_invoice_context(inv)
        computed_status = ctx['computed_status']

        # Stamp attributes for template
        inv.computed_status = computed_status
        inv.subtotal        = ctx['subtotal']
        inv.total_discount  = ctx['total_discount']
        inv.total_tax       = ctx['total_tax']
        inv.display_total   = ctx['display_total']
        inv.total_amount    = ctx['display_total']
        inv.gross_payable   = ctx['display_total']
        inv.paid_amount     = ctx['paid_amount']
        inv.net_payable     = ctx['remaining']

        # Persist status drift
        if inv.status != computed_status:
            try:
                models.Invoice.objects.filter(pk=inv.pk).update(status=computed_status)
                inv.status = computed_status
            except Exception:
                pass

        invoices_with_meta.append({
            'invoice':    inv,
            'month_label': month_label,
            'date_range':  date_range,
        })

    ua        = request.META.get('HTTP_USER_AGENT', '').lower()
    is_mobile = request.GET.get('mobile') == '1' or any(
        k in ua for k in ('mobile', 'android', 'iphone', 'ipad', 'phone', 'ios')
    )
    template = 'accounts/invoices_mobile.html' if is_mobile else 'accounts/invoices.html'
    return render(request, template, {
        'invoices_with_meta': invoices_with_meta,
        'customers': customers,
        'selected_customer_id': customer_id or '',
        'selected_month': month_value or '',
        'selected_start_date': start_date or '',
        'selected_end_date': end_date or '',
    })


# ─────────────────────────────────────────────────────────────────────────────
# INVOICE DETAIL
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
def invoice_detail(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    ctx     = _build_invoice_context(invoice)

    # Persist status if it changed
    if invoice.status != ctx['computed_status']:
        try:
            models.Invoice.objects.filter(pk=invoice.pk).update(status=ctx['computed_status'])
            invoice.status = ctx['computed_status']
        except Exception:
            pass

    return render(request, 'accounts/invoice_detail.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# AUTO-GENERATE INVOICES  ← main fix for "already exists" bug
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
@require_POST
def auto_generate_invoices(request):
    """
    Generate one invoice per active customer for a completed month.
 
    Key fix: checks Invoice existence (not InvoiceItem presence) to decide
    whether to create. This works correctly alongside the auto-attach signal.
    """
    import calendar
    from datetime import date
 
    user        = request.user
    month_value = request.POST.get('month')
 
    if month_value:
        try:
            y, m     = (int(x) for x in month_value.split('-'))
            start    = date(y, m, 1)
            last_day = calendar.monthrange(y, m)[1]
            end      = date(y, m, last_day)
        except Exception:
            messages.error(request, _('Invalid month selected'))
            return redirect('admin_dashboard')
 
        today = timezone.now().date()
        if y == today.year and m == today.month:
            messages.error(request, _('Cannot generate invoices for the current running month.'))
            return redirect('admin_dashboard')
 
        customers = models.Customer.objects.filter(shop__admin=user, is_active=True)
        if not customers.exists():
            messages.info(request, _('No active customers found.'))
            return redirect('admin_dashboard')
 
        created_count    = 0
        skipped_exists   = 0
        skipped_no_deliv = 0
 
        for cust in customers:
            try:
                with transaction.atomic():
                    # ── Check: does an invoice already exist for this month? ───
                    # Use select_for_update to bypass ORM cache and read real DB state.
                    # This is the CORRECT check — not invoice_items__isnull=True.
                    already = (
                        models.Invoice.objects
                        .select_for_update()
                        .filter(customer_id=cust.id, invoice_year=y, invoice_month=m, admin_id=user.id)
                        .exists()
                    )
                    if already:
                        skipped_exists += 1
                        continue
 
                    # ── Find all deliveries for this customer + month ──────────
                    # NOTE: We do NOT filter invoice_items__isnull=True here.
                    # We want ALL deliveries for the month, whether or not they
                    # already have InvoiceItems from the auto-attach signal.
                    # _attach_deliveries_to_invoice uses get_or_create, so
                    # existing InvoiceItems are updated, not duplicated.
                    cust_deliveries = models.DailyDelivery.objects.filter(
                        admin=user,
                        customer=cust,
                        delivery_date__gte=start,
                        delivery_date__lte=end,
                    )
                    if not cust_deliveries.exists():
                        skipped_no_deliv += 1
                        continue
 
                    # ── Create invoice ────────────────────────────────────────
                    now_str        = timezone.now().strftime('%Y%m%d%H%M%S%f')
                    invoice_number = f"INV-{y}{m:02d}-{now_str}-{cust.id}"
 
                    invoice = models.Invoice.objects.create(
                        invoice_number = invoice_number,
                        admin          = user,
                        shop           = user.shop,
                        customer_id    = cust.id,
                        total_amount   = Decimal('0'),
                        status         = 'unpaid',
                        invoice_year   = y,
                        invoice_month  = m,
                        notes          = cust.invoice_notes or '',
                    )
 
                    # Attach all deliveries for the month (get_or_create = no dupes)
                    net_total = _attach_deliveries_to_invoice(invoice, cust_deliveries)
                    models.Invoice.objects.filter(pk=invoice.pk).update(total_amount=net_total)
                    invoice.total_amount = net_total
                    created_count += 1
 
            except IntegrityError:
                skipped_exists += 1
                continue
            except Exception as exc:
                messages.error(
                    request,
                    _('Failed to create invoice for %(name)s: %(error)s') % {
                        'name': cust.display_name, 'error': str(exc),
                    }
                )
                continue
 
        cache.delete(f"dashboard_{user.id}")
 
        if created_count:
            messages.success(
                request,
                _('Created %(count)s invoice(s) for %(month)s.') % {
                    'count': created_count, 'month': start.strftime('%b %Y'),
                }
            )
        if skipped_exists:
            messages.info(
                request,
                _('Skipped %(count)s customer(s) — invoices already exist for %(month)s.') % {
                    'count': skipped_exists, 'month': start.strftime('%b %Y'),
                }
            )
        if skipped_no_deliv:
            messages.info(
                request,
                _('Skipped %(count)s customer(s) — no deliveries in %(month)s.') % {
                    'count': skipped_no_deliv, 'month': start.strftime('%b %Y'),
                }
            )
        if not (created_count or skipped_exists or skipped_no_deliv):
            messages.info(request, _('No invoices were created.'))
 
        return redirect('admin_dashboard')
 
    # ── Date-range fallback ───────────────────────────────────────────────────
    start_date = request.POST.get('start_date')
    end_date   = request.POST.get('end_date')
    try:
        start = (
            timezone.datetime.fromisoformat(start_date).date()
            if start_date else timezone.now().date().replace(day=1)
        )
        end = (
            timezone.datetime.fromisoformat(end_date).date()
            if end_date else timezone.now().date()
        )
    except Exception:
        messages.error(request, _('Invalid dates provided'))
        return redirect('admin_dashboard')
 
    # All deliveries in range — no invoice_items__isnull filter
    deliveries = models.DailyDelivery.objects.filter(
        admin=user,
        delivery_date__gte=start,
        delivery_date__lte=end,
        customer__is_active=True,
    )
    if not deliveries.exists():
        messages.info(request, _('No deliveries found for the selected range.'))
        return redirect('admin_dashboard')
 
    created_count = 0
    for cid in deliveries.values_list('customer', flat=True).distinct():
        try:
            with transaction.atomic():
                cust_deliveries = models.DailyDelivery.objects.filter(
                    admin=user, customer_id=cid,
                    delivery_date__gte=start, delivery_date__lte=end,
                )
                if not cust_deliveries.exists():
                    continue
                now_str        = timezone.now().strftime('%Y%m%d%H%M%S%f')
                invoice_number = f"INV-RANGE-{now_str}-{cid}"
                invoice = models.Invoice.objects.create(
                    invoice_number=invoice_number, admin=user, shop=user.shop,
                    customer_id=cid, total_amount=Decimal('0'), status='unpaid',
                )
                net_total = _attach_deliveries_to_invoice(invoice, cust_deliveries)
                models.Invoice.objects.filter(pk=invoice.pk).update(total_amount=net_total)
                created_count += 1
        except IntegrityError:
            continue
        except Exception as exc:
            messages.error(
                request,
                _('Error for customer %(id)s: %(e)s') % {'id': cid, 'e': str(exc)}
            )
 
    cache.delete(f"dashboard_{user.id}")
    messages.success(
        request,
        _('Created %(count)s invoice(s) for %(start)s – %(end)s.') % {
            'count': created_count, 'start': start, 'end': end,
        }
    )
    return redirect('admin_dashboard')
 

# ─────────────────────────────────────────────────────────────────────────────
# DELETE INVOICE
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
@require_POST
def delete_invoice(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)

    delivery_ids      = invoice.get_delivery_ids()
    completed_payments = models.Payment.objects.filter(
        Q(invoice=invoice) | Q(delivery_id__in=delivery_ids),
        status='completed'
    ).exists()

    if completed_payments:
        messages.error(
            request,
            _('Cannot delete invoice %(num)s — completed payments exist. Delete payments first.') % {
                'num': invoice.invoice_number
            }
        )
        return redirect('invoice_detail', invoice_id=invoice.id)

    invoice_number = invoice.invoice_number
    try:
        with transaction.atomic():
            if invoice.pdf_file:
                try:
                    invoice.pdf_file.delete(save=False)
                except Exception:
                    pass
            # Explicitly delete InvoiceItems so signals fire cleanly
            invoice.items.all().delete()
            invoice.delete()
    except Exception as exc:
        messages.error(request, _('Failed to delete invoice: %(e)s') % {'e': str(exc)})
        return redirect('invoice_detail', invoice_id=invoice_id)

    cache.delete(f"dashboard_{request.user.id}")
    messages.success(request, _('Invoice %(num)s deleted.') % {'num': invoice_number})
    return redirect('invoices_list')


# ─────────────────────────────────────────────────────────────────────────────
# DELETE ALL INVOICES
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
@require_POST
def delete_all_invoices(request):
    user          = request.user
    invoices      = models.Invoice.objects.filter(admin=user)
    deleted_count = 0
    skipped_count = 0

    for inv in invoices:
        delivery_ids = inv.get_delivery_ids()
        has_paid     = models.Payment.objects.filter(
            Q(invoice=inv) | Q(delivery_id__in=delivery_ids), status='completed'
        ).exists()

        if has_paid:
            skipped_count += 1
            continue

        try:
            with transaction.atomic():
                if inv.pdf_file:
                    try:
                        inv.pdf_file.delete(save=False)
                    except Exception:
                        pass
                models.InvoiceItem.objects.filter(invoice=inv).delete()
                inv.items.all().delete()
                inv.delete()
                deleted_count += 1
        except Exception:
            skipped_count += 1

    cache.delete(f"dashboard_{user.id}")

    if deleted_count:
        messages.success(request, _('Deleted %(n)s invoice(s).') % {'n': deleted_count})
    if skipped_count:
        messages.error(
            request,
            _('Skipped %(n)s invoice(s) with completed payments. Delete those payments first.') % {
                'n': skipped_count
            }
        )
    return redirect('invoices_list')


# ─────────────────────────────────────────────────────────────────────────────
# DELETE FILTERED INVOICES
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
@require_POST
def delete_filtered_invoices(request):
    user = request.user
    customer_id = request.POST.get('customer_id')
    month_value = request.POST.get('month')
    start_date  = request.POST.get('start_date')
    end_date    = request.POST.get('end_date')

    invoices = _apply_invoice_filters(
        models.Invoice.objects.filter(admin=user),
        customer_id=customer_id,
        month_value=month_value,
        start_date=start_date,
        end_date=end_date,
    )

    deleted_count = 0
    skipped_count = 0

    for inv in invoices:
        delivery_ids = inv.get_delivery_ids()
        has_paid = models.Payment.objects.filter(
            Q(invoice=inv) | Q(delivery_id__in=delivery_ids), status='completed'
        ).exists()

        if has_paid:
            skipped_count += 1
            continue

        try:
            with transaction.atomic():
                if inv.pdf_file:
                    try:
                        inv.pdf_file.delete(save=False)
                    except Exception:
                        pass
                inv.items.all().delete()
                inv.delete()
                deleted_count += 1
        except Exception:
            skipped_count += 1

    cache.delete(f"dashboard_{user.id}")

    if deleted_count:
        messages.success(request, _('Deleted %(n)s filtered invoice(s).') % {'n': deleted_count})
    if skipped_count:
        messages.error(
            request,
            _('Skipped %(n)s filtered invoice(s) with completed payments. Delete those payments first.') % {
                'n': skipped_count
            }
        )

    return redirect('invoices_list')


# ─────────────────────────────────────────────────────────────────────────────
# GENERATE BILL (custom date range)
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
def generate_bill(request, customer_id):
    start_date = request.POST.get("start_date")
    end_date   = request.POST.get("end_date")
    customer   = get_object_or_404(models.Customer, id=customer_id)

    try:
        start = timezone.datetime.fromisoformat(start_date).date()
        end   = timezone.datetime.fromisoformat(end_date).date()
    except Exception:
        messages.error(request, _('Invalid dates provided'))
        return redirect('view_bill')

    deliveries = models.DailyDelivery.objects.filter(
        customer=customer,
        delivery_date__gte=start,
        delivery_date__lte=end,
    ).order_by('delivery_date')

    now_str        = timezone.now().strftime('%Y%m%d%H%M%S%f')
    invoice_number = f"INV-CUSTOM-{now_str}-{customer.id}"

    try:
        with transaction.atomic():
            invoice = models.Invoice.objects.create(
                invoice_number = invoice_number,
                admin          = request.user,
                shop           = getattr(request.user, 'shop', None),
                customer       = customer,
                total_amount   = Decimal('0'),
                status         = 'unpaid',
                invoice_year   = start.year,
                invoice_month  = start.month,
            )
            # _attach_deliveries_to_invoice applies discount+tax at total level
            net_total = _attach_deliveries_to_invoice(invoice, deliveries)
            models.Invoice.objects.filter(pk=invoice.pk).update(total_amount=net_total)
            invoice.total_amount = net_total
    except IntegrityError:
        messages.error(request, _('Invoice for this customer and month already exists'))
        return redirect('view_bill')

    cache.delete(f"dashboard_{request.user.id}")
    messages.success(request, _('Custom date invoice created.'))
    return redirect('invoice_detail', invoice_id=invoice.id)


# ─────────────────────────────────────────────────────────────────────────────
# RECORD PAYMENT
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
@require_POST
def record_payment(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    amount  = request.POST.get('amount')
    method  = request.POST.get('method')
    txn_id  = request.POST.get('transaction_id')

    try:
        amount_decimal = Decimal(str(amount))
        if amount_decimal <= Decimal('0'):
            raise ValueError()
    except Exception:
        messages.error(request, _('Please enter a valid payment amount.'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    ctx       = _build_invoice_context(invoice)
    remaining = ctx['remaining']

    if remaining <= Decimal('0'):
        messages.error(request, _('Invoice is already fully paid.'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    if amount_decimal > remaining:
        messages.error(
            request,
            _('Payment %(amt)s exceeds remaining balance %(rem)s.') % {
                'amt': amount_decimal, 'rem': remaining,
            }
        )
        return redirect('invoice_detail', invoice_id=invoice.id)

    try:
        models.Payment.objects.create(
            invoice        = invoice,
            admin          = request.user,
            shop           = request.user.shop,
            payer_customer = invoice.customer,
            amount         = amount_decimal,
            method         = method or 'cash',
            transaction_id = txn_id or '',
            status         = 'completed',
            paid_at        = timezone.now(),
        )
    except Exception as e:
        messages.error(request, _('Failed to record payment: %(e)s') % {'e': str(e)})
        return redirect('invoice_detail', invoice_id=invoice.id)

    # Refresh status
    ctx        = _build_invoice_context(invoice)
    new_status = ctx['computed_status']
    if invoice.status != new_status:
        models.Invoice.objects.filter(pk=invoice.pk).update(status=new_status)

    cache.delete(f"dashboard_{request.user.id}")
    return redirect('invoice_detail', invoice_id=invoice.id)


# ─────────────────────────────────────────────────────────────────────────────
# MARK INVOICE PAID (zero-total)
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
@require_POST
def mark_invoice_paid(request, invoice_id):
    invoice   = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    total_amt = invoice.total_amount or Decimal('0')

    if total_amt != Decimal('0'):
        messages.error(request, _('Only zero-total invoices can be marked paid this way.'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    if invoice.status == 'paid':
        messages.info(request, _('Invoice already marked as paid.'))
        return redirect('invoice_detail', invoice_id=invoice.id)

    try:
        models.Payment.objects.create(
            invoice=invoice, admin=request.user, shop=request.user.shop,
            payer_customer=invoice.customer, amount=Decimal('0'),
            method='system', transaction_id='', status='completed', paid_at=timezone.now(),
        )
        models.Invoice.objects.filter(pk=invoice.pk).update(status='paid')
        invoice.status = 'paid'
        messages.success(request, _('Invoice marked as paid.'))
    except Exception as e:
        messages.error(request, _('Failed: %(e)s') % {'e': str(e)})

    return redirect('invoice_detail', invoice_id=invoice.id)


# ─────────────────────────────────────────────────────────────────────────────
# PDF — generate & download
# ─────────────────────────────────────────────────────────────────────────────

def _render_invoice_pdf(invoice):
    """Shared PDF rendering. Returns (bytes, filename) or (None, None) on error."""
    ctx  = _build_invoice_context(invoice)
    html = render_to_string('accounts/invoice_pdf.html', ctx)
    if not pisa:
        return None, None
    buf        = io.BytesIO()
    pdf_status = pisa.CreatePDF(src=html, dest=buf)
    if pdf_status.err:
        return None, None
    return buf.getvalue(), f"{invoice.invoice_number}.pdf"


@shop_admin_required
def generate_invoice_pdf(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    if not pisa:
        messages.error(request, _('PDF requires xhtml2pdf: pip install xhtml2pdf'))
        return redirect('invoice_detail', invoice_id=invoice.id)
    pdf_bytes, _ = _render_invoice_pdf(invoice)
    if not pdf_bytes:
        messages.error(request, _('Failed to generate PDF.'))
    else:
        messages.success(request, _('PDF ready — click Download PDF.'))
    return redirect('invoice_detail', invoice_id=invoice.id)


@shop_admin_required
def download_invoice_pdf(request, invoice_id):
    invoice = get_object_or_404(models.Invoice, id=invoice_id, admin=request.user)
    if not pisa:
        messages.error(request, _('PDF requires xhtml2pdf: pip install xhtml2pdf'))
        return redirect('invoice_detail', invoice_id=invoice.id)
    pdf_bytes, filename = _render_invoice_pdf(invoice)
    if not pdf_bytes:
        messages.error(request, _('Failed to generate PDF.'))
        return redirect('invoice_detail', invoice_id=invoice.id)
    response = HttpResponse(pdf_bytes, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


@shop_admin_required
def download_all_invoices(request):
    user     = request.user
    invoices = list(models.Invoice.objects.filter(admin=user).order_by('created_at'))
    if not invoices:
        messages.info(request, _('No invoices to download.'))
        return redirect('invoices_list')
    if not pisa:
        messages.error(request, _('PDF requires xhtml2pdf.'))
        return redirect('invoices_list')

    pages = []
    head_html = ''
    for idx, inv in enumerate(invoices):
        ctx      = _build_invoice_context(inv)
        rendered = render_to_string('accounts/invoice_pdf.html', ctx)
        if idx == 0:
            hs = rendered.find('<head>')
            he = rendered.find('</head>')
            if hs != -1 and he != -1:
                head_html = rendered[hs + 6:he]
        bs = rendered.find('<body>')
        be = rendered.find('</body>')
        pages.append(rendered[bs + 6:be] if bs != -1 and be != -1 else rendered)

    if not head_html:
        head_html = (
            '<style>@page{size:A4 portrait;margin:8mm}'
            'body{font-family:DejaVu Sans,Arial,sans-serif;font-size:14px;color:#222}'
            'table{width:100%;border-collapse:collapse}'
            'th,td{border:1px solid #333;padding:4px 6px;font-size:13px}</style>'
        )

    page_css  = '<style>.page{width:100%;box-sizing:border-box;padding:6px;page-break-inside:avoid}.page-break{display:block;page-break-after:always}</style>'
    combined  = f'<html><head>{head_html}{page_css}</head><body>'
    for idx, body in enumerate(pages):
        combined += f'<div class="page">{body}</div>'
        if idx != len(pages) - 1:
            combined += '<div class="page-break"></div>'
    combined += '</body></html>'

    result     = io.BytesIO()
    pdf_status = pisa.CreatePDF(src=combined, dest=result)
    if pdf_status.err:
        messages.error(request, _('Failed to generate combined PDF.'))
        return redirect('invoices_list')

    filename = f"ALL_INVOICES_{timezone.now().strftime('%Y%m%d%H%M%S')}.pdf"
    response = HttpResponse(result.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


# ─────────────────────────────────────────────────────────────────────────────
# SEND ALL INVOICES
# ─────────────────────────────────────────────────────────────────────────────

@shop_admin_required
@require_POST
def send_all_invoices(request):
    from django.core.mail import EmailMessage, get_connection
    from django.conf import settings as djsettings

    user = request.user
    sent = 0
    failed = []

    connection = None
    try:
        if user.smtp_host:
            port = int(user.smtp_port) if user.smtp_port else (465 if user.smtp_use_ssl else 587)
            connection = get_connection(
                'django.core.mail.backends.smtp.EmailBackend',
                host=user.smtp_host, port=port,
                username=user.smtp_username or None, password=user.smtp_password or None,
                use_tls=bool(user.smtp_use_tls), use_ssl=bool(user.smtp_use_ssl), timeout=10,
            )
    except Exception as e:
        messages.warning(request, _('SMTP issue: %(e)s — using site defaults.') % {'e': str(e)})

    from_email = (
        getattr(user, 'smtp_from_email', None)
        or getattr(djsettings, 'DEFAULT_FROM_EMAIL', None)
        or getattr(djsettings, 'EMAIL_HOST_USER', None)
    )

    for inv in models.Invoice.objects.filter(admin=user).order_by('-created_at'):
        to_email = inv.customer.display_email if getattr(inv, 'customer', None) else None
        if not to_email:
            failed.append((inv.invoice_number, 'No customer email'))
            continue
        pdf_bytes, filename = _render_invoice_pdf(inv)
        if not pdf_bytes:
            failed.append((inv.invoice_number, 'PDF generation failed'))
            continue
        shop_name = getattr(user.shop, 'name', '') if hasattr(user, 'shop') else ''
        subj = f"Invoice {inv.invoice_number} from {shop_name}"
        body = (
            f"Dear {inv.customer.display_first_name},\n\n"
            f"Please find attached your invoice {inv.invoice_number}.\n\nThank you."
        )
        try:
            email = (
                EmailMessage(subj, body, from_email, [to_email], connection=connection)
                if from_email
                else EmailMessage(subj, body, to=[to_email], connection=connection)
            )
            email.attach(filename, pdf_bytes, 'application/pdf')
            email.send()
            sent += 1
        except Exception as e:
            failed.append((inv.invoice_number, str(e)))

    if sent:
        messages.success(request, _('Sent %(n)s invoice(s).') % {'n': sent})
    if failed:
        messages.error(
            request,
            _('Failed to send %(n)s invoice(s): %(ex)s') % {'n': len(failed), 'ex': str(failed[:3])}
        )
    return redirect('invoices_list')