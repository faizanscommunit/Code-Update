from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone


class Command(BaseCommand):
    help = "Rebuild the can ledger from DailyDelivery entries. Default is dry-run. Use --commit to apply."

    def add_arguments(self, parser):
        parser.add_argument('--commit', action='store_true', help='Apply changes (delete and recreate ledger)')
        parser.add_argument('--admin-id', type=int, help='Limit rebuild to a specific admin id')

    def handle(self, *args, **options):
        from accounts.models import CanTransaction, DailyDelivery

        commit = options.get('commit')
        admin_id = options.get('admin_id')

        deliveries = DailyDelivery.objects.all().order_by('delivery_date', 'id')
        if admin_id:
            deliveries = deliveries.filter(admin_id=admin_id)

        total_deliveries = deliveries.count()
        total_existing = CanTransaction.objects.count() if not admin_id else CanTransaction.objects.filter(admin_id=admin_id).count()

        self.stdout.write(f"Found {total_deliveries} deliveries to process.")
        self.stdout.write(f"Existing CanTransaction entries to remove: {total_existing}")

        if not commit:
            self.stdout.write(self.style.WARNING('Dry-run mode. Run with --commit to apply changes.'))
            return

        self.stdout.write('Starting rebuild...')

        # Collect existing openings so we can preserve them
        openings_map = {}
        opening_qs = CanTransaction.objects.filter(transaction_type='OPENING')
        if admin_id:
            opening_qs = opening_qs.filter(admin_id=admin_id)
        for o in opening_qs:
            openings_map[o.customer_id] = {
                'opening': int(o.full_cans_delivered or 0),
                'date': o.date,
                'shop_id': o.shop_id,
            }

        with transaction.atomic():
            # Remove existing ledger entries for the scope
            if admin_id:
                CanTransaction.objects.filter(admin_id=admin_id).delete()
            else:
                CanTransaction.objects.all().delete()

            # We'll build new CanTransaction instances and bulk_create them to avoid model save() validation
            instances = []
            created = 0
            warnings = []

            # Group deliveries by customer to compute running balances per-customer
            from collections import defaultdict
            by_customer = defaultdict(list)
            for d in deliveries:
                by_customer[d.customer_id].append(d)

            for cust_id, dvs in by_customer.items():
                # Start balance from preserved opening if present
                opening = openings_map.get(cust_id, {})
                prev_balance = opening.get('opening', 0)

                # If an opening exists, create its CanTransaction first
                if 'opening' in opening:
                    ct_open = CanTransaction(
                        admin=dvs[0].admin,
                        shop_id=opening.get('shop_id'),
                        customer_id=cust_id,
                        date=opening.get('date') or timezone.now().date(),
                        full_cans_delivered=opening.get('opening', 0),
                        empty_cans_received=0,
                        balance_after_transaction=prev_balance,
                        transaction_type='OPENING'
                    )
                    instances.append(ct_open)

                # Process deliveries in chronological order (deliveries already ordered globally)
                for d in dvs:
                    delivered = int(d.quantity_delivered or 0)
                    returned = int(d.empty_cans_received or 0)

                    # allowed empties = previous balance + delivered (exchange allowed)
                    allowed_empty = prev_balance + delivered
                    if returned > allowed_empty:
                        # cap returned to allowed to avoid negative balance; record warning
                        warnings.append(f"Capping returned {returned} -> {allowed_empty} for delivery id={d.id} customer={cust_id}")
                        returned = allowed_empty

                    running = prev_balance + delivered - returned
                    if running < 0:
                        # enforce non-negative as safety
                        warnings.append(f"Negative running fixed to 0 for delivery id={d.id} customer={cust_id}")
                        running = 0

                    ct = CanTransaction(
                        admin=d.admin,
                        shop=getattr(d.admin, 'shop_admin', getattr(d.admin, 'shop', None)),
                        customer=d.customer,
                        date=d.delivery_date,
                        full_cans_delivered=delivered,
                        empty_cans_received=returned,
                        balance_after_transaction=running,
                        related_delivery=d,
                        transaction_type='DELIVERY'
                    )
                    instances.append(ct)
                    prev_balance = running

            # Bulk create in chunks
            batch = 500
            for i in range(0, len(instances), batch):
                CanTransaction.objects.bulk_create(instances[i:i+batch])
                created += len(instances[i:i+batch])

        # Report results and any warnings
        self.stdout.write(self.style.SUCCESS(f'Rebuild complete. Created: {created}'))
        if warnings:
            self.stdout.write(self.style.WARNING('Some adjustments were made during rebuild:'))
            for w in warnings:
                self.stdout.write(self.style.WARNING(' - ' + w))