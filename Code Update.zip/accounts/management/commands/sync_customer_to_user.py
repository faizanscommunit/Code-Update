from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from accounts.models import Customer

User = get_user_model()

class Command(BaseCommand):
    help = 'Sync Customer name/email into linked User objects. Use --dry-run to preview.'

    def add_arguments(self, parser):
        parser.add_argument('--dry-run', action='store_true', help='Show which Users would be updated without saving')

    def handle(self, *args, **options):
        dry = options.get('dry_run', False)
        qs = Customer.objects.filter(user__isnull=False).select_related('user')
        total = qs.count()
        self.stdout.write(self.style.NOTICE(f'Found {total} customers with linked users'))
        changed = 0
        for c in qs:
            u = c.user
            # determine changes
            updates = {}
            if (u.first_name or '') != (c.first_name or ''):
                updates['first_name'] = c.first_name or ''
            if (u.last_name or '') != (c.last_name or ''):
                updates['last_name'] = c.last_name or ''
            if (u.email or '') != (c.email or ''):
                updates['email'] = c.email or ''
            if updates:
                changed += 1
                self.stdout.write(self.style.WARNING(f"Would update user {u.username}: {updates}"))
                if not dry:
                    for k, v in updates.items():
                        setattr(u, k, v)
                    u.save()
                    self.stdout.write(self.style.SUCCESS(f"Updated user {u.username}"))
        self.stdout.write(self.style.NOTICE(f'Done. {changed} users updated.'))
