from django.core.management.base import BaseCommand
from decimal import Decimal
from django.db import transaction
from accounts.models import DailyDelivery, Payment, ReceivableLedger  # adjust app name if needed


class Command(BaseCommand):
    help = 'Purani Deliveries aur Payments ke liye ReceivableLedger entries backfill kare'

    def add_arguments(self, parser):
        parser.add_argument(
            '--deliveries-only',
            action='store_true',
            help='Sirf deliveries backfill kare (payments skip)'
        )
        parser.add_argument(
            '--payments-only',
            action='store_true',
            help='Sirf payments backfill kare (deliveries skip)'
        )

    def handle(self, *args, **options):
        created = 0
        skipped = 0

        # === 1. BACKFILL DELIVERIES (Debit) ===
        if not options['payments_only']:
            self.stdout.write("Processing DailyDeliveries...")
            deliveries = DailyDelivery.objects.filter(ledger_entry__isnull=True).select_related('admin', 'customer', 'can_type')

            for delivery in deliveries.iterator(chunk_size=1000):
                amount = Decimal(delivery.quantity_delivered) * Decimal(delivery.rate_given or 0)

                if amount <= 0:
                    skipped += 1
                    continue

                if ReceivableLedger.objects.filter(delivery=delivery).exists():
                    skipped += 1
                    continue

                ReceivableLedger.objects.create(
                    admin=delivery.admin,
                    shop=getattr(delivery.admin, 'shop_admin', getattr(delivery.admin, 'shop', None)),
                    customer=delivery.customer,
                    date=delivery.delivery_date,
                    transaction_type='delivery',
                    delivery=delivery,
                    debit=amount,
                    credit=Decimal('0'),
                    description=f"Delivery #{delivery.id} - {delivery.quantity_delivered} cans @ {delivery.rate_given}",
                )
                created += 1

                if created % 500 == 0:
                    self.stdout.write(f"Deliveries processed: {created}")

        # === 2. BACKFILL PAYMENTS (Credit) ===
        if not options['deliveries_only']:
            self.stdout.write("\nProcessing Payments...")
            # Sirf woh payments jo customer se aaye hain aur completed hain
            payments = Payment.objects.filter(
                status='completed',
                payer_customer__isnull=False,
                ledger_entries__isnull=True   # related_name = 'ledger_entries'
            ).select_related('admin', 'shop', 'payer_customer')

            for payment in payments.iterator(chunk_size=1000):
                if ReceivableLedger.objects.filter(payment=payment).exists():
                    skipped += 1
                    continue

                pay_date = payment.paid_at.date() if payment.paid_at else payment.created_at.date()

                ReceivableLedger.objects.create(
                    admin=payment.admin,
                    shop=payment.shop,
                    customer=payment.payer_customer,
                    date=pay_date,
                    transaction_type='payment',
                    payment=payment,
                    debit=Decimal('0'),
                    credit=payment.amount,
                    description=f"Payment received via {payment.get_method_display()} (#{payment.id})",
                )
                created += 1

                if created % 500 == 0:
                    self.stdout.write(f"Payments processed: {created}")

        self.stdout.write(
            self.style.SUCCESS(
                f'\n✅ Backfill Completed!\n'
                f'New entries created: {created}\n'
                f'Skipped: {skipped}'
            )
        )