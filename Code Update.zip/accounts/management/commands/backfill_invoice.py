from accounts.models import InvoiceItem
for item in InvoiceItem.objects.all():
    try:
        item.save()    
        InvoiceItem.save() #recalculates all columns
    except Exception as e:
        print(f"Item {item.id}: {e}")