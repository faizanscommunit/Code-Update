from django.core.management.base import BaseCommand
from django.db import transaction
from django.contrib.auth import get_user_model
from accounts import models
import random
import string


def _gen_password(length=10):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))


class Command(BaseCommand):
    help = 'Create Django User accounts for existing Customer rows that lack a linked user'

    def add_arguments(self, parser):
        parser.add_argument('--dry-run', action='store_true', help='Do not save changes; just report')

    def handle(self, *args, **options):
        User = get_user_model()
        dry_run = options.get('dry_run', False)

        # roman-urdu: jo pehle se linked users maujood hain (agar username cust... se banaye gaye thay)
        # unko humaari convention ke mutabiq `customer` role set kar denge. Dry-run mode mein sirf report kareinge.
        existing_linked = models.Customer.objects.filter(user__isnull=False).select_related('user')
        fixed_existing = 0
        for c in existing_linked:
            try:
                u = c.user
                if u and (u.username.startswith('cust') or getattr(u, 'role', None) not in ('super_admin', 'shop_admin')):
                    if dry_run:
                        self.stdout.write(f"[DRY] Would set role='customer' for existing user {u.username} (customer id={c.id})")
                    else:
                        try:
                            u.role = 'customer'
                            u.save(update_fields=['role'])
                            fixed_existing += 1
                        except Exception:
                            pass
            except Exception:
                pass
        if fixed_existing and not dry_run:
            self.stdout.write(f"Updated role='customer' for {fixed_existing} existing linked users")

        # roman-urdu: hum un customers ke liye user accounts banayenge jinke paas `user` field NULL hai
        qs = models.Customer.objects.filter(user__isnull=True)
        total = qs.count()
        created = 0
        skipped = 0

        self.stdout.write(f"Found {total} customers without linked users")

        for cust in qs.order_by('id'):
            # roman-urdu: prepare basic username — phone digits preferred, warna fallback to customer{id}
            base = None
            try:
                if cust.phone_number:
                    digits = ''.join(ch for ch in str(cust.phone_number) if ch.isdigit())
                    if digits:
                        base = f"cust{digits}"
            except Exception:
                base = None

            if not base:
                base = f"customer{cust.id}"

            username = base
            # ensure uniqueness
            suffix = 0
            while User.objects.filter(username=username).exists():
                suffix += 1
                username = f"{base}_{suffix}"

            email = cust.email if cust.email and '@' in cust.email else ''
            password = _gen_password(10)

            if dry_run:
                self.stdout.write(f"[DRY] Would create user '{username}' for customer id={cust.id} email={email}")
                skipped += 1
                continue

            try:
                with transaction.atomic():
                    user = User.objects.create_user(username=username, email=email, password=password)
                    # roman-urdu: copy basic profile fields
                    user.first_name = cust.first_name or ''
                    user.last_name = cust.last_name or ''
                    # set role as customer for these generated accounts
                    try:
                        user.role = 'customer'
                    except Exception:
                        pass
                    # custom User may have whatsapp_number or phone related fields
                    try:
                        setattr(user, 'whatsapp_number', cust.whatsapp_number)
                    except Exception:
                        pass
                    user.save()

                    # link back to customer
                    cust.user = user
                    cust.save()
                    created += 1
                    self.stdout.write(f"Created user '{username}' for customer id={cust.id} (password: {password})")
            except Exception as e:
                self.stderr.write(f"Failed for customer id={cust.id}: {e}")

        self.stdout.write(f"Done. Created: {created}. Skipped (dry): {skipped}.")
