# from django.core.management.base import BaseCommand
# from django.db import transaction
# from decimal import Decimal
# import time

# from accounts import models   # apni app ka naam 'accounts' hai to yeh rakho

# class Command(BaseCommand):
#     help = 'Pura ReceivableLedger rebuild karta hai - purane sab delete karke naye banata hai'

#     def handle(self, *args, **options):
#         self.stdout.write(self.style.WARNING('🚀 Starting Full Receivable Ledger Rebalance...'))

#         admin_users = models.User.objects.filter(role='shop_admin')
#         total_admins = admin_users.count()
#         total_success = 0
#         total_errors = 0

#         start_time = time.time()

#         for admin in admin_users:
#             self.stdout.write(f'\nProcessing Shop Admin: {admin.username} ({admin.shop.name if hasattr(admin, "shop") else "No Shop"})')

#             customers = models.Customer.objects.filter(shop__admin=admin)

#             with transaction.atomic():
#                 for customer in customers:
#                     try:
#                         # ==================== 1. Purane sab entries delete ====================
#                         deleted_count = models.ReceivableLedger.objects.filter(
#                             customer=customer,
#                             admin=admin
#                         ).delete()[0]

#                         current_balance = Decimal('0.00')

#                         # ==================== 2. Deliveries (Debit) ====================
#                         deliveries = models.DailyDelivery.objects.filter(
#                             customer=customer,
#                             admin=admin
#                         ).order_by('delivery_date', 'id')

#                         for delivery in deliveries:
#                             debit_amount = Decimal(delivery.quantity_delivered or 0) * Decimal(delivery.rate_given or 0)

#                             ledger = models.ReceivableLedger.objects.create(
#                                 admin=admin,
#                                 shop=getattr(admin, 'shop', None),
#                                 customer=customer,
#                                 date=delivery.delivery_date,
#                                 transaction_type='delivery',
#                                 debit=debit_amount,
#                                 credit=Decimal('0'),
#                                 delivery=delivery,
#                                 description=f"Delivery #{delivery.id} - {delivery.quantity_delivered} cans",
#                             )
#                             current_balance += debit_amount
#                             ledger.balance_after = current_balance
#                             ledger.save()

#                         # ==================== 3. Completed Payments (Credit) ====================
#                         payments = models.Payment.objects.filter(
#                             payer_customer=customer,
#                             admin=admin,
#                             status='completed'
#                         ).order_by('paid_at', 'id')

#                         for payment in payments:
#                             pay_date = payment.paid_at.date() if payment.paid_at else delivery.delivery_date if 'delivery' in locals() else time.timezone.now().date()

#                             ledger = models.ReceivableLedger.objects.create(
#                                 admin=admin,
#                                 shop=getattr(admin, 'shop', None),
#                                 customer=customer,
#                                 date=pay_date,
#                                 transaction_type='payment',
#                                 debit=Decimal('0'),
#                                 credit=payment.amount,
#                                 payment=payment,
#                                 description=f"Payment received - {payment.method}",
#                             )
#                             current_balance -= payment.amount
#                             ledger.balance_after = current_balance
#                             ledger.save()

#                         # Update customer outstanding balance
#                         customer.outstanding_balance = current_balance
#                         customer.save(update_fields=['outstanding_balance'])

#                         total_success += 1
#                         self.stdout.write(self.style.SUCCESS(f'   ✓ Customer {customer.display_name} rebalanced | Balance: {current_balance}'))

#                     except Exception as e:
#                         total_errors += 1
#                         self.stdout.write(self.style.ERROR(f'   ✗ Error for customer {customer.id}: {str(e)}'))

#         elapsed = time.time() - start_time

#         self.stdout.write('\n' + '='*60)
#         self.stdout.write(self.style.SUCCESS(f'✅ FULL REBALANCE COMPLETED!'))
#         self.stdout.write(f'Total Shop Admins Processed : {total_admins}')
#         self.stdout.write(f'Total Customers Rebalanced : {total_success}')
#         self.stdout.write(f'Total Errors               : {total_errors}')
#         self.stdout.write(f'Time Taken                 : {elapsed:.2f} seconds')
#         self.stdout.write('='*60)

#         if total_errors == 0:
#             self.stdout.write(self.style.SUCCESS('🎉 All ledgers rebalanced successfully!'))
#         else:
#             self.stdout.write(self.style.WARNING(f'⚠️ Completed with {total_errors} errors.'))

from django.core.management.base import BaseCommand
from django.db import transaction
from decimal import Decimal
import time
from datetime import datetime

from accounts import models   # agar app ka naam 'accounts' hai

class Command(BaseCommand):
    help = 'Pura Receivable Ledger rebuild karta hai - purane sab delete karke naye banata hai (Best & Clean)'

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING(f'🚀 Starting Full Receivable Ledger Rebalance...'))
        self.stdout.write(f'Start Time: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')

        admin_users = models.User.objects.filter(role='shop_admin')
        total_admins = admin_users.count()
        total_customers_processed = 0
        total_success = 0
        total_errors = 0

        start_time = time.time()

        for admin in admin_users:
            shop_name = getattr(admin.shop, 'name', 'No Shop')
            self.stdout.write(self.style.NOTICE(f'\n📌 Processing Shop: {admin.username} ({shop_name})'))

            customers = models.Customer.objects.filter(shop__admin=admin)

            with transaction.atomic():
                for customer in customers:
                    total_customers_processed += 1
                    try:
                        # === 1. Purane sab ledger entries delete kar do ===
                        models.ReceivableLedger.objects.filter(
                            customer=customer,
                            admin=admin
                        ).delete()

                        current_balance = Decimal('0.00')

                        # === 2. Deliveries → Debit Entries ===
                        deliveries = models.DailyDelivery.objects.filter(
                            customer=customer,
                            admin=admin
                        ).order_by('delivery_date', 'id')

                        for delivery in deliveries:
                            debit_amount = Decimal(delivery.quantity_delivered or 0) * Decimal(delivery.rate_given or 0)

                            ledger = models.ReceivableLedger.objects.create(
                                admin=admin,
                                shop=getattr(admin, 'shop', None),
                                customer=customer,
                                date=delivery.delivery_date,
                                transaction_type='delivery',
                                debit=debit_amount,
                                credit=Decimal('0'),
                                delivery=delivery,
                                description=f"Delivery #{delivery.id} - {delivery.quantity_delivered} cans @ {delivery.rate_given or 0}",
                            )
                            current_balance += debit_amount
                            ledger.balance_after = current_balance
                            ledger.save()

                        # === 3. Completed Payments → Credit Entries ===
                        payments = models.Payment.objects.filter(
                            payer_customer=customer,
                            admin=admin,
                            status='completed'
                        ).order_by('paid_at', 'id')

                        for payment in payments:
                            pay_date = payment.paid_at.date() if payment.paid_at else timezone.now().date()

                            ledger = models.ReceivableLedger.objects.create(
                                admin=admin,
                                shop=getattr(admin, 'shop', None),
                                customer=customer,
                                date=pay_date,
                                transaction_type='payment',
                                debit=Decimal('0'),
                                credit=payment.amount,
                                payment=payment,
                                description=f"Payment received - {payment.method}",
                                notes=f"Payment #{payment.id}"
                            )
                            current_balance -= payment.amount
                            ledger.balance_after = current_balance
                            ledger.save()

                        # === 4. Customer ke outstanding balance ko update kar do ===
                        customer.outstanding_balance = current_balance
                        customer.save(update_fields=['outstanding_balance'])

                        total_success += 1
                        self.stdout.write(self.style.SUCCESS(
                            f'   ✓ {customer.display_name} | Balance: {current_balance}'
                        ))

                    except Exception as e:
                        total_errors += 1
                        self.stdout.write(self.style.ERROR(
                            f'   ✗ Error for {customer.display_name} ({customer.id}): {str(e)}'
                        ))

        elapsed = time.time() - start_time

        self.stdout.write('\n' + '='*70)
        self.stdout.write(self.style.SUCCESS('✅ FULL REBALANCE COMPLETED SUCCESSFULLY!'))
        self.stdout.write(f'Total Shop Admins     : {total_admins}')
        self.stdout.write(f'Total Customers       : {total_customers_processed}')
        self.stdout.write(f'Successfully Rebalanced: {total_success}')
        self.stdout.write(f'Errors Occurred       : {total_errors}')
        self.stdout.write(f'Total Time Taken      : {elapsed:.2f} seconds')
        self.stdout.write('='*70)

        if total_errors == 0:
            self.stdout.write(self.style.SUCCESS('🎉 Sab customers ka ledger bilkul sahi ban gaya!'))
        else:
            self.stdout.write(self.style.WARNING(f'⚠️ {total_errors} customers mein error aaya. Upar dekho details.'))