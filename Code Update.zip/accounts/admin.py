from django.contrib import admin
from . import models
from django.contrib.auth.admin import UserAdmin
from django.db import models as dj_models


from .models import ExpenseCategory, Expense, ExpenseLedger

@admin.register(ExpenseCategory)
class ExpenseCategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'admin', 'description']
    list_filter = ['admin']

@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ['title', 'amount', 'category', 'expense_date', 'status', 'payment_method', 'shop']
    list_filter = ['status', 'category', 'expense_date', 'shop']
    search_fields = ['title', 'reference']

@admin.register(ExpenseLedger)
class ExpenseLedgerAdmin(admin.ModelAdmin):
    list_display = ['date', 'description', 'debit', 'credit', 'balance_after', 'transaction_type', 'shop']
    list_filter = ['transaction_type', 'shop', 'date']
    readonly_fields = ['balance_after']  # Never let admin manually edit this

# ImportExport for easy import/export in admin
from import_export.admin import ImportExportModelAdmin
from .resources import (
    InvoiceResource,
    PaymentResource,
    CustomerResource,
    DailyDeliveryResource,
    SubscriptionResource,
    ReceivableLedgerResource
)


def get_model_field_names(model):
    return [field.name for field in model._meta.fields]


def get_model_search_fields(model):
    text_fields = (
        dj_models.CharField,
        dj_models.TextField,
        dj_models.EmailField,
        dj_models.SlugField,
        dj_models.URLField,
    )
    return [field.name for field in model._meta.fields if isinstance(field, text_fields)]


def get_model_list_filters(model):
    filter_fields = []
    for field in model._meta.fields:
        if field.choices:
            filter_fields.append(field.name)
            continue
        if isinstance(field, (dj_models.BooleanField, dj_models.NullBooleanField, dj_models.DateField, dj_models.DateTimeField, dj_models.ForeignKey)):
            filter_fields.append(field.name)
    return filter_fields


class DynamicAdminMixin:
    def get_list_display(self, request):
        return get_model_field_names(self.model)

    def get_search_fields(self, request):
        return get_model_search_fields(self.model)

    def get_list_filter(self, request):
        return get_model_list_filters(self.model)

from django.db import transaction
from django.utils import timezone
from decimal import Decimal
from django.utils.html import format_html
from django.urls import reverse
from django.shortcuts import redirect
from django.contrib import messages
# ...existing code...

@admin.register(models.CanType)
class CanTypeAdmin(DynamicAdminMixin, admin.ModelAdmin):
    pass

@admin.register(models.ReceivableLedger)
class ReceivableLedgerAdmin(DynamicAdminMixin, ImportExportModelAdmin):
    resource_class = ReceivableLedgerResource

@admin.register(models.Payment)
class PaymentAdmin(DynamicAdminMixin, ImportExportModelAdmin):
    resource_class = PaymentResource


@admin.register(models.Refund)
class RefundAdmin(DynamicAdminMixin, admin.ModelAdmin):
    pass


@admin.register(models.Subscription)
class SubscriptionAdmin(DynamicAdminMixin, ImportExportModelAdmin):
    resource_class = SubscriptionResource


# Inline to show/link DailyDelivery on Invoice admin
class InvoiceItemInline(admin.TabularInline):
    model = models.InvoiceItem
    extra = 0
    readonly_fields = ("line_total", "delivery_link")

    def delivery_link(self, obj):
        if obj.delivery_id:
            url = reverse("admin:accounts_dailydelivery_change", args=[obj.delivery_id])
            return format_html('<a href="{}">Delivery #{}</a>', url, obj.delivery_id)
        return "-"
    delivery_link.short_description = "Delivery"


@admin.register(models.Invoice)
class InvoiceAdmin(DynamicAdminMixin, ImportExportModelAdmin):
    resource_class = InvoiceResource
    inlines = [InvoiceItemInline]
    readonly_fields = ("created_at", "updated_at")


@admin.register(models.InvoiceItem)
class InvoiceItemAdmin(DynamicAdminMixin, ImportExportModelAdmin):
    # Invoice items can also be exported/imported if desired
    def delivery_link(self, obj):
        if obj.delivery_id:
            url = reverse("admin:accounts_dailydelivery_change", args=[obj.delivery_id])
            return format_html('<a href="{}">Delivery #{}</a>', url, obj.delivery_id)
        return "-"
    delivery_link.short_description = "Delivery"









# -------------------- STAFF ADMIN --------------------
@admin.register(models.Staff)
class StaffAdmin(DynamicAdminMixin, ImportExportModelAdmin):
    resource_class = None
    # Allow admin to pick assigned customers via a horizontal filter in admin
    filter_horizontal = ("customers",)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_super_admin():  # see all
            return qs
        if request.user.is_shop_admin():   # shop admin sees only his staff
            return qs.filter(admin=request.user)
        return qs.none()

    def save_model(self, request, obj, form, change):
        if request.user.is_shop_admin() and not obj.admin_id:
            obj.admin = request.user
        obj.save()


# -------------------- CUSTOMER ADMIN --------------------
from django import forms

from django.core.exceptions import ValidationError
from django.utils.translation import gettext as _

class CustomerAdminForm(forms.ModelForm):
    portal_pin = forms.CharField(required=False, widget=forms.PasswordInput(render_value=False), label="Portal PIN", help_text="Optional: set customer's portal PIN (numeric)")
    portal_username = forms.CharField(required=False, label="Portal Username", help_text="Optional username for portal login")

    class Meta:
        model = models.Customer
        fields = '__all__'

    def clean_portal_username(self):
        username = self.cleaned_data.get('portal_username')
        if username:
            qs = models.Customer.objects.filter(portal_username__iexact=username)
            if self.instance and self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise ValidationError(_('Portal username already taken — پورٹل یوزرنیم پہلے سے استعمال میں ہے'))
        return username


@admin.register(models.Customer)
class CustomerAdmin(DynamicAdminMixin, ImportExportModelAdmin):
    resource_class = CustomerResource
    form = CustomerAdminForm
    readonly_fields = ("portal_link",)
    actions = ("suspend_customers", "resume_customers")

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_super_admin():
            return qs
        if request.user.is_shop_admin():
            return qs.filter(shop__admin=request.user)
        return qs.none()

    def portal_link(self, obj):
        if not obj.pk:
            return "(save to see portal link)"
        if obj.portal_is_active:
            url = reverse("customer_portal_login_with_id", args=[obj.pk])
            return format_html('<a href="{}" target="_blank">Open Portal</a>', url)
        return "Not enabled"
    portal_link.short_description = "Customer Portal"

    def save_model(self, request, obj, form, change):
        # Auto assign shop/admin for shop admins
        if request.user.is_shop_admin() and not obj.admin_id:
            obj.admin = request.user
            obj.shop = request.user.shop  # auto assign shop
        # handle portal username & pin
        portal_pin = form.cleaned_data.get("portal_pin") if hasattr(form, 'cleaned_data') else None
        portal_username = form.cleaned_data.get("portal_username") if hasattr(form, 'cleaned_data') else None
        if portal_username:
            obj.portal_username = portal_username
        obj.save()
        if portal_pin:
            if portal_pin.isdigit() and len(portal_pin) == 4:
                obj.set_portal_pin(portal_pin)
            else:
                self.message_user(request, "Invalid PIN: must be 4 digits", level=messages.ERROR)

    def suspend_customers(self, request, queryset):
        updated = queryset.update(is_active=False)
        self.message_user(request, f"Suspended {updated} customer(s)")
    suspend_customers.short_description = "Suspend selected customers"

    def resume_customers(self, request, queryset):
        updated = queryset.update(is_active=True)
        self.message_user(request, f"Resumed {updated} customer(s)")
    resume_customers.short_description = "Resume selected customers"

    # Bulk admin actions for portal PIN management
    def generate_pins(self, request, queryset):
        count = 0
        for c in queryset:
            c.generate_portal_pin()
            count += 1
        self.message_user(request, f"Generated PIN for {count} customer(s)")
    generate_pins.short_description = "Generate portal PIN for selected customers"

    def clear_pins(self, request, queryset):
        # roman-urdu: try fast bulk update; if fields missing, call instance method safely
        try:
            updated = queryset.update(portal_pin_hash=None, portal_is_active=False)
            self.message_user(request, f"Cleared PINs for {updated} customer(s)")
            return
        except Exception:
            count = 0
            for c in queryset:
                try:
                    if hasattr(c, 'clear_portal_pin'):
                        c.clear_portal_pin()
                        count += 1
                except Exception:
                    continue
            self.message_user(request, f"Cleared PINs for {count} customer(s)")
    clear_pins.short_description = "Clear portal PIN for selected customers"

    actions = ("generate_pins", "clear_pins", "suspend_customers", "resume_customers")

    # Allow single-object buttons on change view (Generate PIN / Clear PIN)
    def change_view(self, request, object_id, form_url='', extra_context=None):
        extra_context = extra_context or {}
        if request.method == 'POST' and '_generate_pin' in request.POST:
            cust = self.get_object(request, object_id)
            if cust:
                raw = cust.generate_portal_pin()
                self.message_user(request, f"New PIN generated: {raw}")
                return redirect(request.path)
            if request.method == 'POST' and '_clear_pin' in request.POST:
                cust = self.get_object(request, object_id)
                if cust:
                    # roman-urdu: permission check ab shop ke admin ke basis par
                    cust_admin_id = getattr(getattr(cust, 'shop', None), 'admin_id', None)
                    if not (request.user.is_super_admin() or (request.user.is_shop_admin() and cust_admin_id == request.user.id)):
                        self.message_user(request, "Permission denied", level=messages.ERROR)
                        return redirect(request.path)
                    cust.clear_portal_pin()
                    self.message_user(request, f"Customer PIN cleared")
                    return redirect(request.path)
        if request.method == 'POST' and '_set_custom_pin' in request.POST:
            cust = self.get_object(request, object_id)
            if cust:
                # roman-urdu: permission check ab shop ke admin ke basis par
                cust_admin_id = getattr(getattr(cust, 'shop', None), 'admin_id', None)
                if not (request.user.is_super_admin() or (request.user.is_shop_admin() and cust_admin_id == request.user.id)):
                    self.message_user(request, "Permission denied", level=messages.ERROR)
                    return redirect(request.path)
                custom_pin = request.POST.get('custom_pin')
                if custom_pin:
                    if custom_pin.isdigit() and len(custom_pin) == 4:
                        cust.set_portal_pin(custom_pin)
                        self.message_user(request, f"Custom PIN set")
                    else:
                        self.message_user(request, "Invalid PIN: must be 4 digits", level=messages.ERROR)
                else:
                    self.message_user(request, f"No PIN provided", level=messages.ERROR)
                return redirect(request.path)
        if request.method == 'POST' and '_set_username' in request.POST:
            cust = self.get_object(request, object_id)
            if cust:
                # roman-urdu: permission check ab shop ke admin ke basis par
                cust_admin_id = getattr(getattr(cust, 'shop', None), 'admin_id', None)
                if not (request.user.is_super_admin() or (request.user.is_shop_admin() and cust_admin_id == request.user.id)):
                    self.message_user(request, "Permission denied", level=messages.ERROR)
                    return redirect(request.path)
                custom_username = request.POST.get('custom_username')
                if custom_username:
                    # validate uniqueness
                    if models.Customer.objects.filter(portal_username__iexact=custom_username).exclude(pk=cust.pk).exists():
                        self.message_user(request, "Portal username already taken; please choose another. — پورٹل یوزرنیم پہلے سے استعمال میں ہے، براہ کرم دوسرا منتخب کریں۔", level=messages.ERROR)
                        return redirect(request.path)
                    cust.portal_username = custom_username
                    cust.save(update_fields=['portal_username'])
                    self.message_user(request, f"Portal username set to: {custom_username}")
                else:
                    self.message_user(request, f"No username provided", level=messages.ERROR)
                return redirect(request.path)
        return super().change_view(request, object_id, form_url, extra_context=extra_context)


# -------------------- SHOP ADMIN --------------------
@admin.register(models.Shop)
class ShopAdmin(DynamicAdminMixin, ImportExportModelAdmin):
    resource_class = None

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_super_admin():
            return qs
        if request.user.is_shop_admin():
            return qs.filter(admin=request.user)
        return qs.none()


# -------------------- DAILY DELIVERY ADMIN --------------------
@admin.register(models.DailyDelivery)
class DailyDeliveryAdmin(DynamicAdminMixin, admin.ModelAdmin):
    actions = ("create_invoices_from_deliveries",)

    def invoiced(self, obj):
        return obj.invoice_items.exists()
    invoiced.boolean = True
    invoiced.short_description = "Invoiced"

    @transaction.atomic
    def create_invoices_from_deliveries(self, request, queryset):
        # Group selected deliveries by customer and create one invoice per customer
        grouped = {}
        for d in queryset.select_related("customer", "shop", "admin"):
            grouped.setdefault(d.customer_id, []).append(d)

        created_count = 0
        for cust_id, deliveries in grouped.items():
            first = deliveries[0]
            invoice_number = f"INV-{timezone.now().strftime('%Y%m%d%H%M%S')}-{first.customer_id}"
            invoice = models.Invoice.objects.create(
                invoice_number=invoice_number,
                admin=first.admin,
                shop=first.shop,
                customer=first.customer,
                total_amount=Decimal("0.00"),
                status="draft"
            )
            total = Decimal("0.00")
            for d in deliveries:
                # Convert values to Decimal via string to avoid float * Decimal issues
                qty = Decimal(str(d.quantity_delivered or 0))
                try:
                    cust_ct = models.CustomerCanType.objects.get(customer=d.customer, can_type=d.can_type)
                    unit = Decimal(str(cust_ct.price))
                except Exception:
                    unit = Decimal(str(getattr(d, "rate_given", 0) or 0))
                line_total = qty * unit
                models.InvoiceItem.objects.create(
                    invoice=invoice,
                    delivery=d,
                    description=f"Delivery #{d.id}",
                    quantity=qty,
                    unit_price=unit,
                    line_total=line_total
                )
                total += line_total
            invoice.total_amount = total
            invoice.save()
            created_count += 1
        self.message_user(request, f"Created {created_count} invoice(s) from selected deliveries.")
    create_invoices_from_deliveries.short_description = "Create invoices from selected deliveries"

# -------------------- USER ADMIN --------------------
@admin.register(models.User)
class CustomUserAdmin(DynamicAdminMixin, UserAdmin):
    model = models.User
    fieldsets = UserAdmin.fieldsets + (
        ("Other Information", {"fields": ("role", "shop", "shop_type", "whatsapp_number", "refund_account_number", "refund_account_title", "monthly_charges", "address", "is_demo")} ),
    )
