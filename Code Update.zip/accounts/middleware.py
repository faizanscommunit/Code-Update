# -------------------- middleware.py --------------------
from django.shortcuts import redirect
from django.contrib import messages
from django.utils.translation import gettext as _
import os
from django.conf import settings
from django.utils import timezone
# from . import models  # Remove this top-level import


class ShopActivityLoggingMiddleware:
    """Middleware to record per-shop activity logs.

    - Authenticated shop admins and staff actions are logged to a file named
      `shop_<admin_id>.log` under `<BASE_DIR>/logs/shops/`.
    - Customer portal actions (session key `customer_portal_id`) are also
      logged against the shop admin owning the customer.
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        try:
            admin_user = None
            actor = None

            # Authenticated Django User (shop admin or staff)
            if hasattr(request, 'user') and request.user.is_authenticated:
                actor = f"User:{request.user.username} (role={getattr(request.user, 'role', 'unknown')})"
                if getattr(request.user, 'is_shop_admin', False) or getattr(request.user, 'role', None) == 'shop_admin':
                    admin_user = request.user
                elif getattr(request.user, 'role', None) == 'staff':
                    # try to resolve Staff record to find owning admin
                    try:
                        from . import models  # Import locally
                        staff_obj = models.Staff.objects.filter(user=request.user).first()
                        if staff_obj:
                            admin_user = staff_obj.admin
                    except Exception:
                        admin_user = None

            # Customer portal session (customer actions)
            if not admin_user:
                cid = request.session.get('customer_portal_id')
                if cid:
                    try:
                        from . import models  # Import locally
                        cust = models.Customer.objects.filter(id=cid).first()
                        if cust:
                            admin_user = cust.admin
                            actor = f"Customer:{cust.id} {cust.first_name} {cust.last_name}"
                    except Exception:
                        admin_user = None

            if admin_user:
                # build log directory
                log_dir = os.path.join(getattr(settings, 'BASE_DIR', '.'), 'logs', 'shops')
                os.makedirs(log_dir, exist_ok=True)
                fname = os.path.join(log_dir, f"shop_{admin_user.id}.log")
                # Prepare a compact log line
                ts = timezone.now().isoformat()
                ip = request.META.get('REMOTE_ADDR', '')
                method = request.method
                path = request.path
                data_keys = ''
                try:
                    if method == 'POST':
                        data_keys = ','.join(list(request.POST.keys()))
                except Exception:
                    data_keys = ''
                line = f"{ts}\t{actor or 'Anonymous'}\t{ip}\t{method}\t{path}\t{data_keys}\n"
                try:
                    with open(fname, 'a', encoding='utf-8') as fh:
                        fh.write(line)
                except Exception:
                    # non-fatal: don't interrupt request on logging errors
                    pass
        except Exception:
            pass

        return self.get_response(request)

class BlockedUserMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated:
            if getattr(request.user, 'is_blocked', False):
                allowed = ["/accounts/logout/", "/accounts/login/"]
                if request.path not in allowed:
                    messages.error(request, _('Your account has been blocked. Contact admin.'))
                    return redirect('accounts:login')
        return self.get_response(request)


class NoCacheMiddleware:
    """
    Adds cache control headers to prevent browser caching of dynamic content.
    This ensures that users always see fresh data after updates.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        # Add no-cache headers for authenticated users on dynamic pages
        if hasattr(request, 'user') and request.user.is_authenticated:
            # Skip caching for common static/media paths
            if not any(skip_path in request.path for skip_path in [
                '/static/', '/media/', '/favicon', '/admin/jsi18n/',
                '/__debug__/', '/tracking/api/location/'
            ]):
                response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
                response['Pragma'] = 'no-cache'
                response['Expires'] = '0'

        return response