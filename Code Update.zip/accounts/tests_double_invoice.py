from django.test import TestCase, Client
from django.urls import reverse
from . import models, invoice_views
from django.contrib.auth import get_user_model
from datetime import date
from decimal import Decimal

User = get_user_model()

class InvoiceGenerationTests(TestCase):
    def setUp(self):
        # create shop admin
        self.user = User.objects.create_user(username='admin1', password='pass', role='shop_admin')
        self.shop = models.Shop.objects.create(name='Test Shop', admin=self.user)
        # create customer
        self.customer = models.Customer.objects.create(admin=self.user, shop=self.shop, first_name='John', last_name='Doe', email='a@b.com', phone_number='123', whatsapp_number='123', address='Addr')
        # create deliveries in Jan 2026
        models.DailyDelivery.objects.create(admin=self.user, customer=self.customer, rate_given=100, quantity_delivered=2, delivery_date=date(2026,1,5), can_type=models.CanType.objects.create(admin=self.user, can_type='small', price=100))
        models.DailyDelivery.objects.create(admin=self.user, customer=self.customer, rate_given=100, quantity_delivered=3, delivery_date=date(2026,1,20), can_type=models.CanType.objects.create(admin=self.user, can_type='large', price=150))
        self.client = Client()
        self.client.force_login(self.user)

    def test_prevent_double_generation(self):
        url = reverse('auto_generate_invoices')
        # generate for Jan 2026 first time
        resp1 = self.client.post(url, {'month': '2026-01'}, follow=True)
        self.assertEqual(models.Invoice.objects.filter(admin=self.user, invoice_year=2026, invoice_month=1).count(), 1)
        # The generated invoice should show the full month date range (1st to last day)
        list_resp = self.client.get(reverse('invoices_list'))
        self.assertEqual(list_resp.status_code, 200)
        self.assertContains(list_resp, '01 Jan 2026 - 31 Jan 2026')
        # generate again -> should not create new invoices
        resp2 = self.client.post(url, {'month': '2026-01'}, follow=True)
        self.assertEqual(models.Invoice.objects.filter(admin=self.user, invoice_year=2026, invoice_month=1).count(), 1)
        # Ensure appropriate error message appeared in response
        self.assertContains(resp2, 'Invoices for the selected month already exist', status_code=200)

    def test_download_all_invoices_pdf_generation(self):
        # ensure at least two invoices exist (create via generator)
        url = reverse('auto_generate_invoices')
        resp1 = self.client.post(url, {'month': '2026-01'}, follow=True)
        # hit download all
        dl_url = reverse('download_all_invoices')
        # Skip test if xhtml2pdf not installed in environment
        try:
            from xhtml2pdf import pisa  # noqa
        except Exception:
            self.skipTest('xhtml2pdf not installed; skipping combined PDF test')

        resp = self.client.get(dl_url)
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp['Content-Type'], 'application/pdf')
        # basic sanity: PDF file starts with %PDF
        self.assertTrue(resp.content[:4] == b'%PDF' or b'%PDF' in resp.content[:16])

    def test_customer_specific_rate_used_in_invoice_generation(self):
        # Create a can type and assign a custom price to customer
        can = models.CanType.objects.create(admin=self.user, can_type='custom', price=100)
        # assign custom price 150 to this customer
        models.CustomerCanType.objects.create(admin=self.user, customer=self.customer, can_type=can, price=150)
        # create a delivery for this can type (rate_given left default)
        models.DailyDelivery.objects.create(admin=self.user, customer=self.customer, quantity_delivered=2, delivery_date=date(2026,1,10), can_type=can)
        # generate invoices for Jan 2026
        url = reverse('auto_generate_invoices')
        resp = self.client.post(url, {'month': '2026-01'}, follow=True)
        inv = models.Invoice.objects.get(admin=self.user, customer=self.customer, invoice_year=2026, invoice_month=1)
        # total should reflect customer-specific price (2 * 150 = 300)
        self.assertEqual(inv.total_amount, Decimal('300'))

    def test_invoice_rate_snapshot_preserved_after_customer_update(self):
        self.customer.discount_percent = Decimal('10.00')
        self.customer.discount_flat = Decimal('20.00')
        self.customer.is_tax_exempt = False
        self.customer.tax_rate = Decimal('5.00')
        self.customer.save()

        url = reverse('auto_generate_invoices')
        self.client.post(url, {'month': '2026-01'}, follow=True)

        inv = models.Invoice.objects.get(admin=self.user, customer=self.customer, invoice_year=2026, invoice_month=1)
        expected_total = inv.total_amount
        self.assertEqual(inv.discount_percent_snapshot, Decimal('10.00'))
        self.assertEqual(inv.discount_flat_snapshot, Decimal('20.00'))
        self.assertEqual(inv.tax_rate_snapshot, Decimal('5.00'))
        self.assertFalse(inv.is_tax_exempt_snapshot)

        self.customer.discount_percent = Decimal('25.00')
        self.customer.tax_rate = Decimal('12.00')
        self.customer.save()

        inv.refresh_from_db()
        self.assertEqual(inv.total_amount, expected_total)

        ctx = invoice_views._build_invoice_context(inv)
        self.assertEqual(ctx['customer_discount_pct'], Decimal('10.00'))
        self.assertEqual(ctx['customer_discount_flat'], Decimal('20.00'))
        self.assertEqual(ctx['customer_tax_rate'], Decimal('5.00'))
        self.assertFalse(ctx['customer_tax_exempt'])