from import_export import resources, fields
from import_export.widgets import ForeignKeyWidget, DateWidget
from . import models

class ReceivableLedgerResource(resources.ModelResource):
    shop = fields.Field(attribute='shop', column_name='shop', widget=ForeignKeyWidget(models.Shop, 'name'))
    customer = fields.Field(attribute='customer', column_name='customer', widget=ForeignKeyWidget(models.Customer, 'phone_number'))

    class Meta:
        model = models.ReceivableLedger

class InvoiceResource(resources.ModelResource):
    shop = fields.Field(attribute='shop', column_name='shop', widget=ForeignKeyWidget(models.Shop, 'name'))
    customer = fields.Field(attribute='customer', column_name='customer', widget=ForeignKeyWidget(models.Customer, 'phone_number'))
    due_date = fields.Field(attribute='due_date', column_name='due_date', widget=DateWidget('%Y-%m-%d'))

    class Meta:
        model = models.Invoice


class PaymentResource(resources.ModelResource):
    invoice = fields.Field(attribute='invoice', column_name='invoice', widget=ForeignKeyWidget(models.Invoice, 'invoice_number'))
    paid_at = fields.Field(attribute='paid_at', column_name='paid_at', widget=DateWidget('%Y-%m-%d %H:%M'))

    class Meta:
        model = models.Payment


class CustomerResource(resources.ModelResource):
    shop = fields.Field(attribute='shop', column_name='shop', widget=ForeignKeyWidget(models.Shop, 'name'))

    class Meta:
        model = models.Customer


class DailyDeliveryResource(resources.ModelResource):
    customer = fields.Field(attribute='customer', column_name='customer', widget=ForeignKeyWidget(models.Customer, 'phone_number'))
    staff = fields.Field(attribute='staff', column_name='staff', widget=ForeignKeyWidget(models.Staff, 'phone_number'))
    delivery_date = fields.Field(attribute='delivery_date', column_name='delivery_date', widget=DateWidget('%Y-%m-%d'))
    entry_date = fields.Field(attribute='entry_date', column_name='entry_date', widget=DateWidget('%Y-%m-%d'))
        
    class Meta:
        model = models.DailyDelivery

class SubscriptionResource(resources.ModelResource):
    shop = fields.Field(attribute='shop', column_name='shop', widget=ForeignKeyWidget(models.Shop, 'name'))
    customer = fields.Field(attribute='customer', column_name='customer', widget=ForeignKeyWidget(models.Customer, 'phone_number'))

    class Meta:
        model = models.Subscription
