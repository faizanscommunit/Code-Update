from django.test import TestCase, Client
from django.urls import reverse
from .models import User, Staff

class StaffAdminDashboardUITest(TestCase):
    def setUp(self):
        # create shop admin user
        self.admin_user = User.objects.create_user(username='shopowner', password='pass', role='shop_admin')
        # ensure shop exists (admin_dashboard view creates if missing on login, but ensure)
        # login via client
        self.client = Client()
        self.client.login(username='shopowner', password='pass')
        # create a staff member
        # create linked user for staff
        staff_user = User.objects.create_user(username='staff1', password='pass', role='staff')
        staff = Staff.objects.create(admin=self.admin_user, user=staff_user, first_name='Ali', last_name='Khan', phone_number='03001234567', salary=1000)
        self.staff = staff

    def test_dashboard_shows_staff_actions(self):
        resp = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(resp.status_code, 200)
        # Add Employee button
        self.assertContains(resp, reverse('staff_create'))
        # Edit link for staff
        self.assertContains(resp, reverse('staff_edit', args=[self.staff.id]))
        # Delete action URL
        self.assertContains(resp, reverse('staff_delete', args=[self.staff.id]))
        # Deliveries link
        self.assertContains(resp, reverse('staff_deliveries', args=[self.staff.id]))
