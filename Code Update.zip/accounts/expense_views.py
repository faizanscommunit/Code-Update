# -------------------- views/expense_views.py --------------------
# Paste this into your existing views.py or a separate expense_views.py file

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Sum, Q
from django.utils import timezone
from django.core.paginator import Paginator
from decimal import Decimal
import datetime
from accounts.views import require_POST
from accounts.decorators import shop_admin_required
from .models import Expense, ExpenseCategory, ExpenseLedger

# ── Helper function (add this near the top of views.py with your other helpers) ──

def rebalance_expense_ledger(admin, shop):
    """
    Recalculate balance_after for all ExpenseLedger entries for this shop
    in chronological order. Call this after bulk deletions to fix the
    running total — same pattern as rebalance_customer_ledger.
    """
    from .models import ExpenseLedger
    from decimal import Decimal

    entries = ExpenseLedger.objects.filter(
        admin=admin,
        shop=shop,
    ).order_by('date', 'id')

    running = Decimal('0.00')
    for entry in entries:
        running += (entry.debit - entry.credit)
        if entry.balance_after != running:
            ExpenseLedger.objects.filter(id=entry.id).update(balance_after=running)


# ── View ──────────────────────────────────────────────────────────────────────

@shop_admin_required
@require_POST
def expense_delete_all(request):
    """
    Delete all expenses for the current admin's shop with username confirmation.
    Cleans up ledger entries and rebalances the running total afterward.
    """
    from .models import Expense, ExpenseLedger

    confirm_username = request.POST.get('confirm_username', '').strip()

    # Username must match exactly
    if confirm_username != request.user.username:
        messages.error(
            request,
            'Username confirmation failed. No expenses were deleted.'
        )
        return redirect('expense_list')

    admin = get_admin(request)
    shop = getattr(admin, 'shop_admin', None)

    expenses_to_delete = Expense.objects.filter(admin=admin, shop=shop)

    if not expenses_to_delete.exists():
        messages.warning(request, 'No expenses found to delete.')
        return redirect('expense_list')

    count = expenses_to_delete.count()

    # Step 1: Delete ledger entries tied to these expenses first
    # (avoids orphaned ledger rows since Expense is FK on ExpenseLedger)
    ExpenseLedger.objects.filter(
        expense__in=expenses_to_delete,
        admin=admin,
        shop=shop,
    ).delete()

    # Step 2: Delete the expenses themselves
    expenses_to_delete.delete()

    # Step 3: Rebalance any remaining ledger entries (e.g. manual adjustments
    # that weren't tied to a specific Expense object)
    rebalance_expense_ledger(admin, shop)

    # Step 4: Clear dashboard cache
    try:
        from django.core.cache import cache
        cache.delete(f"dashboard_{admin.id}")
    except Exception:
        pass

    messages.success(
        request,
        f'Successfully deleted {count} expense record(s) and all related ledger entries. '
        f'Running balance has been reset.'
    )
    return redirect('expense_list')

# ─────────────────────────────────────────────
# HELPER: scope every query to the logged-in shop owner
# (same pattern as your DailyDelivery / Customer views)
# ─────────────────────────────────────────────
def get_admin(request):
    """Return the shop-owner User for scoping queries."""
    user = request.user
    # Staff act on behalf of their shop's admin
    if hasattr(user, 'role') and user.role == 'staff':
        try:
            from .models import Staff
            return Staff.objects.get(user=user).admin
        except Exception:
            pass
    return user


# ─────────────────────────────────────────────
# 1. LIST ALL EXPENSES
# ─────────────────────────────────────────────
@login_required
def expense_list(request):
    admin = get_admin(request)

    expenses = Expense.objects.filter(admin=admin).select_related(
        'category', 'shop'
    ).order_by('-expense_date', '-id')

    # ── Filters ──────────────────────────────
    status_filter = request.GET.get('status', '')
    category_filter = request.GET.get('category', '')
    search = request.GET.get('search', '').strip()
    from_date = request.GET.get('from_date', '')
    to_date = request.GET.get('to_date', '')

    if status_filter:
        expenses = expenses.filter(status=status_filter)
    if category_filter:
        expenses = expenses.filter(category_id=category_filter)
    if search:
        expenses = expenses.filter(
            Q(title__icontains=search) | Q(reference__icontains=search)
        )
    if from_date:
        try:
            expenses = expenses.filter(
                expense_date__gte=datetime.date.fromisoformat(from_date)
            )
        except ValueError:
            pass
    if to_date:
        try:
            expenses = expenses.filter(
                expense_date__lte=datetime.date.fromisoformat(to_date)
            )
        except ValueError:
            pass

    # ── Summary cards ────────────────────────
    total_paid = expenses.filter(status='paid').aggregate(
        t=Sum('amount')
    )['t'] or Decimal('0.00')
    total_pending = expenses.filter(status='pending').aggregate(
        t=Sum('amount')
    )['t'] or Decimal('0.00')
    total_cancelled = expenses.filter(status='cancelled').aggregate(
        t=Sum('amount')
    )['t'] or Decimal('0.00')

    # ── Pagination ───────────────────────────
    paginator = Paginator(expenses, 20)
    page = request.GET.get('page', 1)
    expenses_page = paginator.get_page(page)

    categories = ExpenseCategory.objects.filter(admin=admin)

    return render(request, 'expenses/expense_list.html', {
        'expenses': expenses_page,
        'categories': categories,
        'total_paid': total_paid,
        'total_pending': total_pending,
        'total_cancelled': total_cancelled,
        'status_filter': status_filter,
        'category_filter': category_filter,
        'search': search,
        'from_date': from_date,
        'to_date': to_date,
    })


# ─────────────────────────────────────────────
# 2. ADD EXPENSE
# ─────────────────────────────────────────────
@login_required
def expense_add(request):
    admin = get_admin(request)
    categories = ExpenseCategory.objects.filter(admin=admin)

    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        amount = request.POST.get('amount', '').strip()
        category_id = request.POST.get('category', '').strip()
        expense_date = request.POST.get('expense_date', '').strip()
        payment_method = request.POST.get('payment_method', '').strip()
        reference = request.POST.get('reference', '').strip()
        description = request.POST.get('description', '').strip()
        status = request.POST.get('status', 'paid').strip()

        # ── Validation ───────────────────────
        errors = []
        if not title:
            errors.append('Title is required.')
        if not amount:
            errors.append('Amount is required.')
        else:
            try:
                amount = Decimal(amount)
                if amount <= 0:
                    errors.append('Amount must be greater than zero.')
            except Exception:
                errors.append('Enter a valid amount.')
        if not expense_date:
            errors.append('Date is required.')
        else:
            try:
                expense_date = datetime.date.fromisoformat(expense_date)
            except ValueError:
                errors.append('Enter a valid date.')

        if errors:
            for e in errors:
                messages.error(request, e)
            return render(request, 'expenses/expense_form.html', {
                'categories': categories,
                'post': request.POST,
                'form_title': 'Add Expense',
            })

        # ── Create ───────────────────────────
        category = None
        if category_id:
            try:
                category = ExpenseCategory.objects.get(
                    id=category_id, admin=admin
                )
            except ExpenseCategory.DoesNotExist:
                pass

        shop = getattr(admin, 'shop_admin', None)

        Expense.objects.create(
            admin=admin,
            shop=shop,
            category=category,
            title=title,
            amount=amount,
            expense_date=expense_date,
            payment_method=payment_method or None,
            reference=reference or None,
            description=description or None,
            status=status,
        )
        # Expense.save() automatically creates the ExpenseLedger entry

        messages.success(request, f'Expense "{title}" added successfully.')
        return redirect('expense_list')

    return render(request, 'expenses/expense_form.html', {
        'categories': categories,
        'post': {},
        'form_title': 'Add Expense',
        'default_date': timezone.now().date().isoformat(),
    })


# ─────────────────────────────────────────────
# 3. EDIT EXPENSE
# ─────────────────────────────────────────────
@login_required
def expense_edit(request, pk):
    admin = get_admin(request)
    expense = get_object_or_404(Expense, pk=pk, admin=admin)
    categories = ExpenseCategory.objects.filter(admin=admin)

    if expense.status == 'cancelled':
        messages.error(request, 'Cancelled expenses cannot be edited.')
        return redirect('expense_list')

    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        amount = request.POST.get('amount', '').strip()
        category_id = request.POST.get('category', '').strip()
        expense_date = request.POST.get('expense_date', '').strip()
        payment_method = request.POST.get('payment_method', '').strip()
        reference = request.POST.get('reference', '').strip()
        description = request.POST.get('description', '').strip()
        status = request.POST.get('status', expense.status).strip()

        # ── Validation ───────────────────────
        errors = []
        if not title:
            errors.append('Title is required.')
        if not amount:
            errors.append('Amount is required.')
        else:
            try:
                amount = Decimal(amount)
                if amount <= 0:
                    errors.append('Amount must be greater than zero.')
            except Exception:
                errors.append('Enter a valid amount.')
        if not expense_date:
            errors.append('Date is required.')
        else:
            try:
                expense_date = datetime.date.fromisoformat(expense_date)
            except ValueError:
                errors.append('Enter a valid date.')

        if errors:
            for e in errors:
                messages.error(request, e)
            return render(request, 'expenses/expense_form.html', {
                'categories': categories,
                'post': request.POST,
                'expense': expense,
                'form_title': 'Edit Expense',
            })

        # ── Update ───────────────────────────
        category = None
        if category_id:
            try:
                category = ExpenseCategory.objects.get(
                    id=category_id, admin=admin
                )
            except ExpenseCategory.DoesNotExist:
                pass

        expense.title = title
        expense.amount = amount
        expense.category = category
        expense.expense_date = expense_date
        expense.payment_method = payment_method or None
        expense.reference = reference or None
        expense.description = description or None
        expense.status = status
        expense.save()
        # Expense.save() automatically updates the ExpenseLedger entry

        messages.success(request, f'Expense "{title}" updated successfully.')
        return redirect('expense_list')

    return render(request, 'expenses/expense_form.html', {
        'categories': categories,
        'expense': expense,
        'post': {
            'title': expense.title,
            'amount': expense.amount,
            'category': expense.category_id or '',
            'expense_date': expense.expense_date.isoformat(),
            'payment_method': expense.payment_method or '',
            'reference': expense.reference or '',
            'description': expense.description or '',
            'status': expense.status,
        },
        'form_title': 'Edit Expense',
    })


# ─────────────────────────────────────────────
# 4. CANCEL EXPENSE
# ─────────────────────────────────────────────
@login_required
def expense_cancel(request, pk):
    """
    POST-only view. Changes status to 'cancelled'.
    Expense.save() automatically creates a reversal credit in ExpenseLedger.
    """
    admin = get_admin(request)
    expense = get_object_or_404(Expense, pk=pk, admin=admin)

    if request.method != 'POST':
        return redirect('expense_list')

    if expense.status == 'cancelled':
        messages.warning(request, 'This expense is already cancelled.')
        return redirect('expense_list')

    expense.status = 'cancelled'
    expense.save()
    # Expense.save() automatically creates a reversal credit ledger entry

    messages.success(
        request,
        f'Expense "{expense.title}" cancelled. A reversal entry has been added to the ledger.'
    )
    return redirect('expense_list')


# ─────────────────────────────────────────────
# 5. EXPENSE LEDGER REPORT (with date filter)
# ─────────────────────────────────────────────
@login_required
def expense_ledger_report(request):
    admin = get_admin(request)
    shop = getattr(admin, 'shop_admin', None)

    # ── Date filters (default: current month) ─
    today = timezone.now().date()
    default_from = today.replace(day=1).isoformat()
    default_to = today.isoformat()

    from_date_str = request.GET.get('from_date', default_from)
    to_date_str = request.GET.get('to_date', default_to)
    category_filter = request.GET.get('category', '')
    transaction_type_filter = request.GET.get('transaction_type', '')

    try:
        from_date = datetime.date.fromisoformat(from_date_str)
    except ValueError:
        from_date = today.replace(day=1)

    try:
        to_date = datetime.date.fromisoformat(to_date_str)
    except ValueError:
        to_date = today

    # ── Ledger entries ───────────────────────
    ledger_qs = ExpenseLedger.objects.filter(
        admin=admin,
        shop=shop,
        date__gte=from_date,
        date__lte=to_date,
    ).select_related('expense', 'category').order_by('date', 'id')

    if category_filter:
        ledger_qs = ledger_qs.filter(category_id=category_filter)
    if transaction_type_filter:
        ledger_qs = ledger_qs.filter(transaction_type=transaction_type_filter)

    # ── Summary for the filtered period ─────
    total_debit = ledger_qs.aggregate(t=Sum('debit'))['t'] or Decimal('0.00')
    total_credit = ledger_qs.aggregate(t=Sum('credit'))['t'] or Decimal('0.00')
    net_expense = total_debit - total_credit

    # Opening balance = balance just BEFORE from_date
    opening_entry = ExpenseLedger.objects.filter(
        admin=admin,
        shop=shop,
        date__lt=from_date,
    ).order_by('-date', '-id').first()
    opening_balance = opening_entry.balance_after if opening_entry else Decimal('0.00')

    # Closing balance = last entry in the filtered range
    closing_entry = ledger_qs.last()
    closing_balance = closing_entry.balance_after if closing_entry else opening_balance

    # ── Category-wise breakdown ──────────────
    category_breakdown = (
        ledger_qs.filter(transaction_type='expense')
        .values('category__name')
        .annotate(total=Sum('debit'))
        .order_by('-total')
    )

    # ── Pagination ───────────────────────────
    paginator = Paginator(ledger_qs, 25)
    page = request.GET.get('page', 1)
    ledger_page = paginator.get_page(page)

    categories = ExpenseCategory.objects.filter(admin=admin)

    return render(request, 'expenses/expense_ledger_report.html', {
        'ledger': ledger_page,
        'from_date': from_date_str,
        'to_date': to_date_str,
        'category_filter': category_filter,
        'transaction_type_filter': transaction_type_filter,
        'total_debit': total_debit,
        'total_credit': total_credit,
        'net_expense': net_expense,
        'opening_balance': opening_balance,
        'closing_balance': closing_balance,
        'category_breakdown': category_breakdown,
        'categories': categories,
    })


# ─────────────────────────────────────────────
# 6. EXPENSE CATEGORY MANAGEMENT (bonus)
# ─────────────────────────────────────────────
@login_required
def expense_category_list(request):
    categories = ExpenseCategory.objects.annotate(
        total_spent=Sum('expenses__amount')   # adjust related_name if different
    ).order_by('name')
 
    total_spent_all = categories.aggregate(
        total=Sum('expenses__amount')
    )['total'] or 0
 
    return render(request, 'expenses/expense_category_list.html', {
        'categories':      categories,
        'total_spent_all': total_spent_all,
    })
 

@login_required
def expense_category_add(request):
    admin = get_admin(request)

    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        description = request.POST.get('description', '').strip()

        if not name:
            messages.error(request, 'Category name is required.')
            return render(request, 'expenses/expense_category_form.html', {'post': request.POST})

        if ExpenseCategory.objects.filter(admin=admin, name=name).exists():
            messages.error(request, f'Category "{name}" already exists.')
            return render(request, 'expenses/expense_category_form.html', {'post': request.POST})

        ExpenseCategory.objects.create(
            admin=admin,
            name=name,
            description=description or None,
        )
        messages.success(request, f'Category "{name}" created.')
        return redirect('expense_category_list')

    return render(request, 'expenses/expense_category_form.html', {'post': {}})