from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from django.urls import reverse
from . import models
from django.contrib.messages import get_messages
from decimal import Decimal

User = get_user_model()

class PaymentOverpaymentTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='admin', password='pass', role='shop_admin')
        self.user.shop = models.Shop.objects.create(name='Test Shop', admin=self.user)
        self.user.save()
        self.client = Client()
        self.client.login(username='admin', password='pass')

    def test_record_payment_prevents_overpayment(self):
        cust = models.Customer.objects.create(admin=self.user, shop=self.user.shop, first_name='John', last_name='Doe', email='a@example.com', phone_number='123', whatsapp_number='123', address='X')
        inv = models.Invoice.objects.create(invoice_number='INV-OP-1', admin=self.user, shop=self.user.shop, customer=cust, total_amount=Decimal('100.00'), status='unpaid')
        # Add a payment of 90
        p = models.Payment.objects.create(invoice=inv, admin=self.user, shop=self.user.shop, payer_customer=cust, amount=Decimal('90.00'), method='cash', status='completed')
        # Try to record a payment of 20 (would overpay by 10)
        resp = self.client.post(reverse('invoice_pay', args=[inv.id]), {'amount': '20.00', 'method': 'cash'})
        # Should redirect back to invoice_detail
        self.assertEqual(resp.status_code, 302)
        self.assertTrue(resp.url.endswith(str(inv.id)))
        # Message should indicate overpayment
        messages = list(get_messages(resp.wsgi_request))
        self.assertTrue(any('Payment exceeds remaining' in str(m) or 'باقی' in str(m) for m in messages))

    def test_invoice_detail_hides_payment_form_when_fully_paid(self):
        cust = models.Customer.objects.create(admin=self.user, shop=self.user.shop, first_name='John', last_name='Doe', email='a@example.com', phone_number='123', whatsapp_number='123', address='X')
        inv = models.Invoice.objects.create(invoice_number='INV-PAID-1', admin=self.user, shop=self.user.shop, customer=cust, total_amount=Decimal('100.00'), status='paid')
        p = models.Payment.objects.create(invoice=inv, admin=self.user, shop=self.user.shop, payer_customer=cust, amount=Decimal('100.00'), method='cash', status='completed')
        resp = self.client.get(reverse('invoice_detail', args=[inv.id]))
        self.assertEqual(resp.status_code, 200)
        content = resp.content.decode('utf-8')
        self.assertIn('Invoice fully paid', content)
        self.assertNotIn('Save Payment', content)

    def test_zero_total_invoice_marked_paid_and_blocked(self):
        cust = models.Customer.objects.create(admin=self.user, shop=self.user.shop, first_name='John', last_name='Doe', email='a@example.com', phone_number='123', whatsapp_number='123', address='X')
        # create invoice without explicitly setting status; total_amount = 0 should default to unpaid
        inv = models.Invoice.objects.create(invoice_number='INV-ZERO-1', admin=self.user, shop=self.user.shop, customer=cust, total_amount=Decimal('0.00'))
        inv.refresh_from_db()
        self.assertEqual(inv.status, 'unpaid')

        # invoice detail should show payment form (not 'Invoice fully paid')
        resp = self.client.get(reverse('invoice_detail', args=[inv.id]))
        self.assertEqual(resp.status_code, 200)
        content = resp.content.decode('utf-8')
        self.assertNotIn('Invoice fully paid', content)
        self.assertIn('Save Payment', content)

        # Trying to post a payment > 0 should be blocked as it would overpay (remaining is 0)
        resp = self.client.post(reverse('invoice_pay', args=[inv.id]), {'amount': '1.00', 'method': 'cash'})
        self.assertEqual(resp.status_code, 302)
        messages = list(get_messages(resp.wsgi_request))
        self.assertTrue(any('Payment exceeds remaining' in str(m) or 'باقی' in str(m) for m in messages))

        # If user explicitly marks a zero-total invoice as paid, it should stay paid
        inv2 = models.Invoice.objects.create(invoice_number='INV-ZERO-2', admin=self.user, shop=self.user.shop, customer=cust, total_amount=Decimal('0.00'), status='paid')
        inv2.refresh_from_db()
        self.assertEqual(inv2.status, 'paid')
        resp = self.client.get(reverse('invoice_detail', args=[inv2.id]))
        self.assertEqual(resp.status_code, 200)
        content2 = resp.content.decode('utf-8')
        self.assertIn('Invoice fully paid', content2)
        self.assertNotIn('Save Payment', content2)

    def test_invoice_with_items_and_zero_stored_total_uses_items_total(self):
        cust = models.Customer.objects.create(admin=self.user, shop=self.user.shop, first_name='John', last_name='Doe', email='a@example.com', phone_number='123', whatsapp_number='123', address='X')
        # Create invoice with stored total 0 but with one item that has a line_total
        inv = models.Invoice.objects.create(invoice_number='INV-ITEMS-1', admin=self.user, shop=self.user.shop, customer=cust, total_amount=Decimal('0.00'))
        # create an item with a positive line_total
        it = models.InvoiceItem.objects.create(invoice=inv, description='Test item', quantity=Decimal('1.00'), unit_price=Decimal('100.00'), line_total=Decimal('100.00'))
        # Simulate a bad state where invoice.status has been incorrectly set to 'paid'
        inv.status = 'paid'
        inv.save(update_fields=['status'])

        # Visiting the detail page should correct the status to unpaid/partial and show the payment form
        resp = self.client.get(reverse('invoice_detail', args=[inv.id]))
        self.assertEqual(resp.status_code, 200)
        content = resp.content.decode('utf-8')
        self.assertIn('Total: PKR 100', content)
        self.assertNotIn('Invoice fully paid', content)
        self.assertIn('Save Payment', content)

        inv.refresh_from_db()
        self.assertNotEqual(inv.status, 'paid')
        self.assertIn(inv.status, ['unpaid', 'partial'])

        # Posting a payment for the remaining amount should work and mark invoice paid
        resp = self.client.post(reverse('invoice_pay', args=[inv.id]), {'amount': '100.00', 'method': 'cash'})
        self.assertEqual(resp.status_code, 302)
        inv.refresh_from_db()
        self.assertEqual(inv.status, 'paid')

    def test_paid_invoice_becomes_partial_when_new_delivery_increases_total(self):
        # Create customer and a paid invoice (payment covers full amount)
        cust = models.Customer.objects.create(admin=self.user, shop=self.user.shop, first_name='Alice', last_name='Smith', email='a@example.com', phone_number='555', whatsapp_number='555', address='Y')
        inv = models.Invoice.objects.create(invoice_number='INV-PAID-NEW-DEL', admin=self.user, shop=self.user.shop, customer=cust, total_amount=Decimal('100.00'))
        p = models.Payment.objects.create(invoice=inv, admin=self.user, shop=self.user.shop, payer_customer=cust, amount=Decimal('100.00'), method='cash', status='completed')
        inv.refresh_from_db()
        self.assertEqual(inv.status, 'paid')

        # Add a delivery for the same month which should attach to the existing monthly invoice
        from datetime import date
        # Ensure invoice has month/year set (monthly invoice scenario)
        inv.invoice_year = 2025
        inv.invoice_month = 6
        inv.save()
        delivery_date = date(2025, 6, 15)
        can_type = models.CanType.objects.create(admin=self.user, name='Test Can', price=Decimal('50.00'))
        # Add a delivery that will add 50 to invoice
        d = models.DailyDelivery.objects.create(admin=self.user, staff=None, customer=cust, quantity_delivered=1, rate_given=Decimal('50.00'), can_type=can_type, delivery_date=delivery_date)
        # The signal should have created/updated an InvoiceItem and recalc invoice
        inv.refresh_from_db()
        self.assertIn(inv.status, ['partial', 'unpaid'])
        # Since a previous completed payment of 100 exists and invoice total increased to 150, status should be 'partial'
        self.assertEqual(inv.status, 'partial')


