
from decimal import Decimal
from accounts.models import ExpenseLedger

def get_shop_total_expenses(admin, shop, from_date=None, to_date=None):
    """Total expenses paid for a shop in a date range."""
    qs = ExpenseLedger.objects.filter(admin=admin, shop=shop, transaction_type='expense')
    if from_date:
        qs = qs.filter(date__gte=from_date)
    if to_date:
        qs = qs.filter(date__lte=to_date)
    from django.db.models import Sum
    result = qs.aggregate(total=Sum('debit'))['total']
    return result or Decimal('0.00')

def get_shop_running_balance(admin, shop):
    """Latest cumulative expense balance for a shop."""
    latest = ExpenseLedger.objects.filter(
        admin=admin, shop=shop
    ).order_by('-date', '-id').first()
    return latest.balance_after if latest else Decimal('0.00')


