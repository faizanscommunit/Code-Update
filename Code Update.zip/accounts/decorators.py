from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect

def role_required(allowed_roles=None):
    """
    Decorator to restrict access to specific roles.
    Example:
    @role_required(["staff"])
    def some_view(request): ...
    """
    if allowed_roles is None:
        allowed_roles = []

    def decorator(view_func):
        def _wrapped_view(request, *args, **kwargs):
            if not request.user.is_authenticated:
                raise PermissionDenied("You must be logged in.")
            if request.user.role not in allowed_roles:
                raise PermissionDenied("You do not have permission.")
            return view_func(request, *args, **kwargs)
        return _wrapped_view
    return decorator

def shop_admin_required(view_func):
    def _wrapped_view(request, *args, **kwargs):
        if request.user.is_authenticated:
            print("User Role:", request.user.role)
            if request.user.role == 'staff':
                return redirect('record_delivery')
            elif request.user.role == 'customer':
                return redirect('customer_portal')
            elif request.user.role == '':
                return redirect('customer_portal')

        if not request.user.is_authenticated or not request.user.is_shop_admin():
            return redirect('/login/')
        return view_func(request, *args, **kwargs)
    return _wrapped_view