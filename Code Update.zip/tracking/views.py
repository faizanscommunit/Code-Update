# tracking/views.py
"""
Endpoints
─────────
POST /tracking/api/location/update/   — rider browser silently pushes GPS
GET  /tracking/events/                — SSE stream → admin map
GET  /tracking/                       — admin live map page
GET  /tracking/api/map-data/          — JSON: riders + customer pins + delivered set

No customer-facing tracking views at all.
"""

import json
import time
import logging

from django.http             import JsonResponse, StreamingHttpResponse, HttpResponseForbidden
from django.views.decorators.http   import require_POST, require_GET
from django.views.decorators.csrf   import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.shortcuts        import render
from django.utils            import timezone
from django.views.decorators.cache  import never_cache

from .store  import rider_store, customer_pin_cache, calculate_eta
from .models import RiderSession

log = logging.getLogger(__name__)


# ── Helpers ───────────────────────────────────────────────────────────────────


def _get_todays_delivered(admin_user):
    try:
        from django.apps import apps
        DailyDelivery = apps.get_model('accounts', 'DailyDelivery')
        today = timezone.localdate()
        return list(
            DailyDelivery.objects
            .filter(
                delivery_date=today,
                staff__admin=admin_user,
            )
            .values_list('customer_id', flat=True)
            .distinct()
        )
    except Exception as e:
        log.warning(f"[Tracking] Could not fetch today's deliveries: {e}")
        return []


def _get_todays_delivered_with_times(admin_user):
    """
    Returns a dict mapping customer_id to delivery info including delivery_time
    and whether it's after hours (delivered outside shop's opening/closing times).
    """
    try:
        from django.apps import apps
        DailyDelivery = apps.get_model('accounts', 'DailyDelivery')
        Shop = apps.get_model('accounts', 'Shop')
        
        today = timezone.localdate()
        shop = Shop.objects.filter(admin=admin_user).first()
        
        deliveries = DailyDelivery.objects.filter(
            delivery_date=today,
            staff__admin=admin_user,
        ).select_related('customer').values(
            'customer_id', 'delivered_time'
        ).distinct()
        
        result = {}
        for d in deliveries:
            is_after_hours = False
            help_text = None
            
            # Check if delivery is outside shop hours
            if shop and shop.opening_time and shop.closing_time:
                delivery_time = d['delivered_time']
                if delivery_time:
                    if (delivery_time < shop.opening_time or 
                        delivery_time > shop.closing_time):
                        is_after_hours = True
                        if delivery_time < shop.opening_time:
                            help_text = f"Delivered before shop opening ({shop.opening_time.strftime('%H:%M')})"
                        else:
                            help_text = f"Delivered after shop closing ({shop.closing_time.strftime('%H:%M')})"
            
            result[d['customer_id']] = {
                'is_after_hours': is_after_hours,
                'help_text': help_text,
                'delivered_time': d['delivered_time'].isoformat() if d['delivered_time'] else None,
            }
        
        return result
    except Exception as e:
        log.warning(f"[Tracking] Could not fetch delivery times: {e}")
        return {}


def _get_todays_delivered_by_rider(admin_user):
    try:
        from django.apps import apps
        DailyDelivery = apps.get_model('accounts', 'DailyDelivery')
        today = timezone.localdate()
        deliveries = DailyDelivery.objects.filter(
            delivery_date=today,
            staff__admin=admin_user,
        ).values_list('staff_id', 'customer_id')
        mapping = {}
        for staff_id, customer_id in deliveries:
            mapping.setdefault(staff_id, set()).add(customer_id)
        return {staff_id: list(customer_ids) for staff_id, customer_ids in mapping.items()}
    except Exception as e:
        log.warning(f"[Tracking] Could not fetch today\'s per-rider deliveries: {e}")
        return {}
        

def _get_staff(user):
    try:
        from django.apps import apps
        Staff = apps.get_model('accounts', 'Staff')
        return Staff.objects.filter(user=user).select_related('admin').first()
    except Exception:
        return None


def _is_admin(user):
    return getattr(user, 'role', None) in ('shop_admin', 'super_admin')


def _staff_name(user) -> str:
    n = user.get_full_name().strip()
    return n if n else user.username


def _get_shop(user):
    """Return (lat, lng) for the shop. Falls back to Karachi if not set."""
    try:
        from django.apps import apps
        Shop = apps.get_model('accounts', 'Shop')
        shop = Shop.objects.filter(admin=user).first()
        if shop and shop.latitude and shop.longitude:
            return float(shop.latitude), float(shop.longitude), shop.name or 'Shop'
    except Exception:
        pass
    # return 24.8607, 67.0011, 'Shop'


# ── Silent GPS push (called by the invisible snippet in base/record_delivery) ─

@csrf_exempt
@require_POST
@login_required
def location_update(request):
    """
    Staff browser pushes GPS silently every 8 seconds.
    No response UI — just returns ok/error JSON.
    """
    if getattr(request.user, 'role', None) != 'staff':
        return JsonResponse({'ok': False, 'error': 'Staff only'}, status=403)

    staff = _get_staff(request.user)
    if not staff or staff.is_blocked:
        return JsonResponse({'ok': False, 'error': 'No staff record'}, status=403)

    try:
        data     = json.loads(request.body)
        lat      = float(data['lat'])
        lng      = float(data['lng'])
        heading  = float(data.get('heading')  or 0)
        speed    = float(data.get('speed')    or 0) * 3.6   # m/s → km/h
        accuracy = float(data.get('accuracy') or 0)
    except (KeyError, ValueError, TypeError) as e:
        return JsonResponse({'ok': False, 'error': str(e)}, status=400)

    # Update in-memory store
    rider_store.update(
        rider_id=staff.id,
        staff_name=_staff_name(request.user),
        lat=lat, lng=lng,
        heading=heading, speed=speed, accuracy=accuracy,
        is_active=True,
    )

    # Persist to DB (one row per rider)
    try:
        session, _ = RiderSession.objects.get_or_create(staff=request.user)
        if not session.is_active:
            session.is_active  = True
            session.started_at = timezone.now()
        session.update_location(lat, lng, heading, speed, accuracy)
    except Exception as e:
        log.warning(f"[Tracking] DB persist failed for {request.user.username}: {e}")

    return JsonResponse({'ok': True})


# ── Mark delivery (called from DailyDelivery.save signal or view hook) ────────

@csrf_exempt
@require_POST
@login_required
def mark_delivered(request):
    """
    Called after a successful delivery record via AJAX from record_delivery page.
    Body: { customer_id: int }
    """
    if getattr(request.user, 'role', None) != 'staff':
        return JsonResponse({'ok': False}, status=403)

    staff = _get_staff(request.user)
    if not staff:
        return JsonResponse({'ok': False}, status=403)

    try:
        data        = json.loads(request.body)
        customer_id = int(data['customer_id'])
    except (KeyError, ValueError, TypeError):
        return JsonResponse({'ok': False, 'error': 'bad customer_id'}, status=400)

    rider_store.mark_delivered(staff.id, customer_id)
    return JsonResponse({'ok': True, 'delivered_count': len(rider_store.get(staff.id).delivered_to if rider_store.get(staff.id) else [])})


# ── JSON snapshot for admin map (polled + SSE) ────────────────────────────────

@login_required
@require_GET
def map_data(request):
    """
    Returns riders + customer home pins + today's delivered set with after-hours info.
    Admin only.
    """
    if not _is_admin(request.user):
        return HttpResponseForbidden()

    # Refresh customer pin cache every 5 minutes
    if customer_pin_cache.needs_refresh():
        customer_pin_cache.refresh(request.user)

    rider_delivered = _get_todays_delivered_by_rider(request.user)
    delivery_times = _get_todays_delivered_with_times(request.user)
    riders = []
    for loc in rider_store.all_active():
        rider = loc.to_dict()
        rider['delivered_to'] = rider_delivered.get(loc.rider_id, [])
        rider['delivered_count'] = len(rider['delivered_to'])
        riders.append(rider)

    pins      = customer_pin_cache.to_list()
    delivered = list(_get_todays_delivered(request.user))

    shop_lat, shop_lng, shop_name = _get_shop(request.user)

    return JsonResponse({
        'ok':           True,
        'riders':       riders,
        'customer_pins': pins,
        'delivered':    delivered,   # list of customer_ids delivered today
        'delivery_times': delivery_times,  # dict: customer_id -> {is_after_hours, help_text, delivered_time}
        'shop':         {'lat': shop_lat, 'lng': shop_lng, 'name': shop_name},
        'active_count': len(riders),
        'server_time':  time.time(),
    })


# ── SSE stream for admin ──────────────────────────────────────────────────────

@never_cache
@login_required
def sse_admin_feed(request):
    if not _is_admin(request.user):
        return HttpResponseForbidden()

    admin_user = request.user

    def event_stream():
        tick = 0
        while True:
            tick += 1

            # Refresh customer pins every ~5 min (100 ticks × 3s = 300s)
            if tick == 1 or tick % 100 == 0:
                customer_pin_cache.refresh(admin_user)

            shop_lat, shop_lng, shop_name = _get_shop(admin_user)

            rider_delivered = _get_todays_delivered_by_rider(admin_user)
            delivery_times = _get_todays_delivered_with_times(admin_user)
            riders = []
            for loc in rider_store.all_active():
                rider = loc.to_dict()
                rider['delivered_to'] = rider_delivered.get(loc.rider_id, [])
                rider['delivered_count'] = len(rider['delivered_to'])
                riders.append(rider)

            payload = json.dumps({
                'riders':        riders,
                'customer_pins': customer_pin_cache.to_list(),
                'delivered':     list(_get_todays_delivered(admin_user)),
                'delivery_times': delivery_times,  # Include after-hours info
                'shop':          {'lat': shop_lat, 'lng': shop_lng, 'name': shop_name},
                'server_time':   time.time(),
            })
            yield f"data: {payload}\n\n"

            if tick % 60 == 0:
                rider_store.purge_stale()

            time.sleep(3)

    resp = StreamingHttpResponse(event_stream(), content_type='text/event-stream')
    resp['Cache-Control']     = 'no-cache'
    resp['X-Accel-Buffering'] = 'no'
    return resp


# ── Admin map page ────────────────────────────────────────────────────────────

@login_required
def admin_map_view(request):
    if not _is_admin(request.user):
        return HttpResponseForbidden('Admin only')

    # Seed customer pins immediately
    if customer_pin_cache.needs_refresh():
        customer_pin_cache.refresh(request.user)

    shop_lat, shop_lng, shop_name = _get_shop(request.user)

    try:
        from django.apps import apps
        Staff = apps.get_model('accounts', 'Staff')
        staff_count = Staff.objects.filter(admin=request.user).count()
    except Exception:
        staff_count = 0

    try:
        from django.apps import apps
        Customer = apps.get_model('accounts', 'Customer')
        customer_count = Customer.objects.filter(
            shop__admin=request.user, is_deleted=False,
            latitude__isnull=False, longitude__isnull=False,
        ).count()
    except Exception:
        customer_count = 0

    return render(request, 'tracking/admin_map.html', {
        'shop_lat':      shop_lat,
        'shop_lng':      shop_lng,
        'shop_name':     shop_name,
        'staff_count':   staff_count,
        'customer_count': customer_count,
        'active_riders': rider_store.count_active(),
    })
