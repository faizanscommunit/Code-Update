# tracking/models.py
from django.db import models
from django.conf import settings
from django.utils import timezone


class RiderSession(models.Model):
    """
    One row per Staff user.
    Persists last-known location across server restarts.
    Auto-started on login via signal — rider never touches this manually.
    """
    staff = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='tracking_session',
    )
    is_active  = models.BooleanField(default=False, db_index=True)
    lat        = models.FloatField(null=True, blank=True)
    lng        = models.FloatField(null=True, blank=True)
    heading    = models.FloatField(default=0.0)
    speed_kmh  = models.FloatField(default=0.0)
    accuracy   = models.FloatField(default=0.0)
    started_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)
    stopped_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = 'Rider Session'

    def __str__(self):
        return f"{self.staff.username} [{'LIVE' if self.is_active else 'offline'}]"

    def start(self):
        self.is_active  = True
        self.started_at = timezone.now()
        self.stopped_at = None
        self.save(update_fields=['is_active', 'started_at', 'stopped_at', 'updated_at'])

    def stop(self):
        self.is_active  = False
        self.stopped_at = timezone.now()
        self.save(update_fields=['is_active', 'stopped_at', 'updated_at'])

    def update_location(self, lat, lng, heading=0.0, speed=0.0, accuracy=0.0):
        self.lat       = lat
        self.lng       = lng
        self.heading   = heading
        self.speed_kmh = speed
        self.accuracy  = accuracy
        self.save(update_fields=['lat', 'lng', 'heading', 'speed_kmh', 'accuracy', 'updated_at'])
