# tracking/urls.py
from django.urls import path
from . import views

app_name = 'tracking'

urlpatterns = [
    # Admin
    path('',                       views.admin_map_view,  name='admin_map'),
    path('events/',                views.sse_admin_feed,  name='sse_admin'),
    path('api/map-data/',          views.map_data,        name='map_data'),

    # Rider silent push (called from invisible JS snippet)
    path('api/location/update/',   views.location_update, name='location_update'),
    path('api/mark-delivered/',    views.mark_delivered,  name='mark_delivered'),
]
