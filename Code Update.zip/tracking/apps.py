# tracking/apps.py
import logging

from django.apps import AppConfig


_restored_active_sessions = False


def restore_active_rider_sessions(sender=None, **kwargs):
    global _restored_active_sessions
    if _restored_active_sessions:
        return

    try:
        from .store import rider_store
        from .models import RiderSession
        from django.apps import apps

        active = RiderSession.objects.filter(
            is_active=True, lat__isnull=False
        ).select_related('staff')

        count = 0
        for session in active:
            try:
                Staff = apps.get_model('accounts', 'Staff')
                staff = Staff.objects.filter(user=session.staff).first()
                if not staff:
                    continue
                name = session.staff.get_full_name() or session.staff.username
                rider_store.update(
                    rider_id=staff.id,
                    staff_name=name,
                    lat=session.lat,
                    lng=session.lng,
                    heading=session.heading,
                    speed=session.speed_kmh,
                    accuracy=session.accuracy,
                    is_active=True,
                )
                count += 1
            except Exception:
                pass

        if count:
            logging.getLogger(__name__).info(f"[Tracking] Restored {count} active rider(s) from DB.")
    except Exception:
        pass
    finally:
        _restored_active_sessions = True


class TrackingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tracking'
    label = 'tracking'
    verbose_name = 'Live Rider Tracking'

    def ready(self):
        log = logging.getLogger(__name__)

        # ── 1. Connect signals ────────────────────────────────────────────
        from django.contrib.auth.signals import user_logged_in, user_logged_out
        from django.core.signals import request_started
        from django.dispatch import receiver

        @receiver(user_logged_in)
        def on_rider_login(sender, request, user, **kwargs):
            """Auto-start tracking session when a staff user logs in."""
            try:
                if getattr(user, 'role', None) != 'staff':
                    return
                from .models import RiderSession
                session, _ = RiderSession.objects.get_or_create(staff=user)
                session.start()
                log.info(f"[Tracking] Auto-started session for {user.username}")
            except Exception as e:
                log.warning(f"[Tracking] Login signal failed: {e}")

        @receiver(user_logged_out)
        def on_rider_logout(sender, request, user, **kwargs):
            """Auto-stop tracking session when staff logs out."""
            try:
                if not user or getattr(user, 'role', None) != 'staff':
                    return
                from .models import RiderSession
                from .store import rider_store
                from django.apps import apps
                Staff = apps.get_model('accounts', 'Staff')
                staff = Staff.objects.filter(user=user).first()
                if staff:
                    rider_store.deactivate(staff.id)

                RiderSession.objects.filter(staff=user).update(
                    is_active=False,
                )
                log.info(f"[Tracking] Auto-stopped session for {user.username}")
            except Exception as e:
                log.warning(f"[Tracking] Logout signal failed: {e}")

        @receiver(request_started)
        def ensure_active_sessions_restored(sender, **kwargs):
            restore_active_rider_sessions()
