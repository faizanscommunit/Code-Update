# tracking/store.py
"""
Pure in-memory rider location store. No Redis, no Celery.
Thread-safe with threading.Lock.

Key additions in this version
──────────────────────────────
• delivered_to   : set of customer IDs a rider delivered to today
• CustomerPinCache: customer home locations cached from DB for admin map
"""

import math
import time
import threading
from dataclasses import dataclass, field
from typing import Dict, Optional, Set


# ── Data ─────────────────────────────────────────────────────────────────────

@dataclass
class RiderLocation:
    rider_id:    int
    staff_name:  str
    lat:         float
    lng:         float
    heading:     float = 0.0
    speed:       float = 0.0      # km/h
    accuracy:    float = 0.0      # metres
    timestamp:   float = field(default_factory=time.time)
    is_active:   bool  = True
    delivered_to: Set[int] = field(default_factory=set)   # customer IDs

    def age_seconds(self) -> float:
        return time.time() - self.timestamp

    def is_stale(self, max_age: int = 60) -> bool:
        return self.age_seconds() > max_age

    def to_dict(self) -> dict:
        return {
            'rider_id':    self.rider_id,
            'staff_name':  self.staff_name,
            'lat':         self.lat,
            'lng':         self.lng,
            'heading':     self.heading,
            'speed':       self.speed,
            'accuracy':    self.accuracy,
            'timestamp':   self.timestamp,
            'is_active':   self.is_active,
            'age_seconds': round(self.age_seconds(), 1),
            'is_stale':    self.is_stale(),
            'delivered_to': list(self.delivered_to),
        }


@dataclass
class CustomerPin:
    customer_id:       int
    name:              str
    lat:               float
    lng:               float
    address:           str  = ''
    area:              str  = ''
    phone:             str  = ''
    assigned_staff_id: Optional[int] = None


# ── Haversine + ETA ──────────────────────────────────────────────────────────

def haversine_km(lat1, lng1, lat2, lng2) -> float:
    R  = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a  = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))


def calculate_eta(rider_lat, rider_lng, dest_lat, dest_lng, rider_speed_kmh=0.0) -> dict:
    dist_km = haversine_km(rider_lat, rider_lng, dest_lat, dest_lng)
    speed   = rider_speed_kmh if rider_speed_kmh >= 3.0 else 25.0
    eta_sec = int((dist_km / speed) * 3600)
    if eta_sec < 60:
        label = "Less than a minute"
    elif eta_sec < 3600:
        m = eta_sec // 60
        label = f"{m} min{'s' if m != 1 else ''}"
    else:
        label = f"{eta_sec//3600}h {(eta_sec%3600)//60}m"
    return {'distance_km': round(dist_km, 2), 'eta_seconds': eta_sec,
            'eta_label': label, 'speed_used_kmh': round(speed, 1)}


# ── Customer Pin Cache ────────────────────────────────────────────────────────

class _CustomerPinCache:
    """Caches customer home GPS pins for the admin map. Refresh every 5 min."""

    def __init__(self):
        self._lock  = threading.Lock()
        self._pins: Dict[int, CustomerPin] = {}
        self._last_refresh: float = 0.0

    def refresh(self, admin_user) -> int:
        try:
            from django.apps import apps
            Customer = apps.get_model('accounts', 'Customer')
            qs = Customer.objects.filter(
                shop__admin=admin_user,
                is_deleted=False,
                latitude__isnull=False,
                longitude__isnull=False,
            ).prefetch_related('assigned_staff')

            pins = {}
            for c in qs:
                first_staff = c.assigned_staff.first()
                pins[c.id] = CustomerPin(
                    customer_id=c.id,
                    name=c.display_name,
                    lat=float(c.latitude),
                    lng=float(c.longitude),
                    address=getattr(c, 'full_address', '') or '',
                    area=c.area or '',
                    phone=c.phone_number or '',
                    assigned_staff_id=first_staff.id if first_staff else None,
                )
            with self._lock:
                self._pins = pins
                self._last_refresh = time.time()
            return len(pins)
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"[Tracking] Pin cache refresh failed: {e}")
            return 0

    def needs_refresh(self, interval: int = 300) -> bool:
        return (time.time() - self._last_refresh) > interval

    def to_list(self) -> list:
        with self._lock:
            return [
                {
                    'customer_id':       p.customer_id,
                    'name':              p.name,
                    'lat':               p.lat,
                    'lng':               p.lng,
                    'address':           p.address,
                    'area':              p.area,
                    'phone':             p.phone,
                    'assigned_staff_id': p.assigned_staff_id,
                }
                for p in self._pins.values()
            ]


# ── Rider Store ───────────────────────────────────────────────────────────────

class _RiderStore:

    def __init__(self):
        self._lock   = threading.Lock()
        self._riders: Dict[int, RiderLocation] = {}

    def update(self, rider_id, staff_name, lat, lng,
               heading=0.0, speed=0.0, accuracy=0.0, is_active=True) -> RiderLocation:
        with self._lock:
            prev = self._riders.get(rider_id)
            delivered = prev.delivered_to.copy() if prev else set()
            loc = RiderLocation(
                rider_id=rider_id, staff_name=staff_name,
                lat=lat, lng=lng, heading=heading,
                speed=speed, accuracy=accuracy,
                timestamp=time.time(), is_active=is_active,
                delivered_to=delivered,
            )
            self._riders[rider_id] = loc
        return loc

    def mark_delivered(self, rider_id: int, customer_id: int):
        """Call this when a DailyDelivery is saved for this rider/customer."""
        with self._lock:
            if rider_id in self._riders:
                self._riders[rider_id].delivered_to.add(customer_id)

    def all_delivered_today(self) -> Set[int]:
        with self._lock:
            result: Set[int] = set()
            for loc in self._riders.values():
                result |= loc.delivered_to
            return result

    def deactivate(self, rider_id: int):
        with self._lock:
            if rider_id in self._riders:
                self._riders[rider_id].is_active = False

    def get(self, rider_id: int) -> Optional[RiderLocation]:
        with self._lock:
            return self._riders.get(rider_id)

    def all_active(self, max_age: int = 90) -> list:
        with self._lock:
            return [l for l in self._riders.values() if l.is_active and not l.is_stale(max_age)]

    def count_active(self) -> int:
        with self._lock:
            return sum(1 for l in self._riders.values() if l.is_active)

    def purge_stale(self, max_age: int = 300) -> int:
        with self._lock:
            stale = [rid for rid, l in self._riders.items() if l.is_stale(max_age)]
            for rid in stale:
                del self._riders[rid]
        return len(stale)


# ── Singletons (import these everywhere) ─────────────────────────────────────

rider_store        = _RiderStore()
customer_pin_cache = _CustomerPinCache()
